# Payments

Payments

```go
paymentsApi := client.PaymentsApi()
```

## Class Name

`PaymentsApi`


# Payment-Networks

This product supports use cases such as payment enablement or account opening. The response includes identifiers necessary to make ACH and RTP payments. Identifiers include account number, routing number, identifier type (actual or tokenized account number), and payment network type such as ACH or RTP.

<br>
To see the response schema, select the `200` response below. For an example payload response, see the `200` example response below the *Try it* feature.

> 🛑
> 
> The *id_token* should be used as the bearer token with this call.

```go
PaymentNetworks(
    ctx context.Context,
    version string,
    providerId string,
    accountId string,
    xAkoyaInteractionType *models.InteractionType) (
    models.ApiResponse[models.ArrayOfAccountPaymentNetworks],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | Akoya major version number. Do not use minor version numbers. For instance, use v2 and not v2.2 |
| `providerId` | `string` | Template, Required | Id of provider |
| `accountId` | `string` | Template, Required | Account Identifier |
| `xAkoyaInteractionType` | [`*models.InteractionType`](../../doc/models/interaction-type.md) | Header, Optional | Optional but recommended header to include with each data request.<br>Allowed values are `user` or `batch`.<br>`user` indicates a request is prompted by an end-user action.<br>`batch` indicates the request is part of a batch process. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ArrayOfAccountPaymentNetworks](../../doc/models/array-of-account-payment-networks.md).

## Example Usage

```go
ctx := context.Background()

version := "v2"

providerId := "mikomo"

accountId := ":accountId"

apiResponse, err := paymentsApi.PaymentNetworks(ctx, version, providerId, accountId, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "paymentNetworks": [
    {
      "bankId": "125000024",
      "identifier": "454992210071",
      "identifierType": "ACCOUNT_NUMBER",
      "type": "US_ACH",
      "transferIn": true,
      "transferOut": true
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Customer not authorized. | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | Incorrect providerId or no subscription to provider. | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | 701 - Account not found. The `accountId` may be wrong. | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | `ApiError` |
| 408 | Request timed out (round trip call took >10 seconds). | [`ErrorException`](../../doc/models/error-exception.md) |

