
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| basicAuthCredentials | [`BasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| acgAuthCredentials | [`AcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```go
package main

import (
    "akoyaApIsV240"
    "akoyaApIsV240/models"
)

func main() {
    client := akoyaApIsV240.NewClient(
    akoyaApIsV240.CreateConfiguration(
            akoyaApIsV240.WithHttpConfiguration(
                akoyaApIsV240.CreateHttpConfiguration(
                    akoyaApIsV240.WithTimeout(30),
                ),
            ),
            akoyaApIsV240.WithEnvironment(akoyaApIsV240.PRODUCTION),
            akoyaApIsV240.WithBasicAuthCredentials(
                akoyaApIsV240.NewBasicAuthCredentials(
                    "Username",
                    "Password",
                ),
            ),
            akoyaApIsV240.WithBearerAuthCredentials(
                akoyaApIsV240.NewBearerAuthCredentials("AccessToken"),
            ),
            akoyaApIsV240.WithAcgAuthCredentials(
                akoyaApIsV240.NewAcgAuthCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeAcgAuth{
        models.OauthScopeAcgAuth_Openid,
        models.OauthScopeAcgAuth_Profile,
    }),
            ),
            akoyaApIsV240.WithLoggerConfiguration(
                akoyaApIsV240.WithLevel("info"),
                akoyaApIsV240.WithRequestConfiguration(
                    akoyaApIsV240.WithRequestBody(true),
                ),
                akoyaApIsV240.WithResponseConfiguration(
                    akoyaApIsV240.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Akoya APIs v2.4.0 Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| AccountInformationApi() | Gets AccountInformationApi |
| BalancesApi() | Gets BalancesApi |
| CustomersApi() | Gets CustomersApi |
| InvestmentsApi() | Gets InvestmentsApi |
| PaymentsApi() | Gets PaymentsApi |
| StatementsApi() | Gets StatementsApi |
| TaxBetaApi() | Gets TaxBetaApi |
| TransactionsApi() | Gets TransactionsApi |
| OauthAuthorizationApi() | Gets OauthAuthorizationApi |

