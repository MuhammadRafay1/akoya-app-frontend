
# Local Tax Withholding

Income in a locality and its tax withholding

*This model accepts additional fields of type interface{}.*

## Structure

`LocalTaxWithholding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxWithheld` | `*float64` | Optional | Amount of local income tax withheld |
| `LocalityName` | `*string` | Optional | Locality name |
| `Income` | `*float64` | Optional | Income amount for local tax purposes |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 97.82,
  "localityName": "localityName0",
  "income": 162.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

