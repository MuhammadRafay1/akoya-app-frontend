
# Contribution Entity

Describes how new contributions are distributed among the available securities.

*This model accepts additional fields of type interface{}.*

## Structure

`ContributionEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SecurityId` | `*string` | Optional | Unique identifier of security |
| `SecurityIdType` | [`*models.SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type |
| `EmployerMatchPercentage` | `*float64` | Optional | Employer contribution match percentage |
| `EmployerMatchAmount` | `*float64` | Optional | Employer contribution match amount |
| `EmployeePreTaxAmount` | `*float64` | Optional | Employee pre‐tax contribution amount |
| `EmployeePreTaxPercentage` | `*float64` | Optional | Employee pre‐tax contribution percentage |
| `EmployeeAfterTaxAmount` | `*float64` | Optional | Employee after tax contribution amount |
| `EmployeeAfterTaxPercentage` | `*float64` | Optional | Employee after tax contribution percentage |
| `EmployeeDeferPreTaxAmount` | `*float64` | Optional | Employee defer pre‐tax contribution match amount |
| `EmployeeDeferPreTaxPercentage` | `*float64` | Optional | Employee defer pre‐tax contribution match percentage |
| `EmployeeYearToDate` | `*float64` | Optional | Employee total year to date contribution |
| `EmployerYearToDate` | `*float64` | Optional | Employer total year to date contribution |
| `RolloverContributionPercentage` | `*float64` | Optional | Rollover contribution percentage |
| `RolloverContributionAmount` | `*float64` | Optional | Rollover contribution Amount |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "employerMatchPercentage": 195.92,
  "employerMatchAmount": 120.16,
  "employeePreTaxAmount": 147.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

