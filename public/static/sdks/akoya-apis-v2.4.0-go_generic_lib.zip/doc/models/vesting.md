
# Vesting

*This model accepts additional fields of type interface{}.*

## Structure

`Vesting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VestedQuantity` | `*float64` | Optional | Vested quantity (Vested shares total qty of vesting tranche) |
| `VestedValue` | `*float64` | Optional | Vested balance at grant (aggregate of all vestings) |
| `VestingDate` | `*time.Time` | Optional | - |
| `VestExpireDate` | `*time.Time` | Optional | - |
| `VestedStatus` | `*string` | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "vestedQuantity": 67.92,
  "vestedValue": 165.18,
  "vestingDate": "2016-03-13T12:52:32.123Z",
  "vestExpireDate": "2016-03-13T12:52:32.123Z",
  "vestedStatus": "vestedStatus4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

