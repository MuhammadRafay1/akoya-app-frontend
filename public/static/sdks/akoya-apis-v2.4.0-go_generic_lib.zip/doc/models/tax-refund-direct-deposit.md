
# Tax Refund Direct Deposit

IRS Form 8888 Direct Deposit Information

*This model accepts additional fields of type interface{}.*

## Structure

`TaxRefundDirectDeposit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InstitutionName` | `*string` | Optional | Name of institution |
| `Rtn` | `*string` | Optional | Routing transit number |
| `AccountNumber` | `*string` | Optional | Account number |
| `AccountNickName` | `*string` | Optional | Account nickname |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "institutionName": "institutionName6",
  "rtn": "rtn0",
  "accountNumber": "accountNumber4",
  "accountNickName": "accountNickName4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

