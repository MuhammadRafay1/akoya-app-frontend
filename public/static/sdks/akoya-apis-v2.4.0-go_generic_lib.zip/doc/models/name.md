
# Name

The end-user's name

*This model accepts additional fields of type interface{}.*

## Structure

`Name`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `First` | `*string` | Optional | First or given name. This data element may contain first & last name if not separated. |
| `Middle` | `*string` | Optional | - |
| `Last` | `*string` | Optional | - |
| `Prefix` | `*string` | Optional | Name prefix, e.g. Mr. |
| `Suffix` | `*string` | Optional | Generational or academic suffix |
| `Company` | `*string` | Optional | Company name |
| `Addresses` | [`[]models.Address2`](../../doc/models/address-2.md) | Optional | An array of the end-user's physical mail addresses<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `Telephones` | [`[]models.Telephone`](../../doc/models/telephone.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `Email` | `[]string` | Optional | An array of the end-user's electronic mail addresses |
| `Accounts` | [`[]models.Account7`](../../doc/models/account-7.md) | Optional | List of accounts related to this end-user<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

