
# Tax Lot

*This model accepts additional fields of type interface{}.*

## Structure

`TaxLot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CostBasis` | `*float64` | Optional | Total amount of money spent acquiring this lot including any fees or commission expenses incurred. |
| `CurrentValue` | `*float64` | Optional | Lot market value |
| `OriginalPurchaseDate` | `*time.Time` | Optional | Lot acquired date. |
| `PostionType` | [`*models.PostionType`](../../doc/models/postion-type.md) | Optional | LONG, SHORT. |
| `PurchasedPrice` | `*float64` | Optional | Original purchase price. |
| `Quantity` | `*float64` | Optional | Lot quantity. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "costBasis": 225.68,
  "currentValue": 37.64,
  "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
  "postionType": "LONG",
  "purchasedPrice": 14.46,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

