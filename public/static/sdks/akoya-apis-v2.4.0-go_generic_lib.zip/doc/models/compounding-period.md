
# Compounding Period

## Enumeration

`CompoundingPeriod`

## Fields

| Name |
|  --- |
| `Daily` |
| `Weekly` |
| `Biweekly` |
| `Semimonthly` |
| `Monthly` |
| `Semiannually` |
| `Annually` |

