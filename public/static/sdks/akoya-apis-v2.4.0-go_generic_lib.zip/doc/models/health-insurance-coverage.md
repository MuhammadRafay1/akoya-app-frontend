
# Health Insurance Coverage

Used on Form 1095-A Part III

*This model accepts additional fields of type interface{}.*

## Structure

`HealthInsuranceCoverage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EnrollmentPremium` | `*float64` | Optional | Monthly enrollment premiums |
| `SlcspPremium` | `*float64` | Optional | Monthly second lowest cost silver plan (SLCSP) premium |
| `AdvancePremiumTaxCreditPayment` | `*float64` | Optional | Monthly advance payment of premium tax credit |
| `Month` | [`*models.CoverageMonth1`](../../doc/models/coverage-month-1.md) | Optional | Month of coverage |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "enrollmentPremium": 139.74,
  "slcspPremium": 163.34,
  "advancePremiumTaxCreditPayment": 197.06,
  "month": "MAY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

