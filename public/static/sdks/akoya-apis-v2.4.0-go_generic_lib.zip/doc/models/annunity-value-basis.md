
# Annunity Value Basis

## Enumeration

`AnnunityValueBasis`

## Fields

| Name |
|  --- |
| `Fixed` |
| `Variable` |

