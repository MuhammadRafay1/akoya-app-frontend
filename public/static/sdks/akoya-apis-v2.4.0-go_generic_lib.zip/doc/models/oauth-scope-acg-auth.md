
# Oauth Scope Acg Auth

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeAcgAuth`

## Fields

| Name | Description |
|  --- | --- |
| `Openid` | OpenID Connect authentication |
| `Profile` | Access to user profile information |
| `OfflineAccess` | Request refresh tokens for offline access |

