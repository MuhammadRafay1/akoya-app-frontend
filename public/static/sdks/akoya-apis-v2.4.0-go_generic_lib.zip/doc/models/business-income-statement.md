
# Business Income Statement

Business Income Statement for IRS Form 1040 Schedule C

*This model accepts additional fields of type interface{}.*

## Structure

`BusinessIncomeStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxYear` | `*int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `Corrected` | `*bool` | Optional | True to indicate this is a corrected tax form |
| `AccountId` | `*string` | Optional | Long-term persistent identity of the source account. Not the account number |
| `TaxFormId` | `*string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. |
| `TaxFormDate` | `*time.Time` | Optional | Date of production or delivery of the tax form |
| `AdditionalInformation` | `*string` | Optional | Additional explanation text or content about this tax form |
| `TaxFormType` | [`*models.TypeFormType2`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `Issuer` | [`*models.TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Recipient` | [`*models.TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Attributes` | [`[]models.TaxFormAttribute`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. |
| `Error` | [`*models.Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form |
| `Links` | [`[]models.HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs |
| `BusinessName` | `*string` | Optional | Box C, Business name |
| `Sales` | `*float64` | Optional | Box 1, Gross receipts or sales |
| `Returns` | `*float64` | Optional | Box 2, Returns and allowances |
| `OtherIncome` | [`[]models.DescriptionAndAmount`](../../doc/models/description-and-amount.md) | Optional | Box 6, Other income, including federal and state gasoline or fuel tax credit or refund |
| `Advertising` | `*float64` | Optional | Box 8, Advertising |
| `CarAndTruck` | `*float64` | Optional | Box 9, Car and truck expenses |
| `Commissions` | `*float64` | Optional | Box 10, Commissions and fees |
| `ContractLabor` | `*float64` | Optional | Box 11, Contract labor |
| `Depletion` | `*float64` | Optional | Box 12, Depletion |
| `Depreciation` | `*float64` | Optional | Box 13, Depreciation |
| `EmployeeBenefits` | `*float64` | Optional | Box 14, Employee benefit programs |
| `Insurance` | `*float64` | Optional | Box 15, Insurance |
| `MortgageInterest` | `*float64` | Optional | Box 16a, Mortgage interest |
| `OtherInterest` | `*float64` | Optional | Box 16b, Other interest |
| `Legal` | `*float64` | Optional | Box 17, Legal and professional services |
| `Office` | `*float64` | Optional | Box 18, Office expense |
| `Pension` | `*float64` | Optional | Box 19, Pension and profit-sharing plans |
| `EquipmentRent` | `*float64` | Optional | Box 20a, Equipment rent |
| `OtherRent` | `*float64` | Optional | Box 20b, Other rent |
| `Repairs` | `*float64` | Optional | Box 21, Repairs and maintenance |
| `Supplies` | `*float64` | Optional | Box 22, Supplies |
| `Taxes` | `*float64` | Optional | Box 23, Taxes and licenses |
| `Travel` | `*float64` | Optional | Box 24a, Travel |
| `Meals` | `*float64` | Optional | Box 24b, Deductible meals |
| `Utilities` | `*float64` | Optional | Box 25, Utilities |
| `Wages` | `*float64` | Optional | Box 26, Wages |
| `OtherExpenses` | [`[]models.DescriptionAndAmount`](../../doc/models/description-and-amount.md) | Optional | Box 27, Other expenses |
| `BeginningInventory` | `*float64` | Optional | Box 35, Inventory at beginning of year |
| `Purchases` | `*float64` | Optional | Box 36, Purchases |
| `CostOfLabor` | `*float64` | Optional | Box 37, Cost of labor |
| `Materials` | `*float64` | Optional | Box 38, Materials and supplies |
| `OtherCosts` | [`[]models.DescriptionAndAmount`](../../doc/models/description-and-amount.md) | Optional | Box 39, Other costs |
| `EndingInventory` | `*float64` | Optional | Box 41, Inventory at end of year |
| `CapitalExpenditures` | [`[]models.DateAndAmount`](../../doc/models/date-and-amount.md) | Optional | Capital expenditures, for use in calculating Depreciation |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId0",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

