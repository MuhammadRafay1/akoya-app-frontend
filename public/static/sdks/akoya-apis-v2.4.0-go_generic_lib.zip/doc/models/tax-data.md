
# Tax Data

Tax data container for API requests and responses

*This model accepts additional fields of type interface{}.*

## Structure

`TaxData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessIncomeStatement` | [`*models.BusinessIncomeStatement`](../../doc/models/business-income-statement.md) | Optional | Business Income Statement for IRS Form 1040 Schedule C |
| `CryptocurrencyTaxStatement` | [`*models.CryptocurrencyTaxStatementList1`](../../doc/models/cryptocurrency-tax-statement-list-1.md) | Optional | Cryptocurrency Tax Statement list |
| `FarmIncomeStatement` | [`*models.FarmIncomeStatement`](../../doc/models/farm-income-statement.md) | Optional | Farm Income Statement for IRS Form 1040 Schedule F |
| `FarmRentalIncomeStatement` | [`*models.FarmRentalIncomeStatement`](../../doc/models/farm-rental-income-statement.md) | Optional | Farm Rental Income Statement for IRS Form 4835 |
| `RentalIncomeStatement` | [`*models.RentalIncomeStatement`](../../doc/models/rental-income-statement.md) | Optional | Rental Income Statement for IRS Form 1040 Schedule E |
| `RoyaltyIncomeStatement` | [`*models.RoyaltyIncomeStatement`](../../doc/models/royalty-income-statement.md) | Optional | Royalty Income Statement for IRS Form 1040 Schedule E |
| `Tax1041K1` | [`*models.Form1041K12`](../../doc/models/form-1041-k12.md) | Optional | Beneficiary's Share of Income, Deductions, Credits, etc. |
| `Tax1042S` | [`*models.Form1042S2`](../../doc/models/form-1042-s2.md) | Optional | Foreign Person's U.S. Source Income Subject to Withholding |
| `Tax1065K1` | [`*models.Form1065K12`](../../doc/models/form-1065-k12.md) | Optional | Partner's Share of Income, Deductions, Credits, etc. |
| `Tax1095A` | [`*models.Form1095A2`](../../doc/models/form-1095-a2.md) | Optional | Health Insurance Marketplace Statement |
| `Tax1095B` | [`*models.Form1095B2`](../../doc/models/form-1095-b2.md) | Optional | Health Coverage |
| `Tax1095C` | [`*models.Form1095C2`](../../doc/models/form-1095-c2.md) | Optional | Employer-Provided Health Insurance Offer and Coverage |
| `Tax1097Btc` | [`*models.Form1097Btc2`](../../doc/models/form-1097-btc-2.md) | Optional | Bond Tax Credit |
| `Tax1098` | [`*models.Form10982`](../../doc/models/form-10982.md) | Optional | Mortgage Interest Statement |
| `Tax1098C` | [`*models.Form1098C2`](../../doc/models/form-1098-c2.md) | Optional | Contributions of Motor Vehicles, Boats, and Airplanes |
| `Tax1098E` | [`*models.Form1098E2`](../../doc/models/form-1098-e2.md) | Optional | Student Loan Interest Statement |
| `Tax1098Ma` | [`*models.Form1098Ma2`](../../doc/models/form-1098-ma-2.md) | Optional | Mortgage Assistance Payments |
| `Tax1098Q` | [`*models.Form1098Q2`](../../doc/models/form-1098-q2.md) | Optional | Qualifying Longevity Annuity Contract Information |
| `Tax1098T` | [`*models.Form1098T2`](../../doc/models/form-1098-t2.md) | Optional | Tuition Statement |
| `Tax1099A` | [`*models.Form1099A2`](../../doc/models/form-1099-a2.md) | Optional | Acquisition or Abandonment of Secured Property |
| `Tax1099B` | [`*models.Form1099B2`](../../doc/models/form-1099-b2.md) | Optional | Proceeds From Broker and Barter Exchange Transactions |
| `Tax1099C` | [`*models.Form1099C2`](../../doc/models/form-1099-c2.md) | Optional | Cancellation of Debt |
| `Tax1099Cap` | [`*models.Form1099Cap2`](../../doc/models/form-1099-cap-2.md) | Optional | Changes in Corporate Control and Capital Structure |
| `Tax1099ConsolidatedStatement` | [`*models.Form1099ConsolidatedStatement2`](../../doc/models/form-1099-consolidated-statement-2.md) | Optional | Consolidated Statement for combined IRS Form 1099s |
| `Tax1099Div` | [`*models.Form1099Div2`](../../doc/models/form-1099-div-2.md) | Optional | Dividends and Distributions |
| `Tax1099G` | [`*models.Form1099G2`](../../doc/models/form-1099-g2.md) | Optional | Certain Government Payments |
| `Tax1099H` | [`*models.Form1099H2`](../../doc/models/form-1099-h2.md) | Optional | Health Coverage Tax Credit (HCTC) Advance Payments |
| `Tax1099Int` | [`*models.Form1099Int2`](../../doc/models/form-1099-int-2.md) | Optional | Interest Income |
| `Tax1099K` | [`*models.Form1099K2`](../../doc/models/form-1099-k2.md) | Optional | Merchant Card and Third-Party Network Payments |
| `Tax1099Ls` | [`*models.Form1099Ls2`](../../doc/models/form-1099-ls-2.md) | Optional | Reportable Life Insurance Sale |
| `Tax1099Ltc` | [`*models.Form1099Ltc2`](../../doc/models/form-1099-ltc-2.md) | Optional | Long-Term Care and Accelerated Death Benefits |
| `Tax1099Misc` | [`*models.Form1099Misc2`](../../doc/models/form-1099-misc-2.md) | Optional | Miscellaneous Income |
| `Tax1099Nec` | [`*models.Form1099Nec2`](../../doc/models/form-1099-nec-2.md) | Optional | Nonemployee Compensation |
| `Tax1099Oid` | [`*models.Form1099Oid2`](../../doc/models/form-1099-oid-2.md) | Optional | Original Issue Discount |
| `Tax1099Patr` | [`*models.Form1099Patr2`](../../doc/models/form-1099-patr-2.md) | Optional | Taxable Distributions Received From Cooperatives |
| `Tax1099Q` | [`*models.Form1099Q2`](../../doc/models/form-1099-q2.md) | Optional | Payments From Qualified Education Programs |
| `Tax1099Qa` | [`*models.Form1099Qa2`](../../doc/models/form-1099-qa-2.md) | Optional | Distributions From ABLE Accounts |
| `Tax1099R` | [`*models.Form1099R2`](../../doc/models/form-1099-r2.md) | Optional | Distributions from Pensions, Annuities, Retirement or Profit-Sharing Plans, IRAs, Insurance Contracts, etc. |
| `Tax1099S` | [`*models.Form1099S2`](../../doc/models/form-1099-s2.md) | Optional | Proceeds From Real Estate Transactions |
| `Tax1099Sa` | [`*models.Form1099Sa2`](../../doc/models/form-1099-sa-2.md) | Optional | Distributions From an HSA, Archer MSA, or Medicare Advantage MSA |
| `Tax1099Sb` | [`*models.Form1099Sb2`](../../doc/models/form-1099-sb-2.md) | Optional | Seller's Investment in Life Insurance Contract |
| `Tax1120Sk1` | [`*models.Form1120SK12`](../../doc/models/form-1120-sk12.md) | Optional | Shareholder's Share of Income, Deductions, Credits, etc. |
| `Tax2439` | [`*models.Form24392`](../../doc/models/form-24392.md) | Optional | Notice to Shareholder of Undistributed Long-Term Capital Gains |
| `Tax3921` | [`*models.Form39212`](../../doc/models/form-39212.md) | Optional | Exercise of an Incentive Stock Option Under Section 422(b) |
| `Tax3922` | [`*models.Form39222`](../../doc/models/form-39222.md) | Optional | Transfer of Stock Acquired Through an Employee Stock Purchase Plan under Section 423(c) |
| `Tax5227K1` | [`*models.Form1041K1`](../../doc/models/form-1041-k1.md) | Optional | Split-Interest Trust Beneficiary's schedule K-1 |
| `Tax5498` | [`*models.Form54982`](../../doc/models/form-54982.md) | Optional | IRA Contribution Information |
| `Tax5498Esa` | [`*models.Form5498Esa2`](../../doc/models/form-5498-esa-2.md) | Optional | Coverdell ESA Contribution Information |
| `Tax5498Qa` | [`*models.Form5498Qa2`](../../doc/models/form-5498-qa-2.md) | Optional | ABLE Account Contribution Information |
| `Tax5498Sa` | [`*models.Form5498Sa2`](../../doc/models/form-5498-sa-2.md) | Optional | HSA, Archer MSA, or Medicare Advantage MSA Information |
| `TaxW2` | [`*models.FormW24`](../../doc/models/form-w24.md) | Optional | Wage and Tax Statement |
| `TaxW2C` | [`*models.FormW2C2`](../../doc/models/form-w2-c2.md) | Optional | IRS form W-2c, Corrected Wage and Tax Statement |
| `TaxW2G` | [`*models.FormW2G2`](../../doc/models/form-w2-g2.md) | Optional | Certain Gambling Winnings |
| `TaxRefundDirectDeposit` | [`*models.TaxRefundDirectDeposit2`](../../doc/models/tax-refund-direct-deposit-2.md) | Optional | Tax refund direct deposit information |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "businessIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId4",
    "taxFormId": "taxFormId2",
    "taxFormDate": "2016-03-13T12:52:32.123Z",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "cryptocurrencyTaxStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId2",
    "taxFormId": "taxFormId0",
    "taxFormDate": "2016-03-13T12:52:32.123Z",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "farmIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId4",
    "taxFormId": "taxFormId2",
    "taxFormDate": "2016-03-13T12:52:32.123Z",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "farmRentalIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId8",
    "taxFormId": "taxFormId6",
    "taxFormDate": "2016-03-13T12:52:32.123Z",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "rentalIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId8",
    "taxFormId": "taxFormId6",
    "taxFormDate": "2016-03-13T12:52:32.123Z",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

