
# Accept Media Type

## Enumeration

`AcceptMediaType`

## Fields

| Name |
|  --- |
| `EnumApplicationjson` |
| `EnumApplicationpdf` |

