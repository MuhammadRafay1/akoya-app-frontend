
# Transaction Type

DepositTransaction Type

## Enumeration

`TransactionType`

## Fields

| Name |
|  --- |
| `Check` |
| `Withdrawal` |
| `Transfer` |
| `Posdebit` |
| `Atmwithdrawal` |
| `Billpayment` |
| `Fee` |
| `Deposit` |
| `Adjustment` |
| `Interest` |
| `Dividend` |
| `Directdeposit` |
| `Atmdeposit` |
| `Poscredit` |

