
# Inv 401 K Surce

Source for money for this security.

## Enumeration

`Inv401KSurce`

## Fields

| Name |
|  --- |
| `Pretax` |
| `Aftertax` |
| `Match` |
| `Profitsharing` |
| `Rollover` |
| `Othervest` |
| `Othernonvest` |

