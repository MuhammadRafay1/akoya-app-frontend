
# State Tax Withholding

Income in a state and its tax withholding

*This model accepts additional fields of type interface{}.*

## Structure

`StateTaxWithholding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxWithheld` | `*float64` | Optional | Amount of state income tax withheld |
| `TaxId` | `*string` | Optional | Filer's state tax id |
| `Income` | `*float64` | Optional | Income amount for state tax purposes |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 48.38,
  "taxId": "taxId0",
  "income": 15.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

