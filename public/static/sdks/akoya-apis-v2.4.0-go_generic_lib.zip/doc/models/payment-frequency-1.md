
# Payment Frequency 1

## Enumeration

`PaymentFrequency1`

## Fields

| Name |
|  --- |
| `Annually` |
| `Quarterly` |
| `Monthly` |
| `Weekly` |

