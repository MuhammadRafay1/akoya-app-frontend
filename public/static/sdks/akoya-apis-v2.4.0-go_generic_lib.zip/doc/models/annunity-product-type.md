
# Annunity Product Type

## Enumeration

`AnnunityProductType`

## Fields

| Name |
|  --- |
| `Currency` |
| `Shares` |

