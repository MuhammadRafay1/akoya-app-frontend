
# Interaction Type

## Enumeration

`InteractionType`

## Fields

| Name |
|  --- |
| `User` |
| `Batch` |

