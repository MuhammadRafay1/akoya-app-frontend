
# Tax Form Attribute

An additional tax form attribute for use when a defined field is not available

*This model accepts additional fields of type interface{}.*

## Structure

`TaxFormAttribute`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `*string` | Optional | Name of attribute |
| `Value` | `*string` | Optional | Value of attribute |
| `BoxNumber` | `*string` | Optional | Box number on a tax form, if any |
| `Code` | `*string` | Optional | Tax form code for the given box number, if any |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4",
  "boxNumber": "boxNumber0",
  "code": "code0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

