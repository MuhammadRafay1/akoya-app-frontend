
# Holding Type

## Enumeration

`HoldingType`

## Fields

| Name |
|  --- |
| `Stock` |
| `Bond` |
| `Mutualfund` |
| `Cd` |
| `Annuity` |
| `Option` |
| `Other` |

