
# Coverage Month 1

Month of coverage

## Enumeration

`CoverageMonth1`

## Fields

| Name |
|  --- |
| `Annual` |
| `January` |
| `February` |
| `March` |
| `April` |
| `May` |
| `June` |
| `July` |
| `August` |
| `September` |
| `October` |
| `November` |
| `December` |

