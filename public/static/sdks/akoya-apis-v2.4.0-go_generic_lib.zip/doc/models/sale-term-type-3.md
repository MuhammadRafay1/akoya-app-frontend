
# Sale Term Type 3

LONG or SHORT (1099-B box 2)

## Enumeration

`SaleTermType3`

## Fields

| Name |
|  --- |
| `Long` |
| `Short` |

