
# Unit Type

Type of unit.

## Enumeration

`UnitType`

## Fields

| Name |
|  --- |
| `Currency` |
| `Shares` |

