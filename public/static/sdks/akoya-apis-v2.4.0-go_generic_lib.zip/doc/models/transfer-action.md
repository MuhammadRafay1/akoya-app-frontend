
# Transfer Action

Transfer direction.

## Enumeration

`TransferAction`

## Fields

| Name |
|  --- |
| `In` |
| `Out` |

