
# Investment Balance List

*This model accepts additional fields of type interface{}.*

## Structure

`InvestmentBalanceList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceName` | `*string` | Optional | Name of the balance. |
| `BalanceDescription` | `*string` | Optional | Description of balance. |
| `BalanceType` | [`*models.BalanceType1`](../../doc/models/balance-type-1.md) | Optional | The type of an investment balance. AMOUNT or PERCENTAGE. |
| `BalanceValue` | `*float64` | Optional | Value of balance name. |
| `BalanceDate` | `*time.Time` | Optional | Date as of this balance. |
| `Currency` | [`*models.CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "balanceName": "balanceName0",
  "balanceDescription": "balanceDescription6",
  "balanceType": "AMOUNT",
  "balanceValue": 220.9,
  "balanceDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

