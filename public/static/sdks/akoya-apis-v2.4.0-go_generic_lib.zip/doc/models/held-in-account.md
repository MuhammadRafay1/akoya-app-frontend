
# Held in Account

Sub-account

## Enumeration

`HeldInAccount`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `Short` |
| `Other` |

