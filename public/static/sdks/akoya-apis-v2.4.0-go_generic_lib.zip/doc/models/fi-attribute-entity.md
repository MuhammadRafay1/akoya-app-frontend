
# Fi Attribute Entity

Data provider-specific attribute

*This model accepts additional fields of type interface{}.*

## Structure

`FiAttributeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `*string` | Optional | Name of attribute |
| `Value` | `*string` | Optional | Value of attribute |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name6",
  "value": "value8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

