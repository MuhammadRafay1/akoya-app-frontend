
# Account Holder Relationship

Types of relationships between accounts and holders. Suggested values

## Enumeration

`AccountHolderRelationship`

## Fields

| Name |
|  --- |
| `AuthorizedUser` |
| `Business` |
| `ForBenefitOf` |
| `ForBenefitOfPrimary` |
| `ForBenefitOfPrimaryJointRestricted` |
| `ForBenefitOfSecondary` |
| `ForBenefitOfSecondaryJointRestricted` |
| `ForBenefitOfSoleOwnerRestricted` |
| `PowerOfAttorney` |
| `PrimaryJointTenants` |
| `Primary` |
| `PrimaryBorrower` |
| `PrimaryJoint` |
| `Secondary` |
| `SecondaryJointTenants` |
| `SecondaryBorrower` |
| `SecondaryJoint` |
| `SoleOwner` |
| `Trustee` |
| `UniformTransferToMinor` |

