
# Taxlots Response

*This model accepts additional fields of type interface{}.*

## Structure

`TaxlotsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `*string` | Optional | Corresponds to AccountId in Account |
| `Holding` | [`*models.Holding`](../../doc/models/holding.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId6",
  "holding": {
    "holdingId": "holdingId0",
    "securityId": "securityId2",
    "securityIdType": "VALOR",
    "taxLots": [
      {
        "costBasis": 131.38,
        "currentValue": 199.34,
        "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
        "positionType": "LONG",
        "purchasedPrice": 176.16,
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "costBasis": 131.38,
        "currentValue": 199.34,
        "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
        "positionType": "LONG",
        "purchasedPrice": 176.16,
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "costBasis": 131.38,
        "currentValue": 199.34,
        "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
        "positionType": "LONG",
        "purchasedPrice": 176.16,
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

