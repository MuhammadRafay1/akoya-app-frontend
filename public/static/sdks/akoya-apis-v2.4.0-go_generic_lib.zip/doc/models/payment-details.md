
# Payment Details

Payment details for some transactions

*This model accepts additional fields of type interface{}.*

## Structure

`PaymentDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EscrowAmount` | `*float64` | Optional | The amount of payment applied to escrow |
| `FeesAmount` | `*float64` | Optional | The amount of payment applied to fees |
| `InsuranceAmount` | `*float64` | Optional | The amount of payment applied to life/health/accident insurance on the loan |
| `InterestAmount` | `*float64` | Optional | The amount of payment applied to interest |
| `PmiAmount` | `*float64` | Optional | The amount of payment applied to PMI |
| `PrincipalAmount` | `*float64` | Optional | The amount of payment applied to principal |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "escrowAmount": 171.3,
  "feesAmount": 83.52,
  "insuranceAmount": 63.4,
  "interestAmount": 64.72,
  "pmiAmount": 217.98,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

