
# Local Tax Withholding 1

Amount of local income tax withheld, if any

*This model accepts additional fields of type interface{}.*

## Structure

`LocalTaxWithholding1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxWithheld` | `*float64` | Optional | Amount of local income tax withheld |
| `LocalityName` | `*string` | Optional | Locality name |
| `Income` | `*float64` | Optional | Income amount for local tax purposes |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 15.4,
  "localityName": "localityName2",
  "income": 207.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

