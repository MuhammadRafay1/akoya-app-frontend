
# Asset Class 1

## Enumeration

`AssetClass1`

## Fields

| Name |
|  --- |
| `Domesticbond` |
| `Intlbond` |
| `Largestock` |
| `Smallstock` |
| `Intlstock` |
| `Moneymarket` |
| `Other` |

