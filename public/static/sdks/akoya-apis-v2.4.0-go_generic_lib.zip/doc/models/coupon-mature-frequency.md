
# Coupon Mature Frequency

When coupons mature

## Enumeration

`CouponMatureFrequency`

## Fields

| Name |
|  --- |
| `Monthly` |
| `Quarterly` |
| `Semiannual` |
| `Annual` |
| `Other` |

