
# Option Type

## Enumeration

`OptionType`

## Fields

| Name |
|  --- |
| `Call` |
| `Put` |

