
# Name Address and Phone 1

Acquirer's information contact name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone no. (If different from ACQUIRER)

*This model accepts additional fields of type interface{}.*

## Structure

`NameAddressAndPhone1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Line1` | `*string` | Optional | Address line 1 |
| `Line2` | `*string` | Optional | Address line 2 |
| `Line3` | `*string` | Optional | Address line 3 |
| `City` | `*string` | Optional | City |
| `Region` | `*string` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode' |
| `PostalCode` | `*string` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` |
| `Country` | [`*models.Iso3166CountryCode2`](../../doc/models/iso-3166-country-code-2.md) | Optional | Country code |
| `Name1` | `*string` | Optional | Name line 1 |
| `Name2` | `*string` | Optional | Name line 2 |
| `Phone` | [`*models.TelephoneNumberPlusExtension1`](../../doc/models/telephone-number-plus-extension-1.md) | Optional | Phone number |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "line1": "line16",
  "line2": "line28",
  "line3": "line36",
  "city": "city4",
  "region": "region0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

