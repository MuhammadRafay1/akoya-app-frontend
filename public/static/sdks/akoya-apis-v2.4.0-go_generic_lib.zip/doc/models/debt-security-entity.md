
# Debt Security Entity

Information about the debt security specific to the type of security

*This model accepts additional fields of type interface{}.*

## Structure

`DebtSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParValue` | `*float64` | Optional | Par value amount |
| `DebtType` | [`*models.DebtType`](../../doc/models/debt-type.md) | Optional | Debt type |
| `DebtClass` | [`*models.DebtClass`](../../doc/models/debt-class.md) | Optional | Classification of debt |
| `CouponRate` | `*float64` | Optional | Bond coupon rate for next closest call date |
| `CouponDate` | `*time.Time` | Optional | Maturity date for next coupon |
| `CouponMatureFrequency` | [`*models.CouponMatureFrequency`](../../doc/models/coupon-mature-frequency.md) | Optional | When coupons mature |
| `CallPrice` | `*float64` | Optional | Bond call price |
| `YieldToCall` | `*float64` | Optional | Yield to next call |
| `CallDate` | `*time.Time` | Optional | Next call date |
| `CallType` | [`*models.CallType`](../../doc/models/call-type.md) | Optional | Type of next call |
| `YieldToMaturity` | `*float64` | Optional | Yield to maturity |
| `BondMaturityDate` | `*time.Time` | Optional | Bond Maturity date |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "parValue": 18.14,
  "debtType": "ASSET",
  "debtClass": "CORPORATE",
  "couponRate": 229.02,
  "couponDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

