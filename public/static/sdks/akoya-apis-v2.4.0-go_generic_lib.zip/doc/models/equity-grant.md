
# Equity Grant

*This model accepts additional fields of type interface{}.*

## Structure

`EquityGrant`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GrantId` | `*string` | Optional | Unique identifier of grant |
| `GrantDate` | `*time.Time` | Optional | Date grant was given |
| `GrantType` | `*string` | Optional | Type of grant |
| `SeqNum` | `*float64` | Optional | - |
| `GrantPrice` | `*float64` | Optional | Grant price |
| `GrantCurrencyCode` | `*string` | Optional | Indicates the currency of grant USD vs AUD vs EUR etc (for share awards, you will still get a USD) |
| `QuantityGranted` | `*float64` | Optional | Number of options |
| `QuantityOutstanding` | `*float64` | Optional | - |
| `ExpirationDate` | `*time.Time` | Optional | Date grant expires |
| `Vestings` | [`[]models.Vesting`](../../doc/models/vesting.md) | Optional | An array of equityGrant vestings. Provides the past, present, and future vesting schedule and percentages. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "grantId": "grantId0",
  "grantDate": "2016-03-13T12:52:32.123Z",
  "grantType": "grantType0",
  "seqNum": 174.64,
  "grantPrice": 12.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

