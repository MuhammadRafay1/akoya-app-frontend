
# Individual Name 3

Box g, Employee's previously reported name

*This model accepts additional fields of type interface{}.*

## Structure

`IndividualName3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `First` | `*string` | Optional | First name |
| `Middle` | `*string` | Optional | Middle initial |
| `Last` | `*string` | Optional | Last name |
| `Suffix` | `*string` | Optional | Generational or academic suffix |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first8",
  "middle": "middle8",
  "last": "last8",
  "suffix": "suffix8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

