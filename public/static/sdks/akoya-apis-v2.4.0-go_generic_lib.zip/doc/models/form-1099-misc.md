
# Form 1099 Misc

Miscellaneous Income, from PAYER (1st-2nd boxes as issuer) to RECIPIENT (3rd-4th boxes)

*This model accepts additional fields of type interface{}.*

## Structure

`Form1099Misc`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxYear` | `*int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `Corrected` | `*bool` | Optional | True to indicate this is a corrected tax form |
| `AccountId` | `*string` | Optional | Long-term persistent identity of the source account. Not the account number |
| `TaxFormId` | `*string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. |
| `TaxFormDate` | `*time.Time` | Optional | Date of production or delivery of the tax form |
| `AdditionalInformation` | `*string` | Optional | Additional explanation text or content about this tax form |
| `TaxFormType` | [`*models.TypeFormType2`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `Issuer` | [`*models.TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Recipient` | [`*models.TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Attributes` | [`[]models.TaxFormAttribute`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. |
| `Error` | [`*models.Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form |
| `Links` | [`[]models.HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs |
| `AccountNumber` | `*string` | Optional | Account number |
| `Rents` | `*float64` | Optional | Box 1, Rents |
| `Royalties` | `*float64` | Optional | Box 2, Royalties |
| `OtherIncome` | `*float64` | Optional | Box 3, Other income |
| `FederalTaxWithheld` | `*float64` | Optional | Box 4, Federal income tax withheld |
| `FishingBoatProceeds` | `*float64` | Optional | Box 5, Fishing boat proceeds |
| `MedicalHealthPayment` | `*float64` | Optional | Box 6, Medical and health care payments |
| `PayerDirectSales` | `*bool` | Optional | Box 7, Payer made direct sales of $5,000 or more of consumer products to a buyer (recipient) for resale |
| `SubstitutePayments` | `*float64` | Optional | Box 8, Substitute payments in lieu of dividends or interest |
| `CropInsurance` | `*float64` | Optional | Box 9, Crop insurance proceeds |
| `SecondTinNotice` | `*bool` | Optional | Second TIN Notice |
| `GrossAttorney` | `*float64` | Optional | Box 10, Gross proceeds paid to an attorney |
| `FishPurchased` | `*float64` | Optional | Box 11, Fish purchased for resale |
| `Section409ADeferrals` | `*float64` | Optional | Box 12, Section 409A deferrals |
| `ForeignAccountTaxCompliance` | `*bool` | Optional | Box 13, FATCA filing requirement |
| `ExcessGolden` | `*float64` | Optional | Box 14, Excess golden parachute payments |
| `NonQualifiedDeferredCompensation` | `*float64` | Optional | Box 15, Nonqualified Deferred Compensation |
| `StateAndLocal` | [`[]models.StateAndLocalTaxWithholding`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 16-18, State and Local tax withholding |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId4",
  "taxFormId": "taxFormId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

