
# Investment Account With All Details

Data elements included with the investment product

*This model accepts additional fields of type interface{}.*

## Structure

`InvestmentAccountWithAllDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `*string` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. |
| `AccountType` | `*string` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. |
| `AccountNumberDisplay` | `*string` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. |
| `Currency` | [`*models.CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. |
| `Description` | `*string` | Optional | - |
| `FiAttributes` | [`[]models.FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | - |
| `Nickname` | `*string` | Optional | Name given by the user. Used in UIs to assist in account selection |
| `ProductName` | `*string` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection |
| `Status` | [`*models.Status`](../../doc/models/status.md) | Optional | The status of an account. |
| `LineOfBusiness` | `*string` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. |
| `BalanceType` | [`*models.BalanceType`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) |
| `InterestRate` | `*float64` | Optional | Interest Rate of Account |
| `InterestRateType` | [`*models.InterestRateType`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. |
| `InterestRateAsOf` | `*time.Time` | Optional | Date of account’s interest rate |
| `LastActivityDate` | `*time.Time` | Optional | Date that last transaction occurred on account |
| `MicrNumber` | `*string` | Optional | MICR Number |
| `ParentAccountId` | `*string` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. |
| `PriorInterestRate` | `*float64` | Optional | Previous Interest Rate of Account |
| `TransferIn` | `*bool` | Optional | Account is eligible for incoming transfers |
| `TransferOut` | `*bool` | Optional | Account is eligible for outgoing transfers |
| `AllowedCheckWriting` | `*bool` | Optional | Check writing privileges |
| `AllowedOptionTrade` | `*bool` | Optional | Allowed to trade options |
| `BrokerId` | `*string` | Optional | Unique identifier FI |
| `CalendarYearFor401K` | `*string` | Optional | Date for this calendar year for 401K account |
| `EmployerName` | `*string` | Optional | Name of the employer in investment 401k Plan |
| `Margin` | `*bool` | Optional | Margin trading is allowed |
| `PlanId` | `*string` | Optional | Plan number for Investment 401k plan |
| `AvailableCashBalance` | `*float64` | Optional | Cash balance across all sub-accounts. Should include sweep funds. |
| `BalanceAsOf` | `*time.Time` | Optional | As-of date of balances |
| `BalanceList` | [`[]models.InvestmentBalanceList`](../../doc/models/investment-balance-list.md) | Optional | Balance List. Name value pair aggregate. |
| `CurrentValue` | `*float64` | Optional | Total current value of all investments |
| `DailyChange` | `*float64` | Optional | Daily change |
| `MarginBalance` | `*float64` | Optional | Margin balance |
| `PercentageChange` | `*float64` | Optional | Percentage change |
| `RolloverAmount` | `*float64` | Optional | Rollover amount |
| `ShortBalance` | `*float64` | Optional | Short balance |
| `Holdings` | [`[]models.AnInvestmentHolding`](../../doc/models/an-investment-holding.md) | Optional | Array of holdings |
| `OpenOrders` | [`[]models.OpenOrderEntity`](../../doc/models/open-order-entity.md) | Optional | Array of open orders |
| `Contribution` | [`[]models.ContributionEntity`](../../doc/models/contribution-entity.md) | Optional | Array of contribution objects. Describes how new contributions are distributed among the available securities |
| `Vesting` | [`[]models.VestingEntity`](../../doc/models/vesting-entity.md) | Optional | Array of vesting objects. Provides the past, present, and future vesting schedule and percentages |
| `InvestmentLoans` | [`[]models.InvestmentLoanEntity`](../../doc/models/investment-loan-entity.md) | Optional | Array of investment loans |
| `PensionSource` | [`[]models.PensionSourceEntity`](../../doc/models/pension-source-entity.md) | Optional | Array of Pension Source |
| `EquityGrants` | [`[]models.EquityGrant`](../../doc/models/equity-grant.md) | Optional | Provides equity grant information on Restricted Stock Units, Restricted Stock Awards, Stock Appreciation Right, Stock Options, Performance Awards, and Total Share Return Units |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId2",
  "accountType": "accountType2",
  "accountNumberDisplay": "accountNumberDisplay8",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

