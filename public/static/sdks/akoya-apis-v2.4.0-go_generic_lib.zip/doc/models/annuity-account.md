
# Annuity Account

Annuity Account

*This model accepts additional fields of type interface{}.*

## Structure

`AnnuityAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `*string` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. |
| `AccountType` | `*string` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. |
| `AccountNumberDisplay` | `*string` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. |
| `Currency` | [`*models.CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. |
| `Description` | `*string` | Optional | - |
| `FiAttributes` | [`[]models.FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | - |
| `Nickname` | `*string` | Optional | Name given by the user. Used in UIs to assist in account selection |
| `ProductName` | `*string` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection |
| `Status` | [`*models.Status`](../../doc/models/status.md) | Optional | The status of an account. |
| `LineOfBusiness` | `*string` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. |
| `BalanceType` | [`*models.BalanceType`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) |
| `InterestRate` | `*float64` | Optional | Interest Rate of Account |
| `InterestRateType` | [`*models.InterestRateType`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. |
| `InterestRateAsOf` | `*time.Time` | Optional | Date of account’s interest rate |
| `LastActivityDate` | `*time.Time` | Optional | Date that last transaction occurred on account |
| `MicrNumber` | `*string` | Optional | MICR Number |
| `ParentAccountId` | `*string` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. |
| `PriorInterestRate` | `*float64` | Optional | Previous Interest Rate of Account |
| `TransferIn` | `*bool` | Optional | Account is eligible for incoming transfers |
| `TransferOut` | `*bool` | Optional | Account is eligible for outgoing transfers |
| `AnnuityProductType` | [`*models.AnnunityProductType`](../../doc/models/annunity-product-type.md) | Optional | - |
| `AnnuityValueBasis` | [`*models.AnnunityValueBasis`](../../doc/models/annunity-value-basis.md) | Optional | - |
| `PaymentFrequency` | [`*models.PaymentFrequency1`](../../doc/models/payment-frequency-1.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId8",
  "accountType": "accountType8",
  "accountNumberDisplay": "accountNumberDisplay4",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

