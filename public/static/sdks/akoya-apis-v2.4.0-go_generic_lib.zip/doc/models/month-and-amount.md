
# Month and Amount

Month and amount pair used on IRS Form 1099-K, etc.

*This model accepts additional fields of type interface{}.*

## Structure

`MonthAndAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | [`*models.MonthAbbreviation1`](../../doc/models/month-abbreviation-1.md) | Optional | Month |
| `Amount` | `*float64` | Optional | Amount |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "month": "SEP",
  "amount": 97.94,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

