
# Stock Security Entity

Information about the stock security specific to the type of security

*This model accepts additional fields of type interface{}.*

## Structure

`StockSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UnitsStreet` | `*float64` | Optional | Units in the FI's street name, positive quantity |
| `UnitsUser` | `*float64` | Optional | Units in user's name directly, positive  quantity |
| `ReinvestDividends` | `*bool` | Optional | Reinvest dividends |
| `StockType` | [`*models.StockType`](../../doc/models/stock-type.md) | Optional | - |
| `Yield` | `*float64` | Optional | Current yield |
| `YieldAsOfDate` | `*time.Time` | Optional | Yield as-of date |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "unitsStreet": 117.56,
  "unitsUser": 92.52,
  "reinvestDividends": false,
  "stockType": "STOCK",
  "yield": 211.18,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

