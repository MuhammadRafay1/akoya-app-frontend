
# Individual Name 4

Individual issuer or recipient name

*This model accepts additional fields of type interface{}.*

## Structure

`IndividualName4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `First` | `*string` | Optional | First name |
| `Middle` | `*string` | Optional | Middle initial |
| `Last` | `*string` | Optional | Last name |
| `Suffix` | `*string` | Optional | Generational or academic suffix |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first2",
  "middle": "middle2",
  "last": "last4",
  "suffix": "suffix6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

