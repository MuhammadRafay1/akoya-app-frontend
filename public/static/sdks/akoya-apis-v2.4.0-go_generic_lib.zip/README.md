
# Getting Started with Akoya APIs v2.4.0

## Introduction

Akoya product APIs for data access. Default servers are set for the Akoya sandbox environment.

Akoya APIs include the following updates:

- v2.4.0
  - Added Tax product
- v2.3.0
  - Removed erroneous `accountId` query param from Taxlots endpoint
  - Added TaxLots endpoint
- v2.2.2
  - Added mode query parameter to Account Information, Balances, Investments, and Transactions to support standard mode.
  - Edited callouts for Account Holder endpoint
- v2.2.1
  - Fixed typo in `accountIds` query parameter for `/accounts-info`, `/balances`, `/accounts`
  - Added security method for `Account holder information` to bear token. Missing method defaulted to basic auth.
  - Added examples and descriptions to some schemas
  - Added HTTP status `429` FDX error `1207`.
- v2.2 Additions
  - Added optional `x-akoya-interaction-type` header to all endpoints to specify if a request is part of a batch process
  - Update of tags to organize endpoints by Akoya product
  - `206` response added to `/accounts-info`, `/balances`, `/accounts`
- v2.1 New Statements product and Customers product updated with additional endpoint, `Account holder information`.
- v2.0 Launch of Akoya products: Account Info, Balances, Investments, Transactions, Payments, Customers.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the akoyaApIsV240 library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace akoyaApIsV240 => ".\\akoya-apis-v2.4.0-go_generic_lib" // local path to the SDK

require akoyaApIsV240 v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| basicAuthCredentials | [`BasicAuthCredentials`](doc/auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |
| bearerAuthCredentials | [`BearerAuthCredentials`](doc/auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| acgAuthCredentials | [`AcgAuthCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```go
package main

import (
    "akoyaApIsV240"
    "akoyaApIsV240/models"
)

func main() {
    client := akoyaApIsV240.NewClient(
    akoyaApIsV240.CreateConfiguration(
            akoyaApIsV240.WithHttpConfiguration(
                akoyaApIsV240.CreateHttpConfiguration(
                    akoyaApIsV240.WithTimeout(30),
                ),
            ),
            akoyaApIsV240.WithEnvironment(akoyaApIsV240.PRODUCTION),
            akoyaApIsV240.WithBasicAuthCredentials(
                akoyaApIsV240.NewBasicAuthCredentials(
                    "Username",
                    "Password",
                ),
            ),
            akoyaApIsV240.WithBearerAuthCredentials(
                akoyaApIsV240.NewBearerAuthCredentials("AccessToken"),
            ),
            akoyaApIsV240.WithAcgAuthCredentials(
                akoyaApIsV240.NewAcgAuthCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeAcgAuth{
        models.OauthScopeAcgAuth_Openid,
        models.OauthScopeAcgAuth_Profile,
    }),
            ),
            akoyaApIsV240.WithLoggerConfiguration(
                akoyaApIsV240.WithLevel("info"),
                akoyaApIsV240.WithRequestConfiguration(
                    akoyaApIsV240.WithRequestBody(true),
                ),
                akoyaApIsV240.WithResponseConfiguration(
                    akoyaApIsV240.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Sandbox server |
| environment2 | Products server |

## Authorization

This API uses the following authentication schemes.

* [`basicAuth (Basic Authentication)`](doc/auth/basic-authentication.md)
* [`bearerAuth (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)
* [`acgAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Accountinformation](doc/controllers/accountinformation.md)
* [Tax Beta](doc/controllers/tax-beta.md)
* [Balances](doc/controllers/balances.md)
* [Customers](doc/controllers/customers.md)
* [Investments](doc/controllers/investments.md)
* [Payments](doc/controllers/payments.md)
* [Statements](doc/controllers/statements.md)
* [Transactions](doc/controllers/transactions.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

