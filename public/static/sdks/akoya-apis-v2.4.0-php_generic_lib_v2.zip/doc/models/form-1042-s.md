
# Form 1042 S

Foreign Person's U.S. Source Income Subject to Withholding, from WithholdingAgent (boxes 12a-i) to Recipient (boxes 13a-j, 13l as form1042Recipient)

*This model accepts additional fields of type array.*

## Structure

`Form1042S`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxYear` | `?int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | getTaxYear(): ?int | setTaxYear(?int taxYear): void |
| `corrected` | `?bool` | Optional | True to indicate this is a corrected tax form | getCorrected(): ?bool | setCorrected(?bool corrected): void |
| `accountId` | `?string` | Optional | Long-term persistent identity of the source account. Not the account number | getAccountId(): ?string | setAccountId(?string accountId): void |
| `taxFormId` | `?string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | getTaxFormId(): ?string | setTaxFormId(?string taxFormId): void |
| `taxFormDate` | `?DateTime` | Optional | Date of production or delivery of the tax form | getTaxFormDate(): ?\DateTime | setTaxFormDate(?\DateTime taxFormDate): void |
| `additionalInformation` | `?string` | Optional | Additional explanation text or content about this tax form | getAdditionalInformation(): ?string | setAdditionalInformation(?string additionalInformation): void |
| `taxFormType` | [`?string(TypeFormType2)`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | getTaxFormType(): ?string | setTaxFormType(?string taxFormType): void |
| `issuer` | [`?TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getIssuer(): ?TaxParty8 | setIssuer(?TaxParty8 issuer): void |
| `recipient` | [`?TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getRecipient(): ?TaxParty1 | setRecipient(?TaxParty1 recipient): void |
| `attributes` | [`?(TaxFormAttribute[])`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | getAttributes(): ?array | setAttributes(?array attributes): void |
| `error` | [`?Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | getError(): ?Error2 | setError(?Error2 error): void |
| `links` | [`?(HateoasLink[])`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | getLinks(): ?array | setLinks(?array links): void |
| `formId` | `?string` | Optional | Unique form identifier | getFormId(): ?string | setFormId(?string formId): void |
| `amended` | `?bool` | Optional | Amended | getAmended(): ?bool | setAmended(?bool amended): void |
| `amendmentNumber` | `?int` | Optional | Amendment number | getAmendmentNumber(): ?int | setAmendmentNumber(?int amendmentNumber): void |
| `incomeTypeCode` | `?string` | Optional | Box 1, Income code | getIncomeTypeCode(): ?string | setIncomeTypeCode(?string incomeTypeCode): void |
| `grossIncome` | `?float` | Optional | Box 2, Gross income | getGrossIncome(): ?float | setGrossIncome(?float grossIncome): void |
| `chapterIndicator` | `?string` | Optional | Box 3, Chapter indicator | getChapterIndicator(): ?string | setChapterIndicator(?string chapterIndicator): void |
| `ch3ExemptionCode` | `?string` | Optional | Box 3a, Exemption code | getCh3ExemptionCode(): ?string | setCh3ExemptionCode(?string ch3ExemptionCode): void |
| `ch3TaxRate` | `?float` | Optional | Box 3b, Tax rate | getCh3TaxRate(): ?float | setCh3TaxRate(?float ch3TaxRate): void |
| `ch4ExemptionCode` | `?string` | Optional | Box 4a, Exemption code | getCh4ExemptionCode(): ?string | setCh4ExemptionCode(?string ch4ExemptionCode): void |
| `ch4TaxRate` | `?float` | Optional | Box 4b, Tax rate | getCh4TaxRate(): ?float | setCh4TaxRate(?float ch4TaxRate): void |
| `withholdingAllowance` | `?float` | Optional | Box 5, Withholding allowance | getWithholdingAllowance(): ?float | setWithholdingAllowance(?float withholdingAllowance): void |
| `netIncome` | `?float` | Optional | Box 6, Net income | getNetIncome(): ?float | setNetIncome(?float netIncome): void |
| `federalTaxWithheld` | `?float` | Optional | Box 7a, Federal tax withheld | getFederalTaxWithheld(): ?float | setFederalTaxWithheld(?float federalTaxWithheld): void |
| `escrowProceduresApplied` | `?bool` | Optional | Box 7b, Check if federal tax withheld was not deposited with the IRS because escrow procedures were applied | getEscrowProceduresApplied(): ?bool | setEscrowProceduresApplied(?bool escrowProceduresApplied): void |
| `subsequentYear` | `?bool` | Optional | Box 7c, Check if withholding occurred in subsequent year with respect to a partnership interest | getSubsequentYear(): ?bool | setSubsequentYear(?bool subsequentYear): void |
| `otherAgentsTaxWithheld` | `?float` | Optional | Box 8, Tax withheld by other agents | getOtherAgentsTaxWithheld(): ?float | setOtherAgentsTaxWithheld(?float otherAgentsTaxWithheld): void |
| `recipientRepaidAmount` | `?float` | Optional | Box 9, Overwithheld tax repaid to recipient pursuant to adjustment procedures | getRecipientRepaidAmount(): ?float | setRecipientRepaidAmount(?float recipientRepaidAmount): void |
| `totalTaxWithholdingCredit` | `?float` | Optional | Box 10, Total withholding credit | getTotalTaxWithholdingCredit(): ?float | setTotalTaxWithholdingCredit(?float totalTaxWithholdingCredit): void |
| `withholdingAgentTaxPaid` | `?float` | Optional | Box 11, Tax paid by withholding agent (amounts not withheld) | getWithholdingAgentTaxPaid(): ?float | setWithholdingAgentTaxPaid(?float withholdingAgentTaxPaid): void |
| `withholdingAgent` | [`?Form1042SAgent1`](../../doc/models/form-1042-s-agent-1.md) | Optional | Boxes 12a-i, Withholding agent | getWithholdingAgent(): ?Form1042SAgent1 | setWithholdingAgent(?Form1042SAgent1 withholdingAgent): void |
| `form1042Recipient` | [`?Form1042SRecipient1`](../../doc/models/form-1042-s-recipient-1.md) | Optional | Boxes 13a-j, 13l, Recipient for Form 1042-S | getForm1042Recipient(): ?Form1042SRecipient1 | setForm1042Recipient(?Form1042SRecipient1 form1042Recipient): void |
| `accountNumber` | `?string` | Optional | Box 13k, Recipient account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `primary` | [`?Form1042SAgent2`](../../doc/models/form-1042-s-agent-2.md) | Optional | Boxes 14a-b, Primary Withholding Agent | getPrimary(): ?Form1042SAgent2 | setPrimary(?Form1042SAgent2 primary): void |
| `prorataBasisReporting` | `?bool` | Optional | Box 15, Check if pro-rata basis reporting | getProrataBasisReporting(): ?bool | setProrataBasisReporting(?bool prorataBasisReporting): void |
| `intermediary` | [`?Form1042SAgent3`](../../doc/models/form-1042-s-agent-3.md) | Optional | Boxes 15a-i, Intermediary or flow thru entity | getIntermediary(): ?Form1042SAgent3 | setIntermediary(?Form1042SAgent3 intermediary): void |
| `payer` | [`?Form1042SAgent4`](../../doc/models/form-1042-s-agent-4.md) | Optional | Boxes 16a-e, Payer | getPayer(): ?Form1042SAgent4 | setPayer(?Form1042SAgent4 payer): void |
| `stateAndLocal` | [`?StateAndLocalTaxWithholding1`](../../doc/models/state-and-local-tax-withholding-1.md) | Optional | Box 17, State and Local tax withholding | getStateAndLocal(): ?StateAndLocalTaxWithholding1 | setStateAndLocal(?StateAndLocalTaxWithholding1 stateAndLocal): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId6",
  "taxFormId": "taxFormId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

