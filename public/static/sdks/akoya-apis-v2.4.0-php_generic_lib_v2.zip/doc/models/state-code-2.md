
# State Code 2

State two-digit code

## Enumeration

`StateCode2`

## Fields

| Name |
|  --- |
| `AA` |
| `AE` |
| `AK` |
| `AL` |
| `AP` |
| `AR` |
| `AS_` |
| `AZ` |
| `CA` |
| `CO` |
| `CT` |
| `DC` |
| `DE` |
| `FL` |
| `FM` |
| `GA` |
| `GU` |
| `HI` |
| `IA` |
| `ID` |
| `IL` |
| `IN` |
| `KS` |
| `KY` |
| `LA` |
| `MA` |
| `MD` |
| `ME` |
| `MH` |
| `MI` |
| `MN` |
| `MO` |
| `MP` |
| `MS` |
| `MT` |
| `NC` |
| `ND` |
| `NE` |
| `NH` |
| `NJ` |
| `NM` |
| `NV` |
| `NY` |
| `OH` |
| `OK` |
| `OR_` |
| `PA` |
| `PR` |
| `PW` |
| `RI` |
| `SC` |
| `SD` |
| `TN` |
| `TX` |
| `UT` |
| `VA` |
| `VI` |
| `VT` |
| `WA` |
| `WI` |
| `WV` |
| `WY` |

