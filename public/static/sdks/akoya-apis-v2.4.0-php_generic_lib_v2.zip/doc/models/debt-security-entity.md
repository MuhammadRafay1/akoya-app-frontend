
# Debt Security Entity

Information about the debt security specific to the type of security

*This model accepts additional fields of type array.*

## Structure

`DebtSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `parValue` | `?float` | Optional | Par value amount | getParValue(): ?float | setParValue(?float parValue): void |
| `debtType` | [`?string(DebtType)`](../../doc/models/debt-type.md) | Optional | Debt type | getDebtType(): ?string | setDebtType(?string debtType): void |
| `debtClass` | [`?string(DebtClass)`](../../doc/models/debt-class.md) | Optional | Classification of debt | getDebtClass(): ?string | setDebtClass(?string debtClass): void |
| `couponRate` | `?float` | Optional | Bond coupon rate for next closest call date | getCouponRate(): ?float | setCouponRate(?float couponRate): void |
| `couponDate` | `?DateTime` | Optional | Maturity date for next coupon | getCouponDate(): ?\DateTime | setCouponDate(?\DateTime couponDate): void |
| `couponMatureFrequency` | [`?string(CouponMatureFrequency)`](../../doc/models/coupon-mature-frequency.md) | Optional | When coupons mature | getCouponMatureFrequency(): ?string | setCouponMatureFrequency(?string couponMatureFrequency): void |
| `callPrice` | `?float` | Optional | Bond call price | getCallPrice(): ?float | setCallPrice(?float callPrice): void |
| `yieldToCall` | `?float` | Optional | Yield to next call | getYieldToCall(): ?float | setYieldToCall(?float yieldToCall): void |
| `callDate` | `?DateTime` | Optional | Next call date | getCallDate(): ?\DateTime | setCallDate(?\DateTime callDate): void |
| `callType` | [`?string(CallType)`](../../doc/models/call-type.md) | Optional | Type of next call | getCallType(): ?string | setCallType(?string callType): void |
| `yieldToMaturity` | `?float` | Optional | Yield to maturity | getYieldToMaturity(): ?float | setYieldToMaturity(?float yieldToMaturity): void |
| `bondMaturityDate` | `?DateTime` | Optional | Bond Maturity date | getBondMaturityDate(): ?\DateTime | setBondMaturityDate(?\DateTime bondMaturityDate): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "parValue": 18.14,
  "debtType": "ASSET",
  "debtClass": "CORPORATE",
  "couponRate": 229.02,
  "couponDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

