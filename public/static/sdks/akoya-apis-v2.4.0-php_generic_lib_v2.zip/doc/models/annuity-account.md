
# Annuity Account

Annuity Account

*This model accepts additional fields of type array.*

## Structure

`AnnuityAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountId` | `?string` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. | getAccountId(): ?string | setAccountId(?string accountId): void |
| `accountType` | `?string` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. | getAccountType(): ?string | setAccountType(?string accountType): void |
| `accountNumberDisplay` | `?string` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. | getAccountNumberDisplay(): ?string | setAccountNumberDisplay(?string accountNumberDisplay): void |
| `currency` | [`?CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | getCurrency(): ?CurrencyEntity | setCurrency(?CurrencyEntity currency): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `fiAttributes` | [`?(FiAttributeEntity[])`](../../doc/models/fi-attribute-entity.md) | Optional | - | getFiAttributes(): ?array | setFiAttributes(?array fiAttributes): void |
| `nickname` | `?string` | Optional | Name given by the user. Used in UIs to assist in account selection | getNickname(): ?string | setNickname(?string nickname): void |
| `productName` | `?string` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection | getProductName(): ?string | setProductName(?string productName): void |
| `status` | [`?string(Status)`](../../doc/models/status.md) | Optional | The status of an account. | getStatus(): ?string | setStatus(?string status): void |
| `lineOfBusiness` | `?string` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. | getLineOfBusiness(): ?string | setLineOfBusiness(?string lineOfBusiness): void |
| `balanceType` | [`?string(BalanceType)`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) | getBalanceType(): ?string | setBalanceType(?string balanceType): void |
| `interestRate` | `?float` | Optional | Interest Rate of Account | getInterestRate(): ?float | setInterestRate(?float interestRate): void |
| `interestRateType` | [`?string(InterestRateType)`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. | getInterestRateType(): ?string | setInterestRateType(?string interestRateType): void |
| `interestRateAsOf` | `?DateTime` | Optional | Date of account’s interest rate | getInterestRateAsOf(): ?\DateTime | setInterestRateAsOf(?\DateTime interestRateAsOf): void |
| `lastActivityDate` | `?DateTime` | Optional | Date that last transaction occurred on account | getLastActivityDate(): ?\DateTime | setLastActivityDate(?\DateTime lastActivityDate): void |
| `micrNumber` | `?string` | Optional | MICR Number | getMicrNumber(): ?string | setMicrNumber(?string micrNumber): void |
| `parentAccountId` | `?string` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. | getParentAccountId(): ?string | setParentAccountId(?string parentAccountId): void |
| `priorInterestRate` | `?float` | Optional | Previous Interest Rate of Account | getPriorInterestRate(): ?float | setPriorInterestRate(?float priorInterestRate): void |
| `transferIn` | `?bool` | Optional | Account is eligible for incoming transfers | getTransferIn(): ?bool | setTransferIn(?bool transferIn): void |
| `transferOut` | `?bool` | Optional | Account is eligible for outgoing transfers | getTransferOut(): ?bool | setTransferOut(?bool transferOut): void |
| `annuityProductType` | [`?string(AnnunityProductType)`](../../doc/models/annunity-product-type.md) | Optional | - | getAnnuityProductType(): ?string | setAnnuityProductType(?string annuityProductType): void |
| `annuityValueBasis` | [`?string(AnnunityValueBasis)`](../../doc/models/annunity-value-basis.md) | Optional | - | getAnnuityValueBasis(): ?string | setAnnuityValueBasis(?string annuityValueBasis): void |
| `paymentFrequency` | [`?string(PaymentFrequency1)`](../../doc/models/payment-frequency-1.md) | Optional | - | getPaymentFrequency(): ?string | setPaymentFrequency(?string paymentFrequency): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "accountId": "accountId8",
  "accountType": "accountType8",
  "accountNumberDisplay": "accountNumberDisplay4",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

