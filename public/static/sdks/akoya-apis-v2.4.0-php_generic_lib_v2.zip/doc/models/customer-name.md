
# Customer Name

*This model accepts additional fields of type array.*

## Structure

`CustomerName`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `first` | `?string` | Optional | First or given name. This data element may contain first & last name if not separated. | getFirst(): ?string | setFirst(?string first): void |
| `middle` | `?string` | Optional | - | getMiddle(): ?string | setMiddle(?string middle): void |
| `last` | `?string` | Optional | - | getLast(): ?string | setLast(?string last): void |
| `prefix` | `?string` | Optional | Name prefix, e.g. Mr. | getPrefix(): ?string | setPrefix(?string prefix): void |
| `suffix` | `?string` | Optional | Generational or academic suffix | getSuffix(): ?string | setSuffix(?string suffix): void |
| `company` | `?string` | Optional | Company name | getCompany(): ?string | setCompany(?string company): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

