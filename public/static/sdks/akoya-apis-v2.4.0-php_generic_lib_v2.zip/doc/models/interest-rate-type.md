
# Interest Rate Type

The type of interest rate. FIXED or VARIABLE.

## Enumeration

`InterestRateType`

## Fields

| Name |
|  --- |
| `FIXED` |
| `VARIABLE` |

