
# Month Abbreviation

Used by MonthAmount

## Enumeration

`MonthAbbreviation`

## Fields

| Name |
|  --- |
| `JAN` |
| `FEB` |
| `MAR` |
| `APR` |
| `MAY` |
| `JUN` |
| `JUL` |
| `AUG` |
| `SEP` |
| `OCT` |
| `NOV` |
| `DEC` |

