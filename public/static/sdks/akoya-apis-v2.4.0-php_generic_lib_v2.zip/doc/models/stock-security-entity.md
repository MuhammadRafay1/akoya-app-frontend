
# Stock Security Entity

Information about the stock security specific to the type of security

*This model accepts additional fields of type array.*

## Structure

`StockSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `unitsStreet` | `?float` | Optional | Units in the FI's street name, positive quantity | getUnitsStreet(): ?float | setUnitsStreet(?float unitsStreet): void |
| `unitsUser` | `?float` | Optional | Units in user's name directly, positive  quantity | getUnitsUser(): ?float | setUnitsUser(?float unitsUser): void |
| `reinvestDividends` | `?bool` | Optional | Reinvest dividends | getReinvestDividends(): ?bool | setReinvestDividends(?bool reinvestDividends): void |
| `stockType` | [`?string(StockType)`](../../doc/models/stock-type.md) | Optional | - | getStockType(): ?string | setStockType(?string stockType): void |
| `yield` | `?float` | Optional | Current yield | getYield(): ?float | setYield(?float yield): void |
| `yieldAsOfDate` | `?DateTime` | Optional | Yield as-of date | getYieldAsOfDate(): ?\DateTime | setYieldAsOfDate(?\DateTime yieldAsOfDate): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "unitsStreet": 117.56,
  "unitsUser": 92.52,
  "reinvestDividends": false,
  "stockType": "STOCK",
  "yield": 211.18,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

