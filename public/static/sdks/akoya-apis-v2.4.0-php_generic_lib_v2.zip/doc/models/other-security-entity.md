
# Other Security Entity

Information about the security specific to the type of security

*This model accepts additional fields of type array.*

## Structure

`OtherSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `typeDescription` | `?string` | Optional | Description of Other Security | getTypeDescription(): ?string | setTypeDescription(?string typeDescription): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "typeDescription": "typeDescription6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

