
# Business Customer Entity

Customers that are commercial in nature are affiliated with a business entity

*This model accepts additional fields of type array.*

## Structure

`BusinessCustomerEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Name of business customer | getName(): ?string | setName(?string name): void |
| `registeredAgents` | [`?(CustomerName[])`](../../doc/models/customer-name.md) | Optional | A list of registered agents who act on behalf of the business customer | getRegisteredAgents(): ?array | setRegisteredAgents(?array registeredAgents): void |
| `registeredId` | `?string` | Optional | The registered tax identification number (TIN) or other identifier of business customer | getRegisteredId(): ?string | setRegisteredId(?string registeredId): void |
| `industryCode` | [`?IndustryCode`](../../doc/models/industry-code.md) | Optional | Industry code and type | getIndustryCode(): ?IndustryCode | setIndustryCode(?IndustryCode industryCode): void |
| `domicile` | [`?Domicile`](../../doc/models/domicile.md) | Optional | The country and region of the business customer's location | getDomicile(): ?Domicile | setDomicile(?Domicile domicile): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "name": "name0",
  "registeredAgents": [
    {
      "first": "first6",
      "middle": "middle6",
      "last": "last0",
      "prefix": "prefix8",
      "suffix": "suffix0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "registeredId": "registeredId6",
  "industryCode": {
    "type": "type8",
    "code": "code0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "domicile": {
    "region": "region2",
    "country": "country0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

