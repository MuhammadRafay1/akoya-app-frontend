
# Status 1

AUTHORIZATION, MEMO, PENDING, or POSTED

## Enumeration

`Status1`

## Fields

| Name |
|  --- |
| `PENDING` |
| `MEMO` |
| `POSTED` |
| `AUTHORIZATION` |

