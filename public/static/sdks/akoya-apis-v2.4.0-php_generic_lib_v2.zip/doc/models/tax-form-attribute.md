
# Tax Form Attribute

An additional tax form attribute for use when a defined field is not available

*This model accepts additional fields of type array.*

## Structure

`TaxFormAttribute`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Name of attribute | getName(): ?string | setName(?string name): void |
| `value` | `?string` | Optional | Value of attribute | getValue(): ?string | setValue(?string value): void |
| `boxNumber` | `?string` | Optional | Box number on a tax form, if any | getBoxNumber(): ?string | setBoxNumber(?string boxNumber): void |
| `code` | `?string` | Optional | Tax form code for the given box number, if any | getCode(): ?string | setCode(?string code): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4",
  "boxNumber": "boxNumber0",
  "code": "code0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

