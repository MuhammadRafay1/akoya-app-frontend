
# Security Detail Irs Form 1099 B

Tax information for a single security transaction

*This model accepts additional fields of type array.*

## Structure

`SecurityDetailIrsForm1099B`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `checkboxOnForm8949` | `?string` | Optional | Applicable checkbox on Form 8949 | getCheckboxOnForm8949(): ?string | setCheckboxOnForm8949(?string checkboxOnForm8949): void |
| `securityName` | `?string` | Optional | Security name | getSecurityName(): ?string | setSecurityName(?string securityName): void |
| `numberOfShares` | `?float` | Optional | Number of shares | getNumberOfShares(): ?float | setNumberOfShares(?float numberOfShares): void |
| `saleDescription` | `?string` | Optional | Box 1a, Description of property | getSaleDescription(): ?string | setSaleDescription(?string saleDescription): void |
| `dateAcquired` | `?DateTime` | Optional | Box 1b, Date acquired | getDateAcquired(): ?\DateTime | setDateAcquired(?\DateTime dateAcquired): void |
| `variousDatesAcquired` | `?bool` | Optional | Box 1b, Date acquired Various | getVariousDatesAcquired(): ?bool | setVariousDatesAcquired(?bool variousDatesAcquired): void |
| `dateOfSale` | `?DateTime` | Optional | Box 1c, Date sold or disposed | getDateOfSale(): ?\DateTime | setDateOfSale(?\DateTime dateOfSale): void |
| `salesPrice` | `?float` | Optional | Box 1d, Proceeds (not price per share) | getSalesPrice(): ?float | setSalesPrice(?float salesPrice): void |
| `accruedMarketDiscount` | `?float` | Optional | Box 1f, Accrued market discount | getAccruedMarketDiscount(): ?float | setAccruedMarketDiscount(?float accruedMarketDiscount): void |
| `adjustmentCodes` | [`?(CodeAndAmount[])`](../../doc/models/code-and-amount.md) | Optional | Other adjustments (code and amount) | getAdjustmentCodes(): ?array | setAdjustmentCodes(?array adjustmentCodes): void |
| `costBasis` | `?float` | Optional | Box 1e, Cost or other basis | getCostBasis(): ?float | setCostBasis(?float costBasis): void |
| `correctedCostBasis` | `?float` | Optional | Corrected cost basis. May be supplied in lieu of adjustmentCode code B. If both adjustmentCodes and correctedCostBasis are supplied, costBasis plus adjustmentCode B should equal correctedCostBasis | getCorrectedCostBasis(): ?float | setCorrectedCostBasis(?float correctedCostBasis): void |
| `washSaleLossDisallowed` | `?float` | Optional | Box 1g, Wash sale loss disallowed | getWashSaleLossDisallowed(): ?float | setWashSaleLossDisallowed(?float washSaleLossDisallowed): void |
| `longOrShort` | [`?string(SaleTermType2)`](../../doc/models/sale-term-type-2.md) | Optional | Box 2, LONG or SHORT | getLongOrShort(): ?string | setLongOrShort(?string longOrShort): void |
| `ordinary` | `?bool` | Optional | Box 2, Ordinary | getOrdinary(): ?bool | setOrdinary(?bool ordinary): void |
| `collectible` | `?bool` | Optional | Box 3, Collectibles | getCollectible(): ?bool | setCollectible(?bool collectible): void |
| `qof` | `?bool` | Optional | Box 3, Qualified Opportunity Fund (QOF) | getQof(): ?bool | setQof(?bool qof): void |
| `federalTaxWithheld` | `?float` | Optional | Box 4, Federal income tax withheld | getFederalTaxWithheld(): ?float | setFederalTaxWithheld(?float federalTaxWithheld): void |
| `noncoveredSecurity` | `?bool` | Optional | Box 5, Noncovered security | getNoncoveredSecurity(): ?bool | setNoncoveredSecurity(?bool noncoveredSecurity): void |
| `grossOrNet` | [`?string(SaleProceedsType1)`](../../doc/models/sale-proceeds-type-1.md) | Optional | Box 6, Reported to IRS: GROSS or NET | getGrossOrNet(): ?string | setGrossOrNet(?string grossOrNet): void |
| `lossNotAllowed` | `?bool` | Optional | Box 7, Loss not allowed based on proceeds | getLossNotAllowed(): ?bool | setLossNotAllowed(?bool lossNotAllowed): void |
| `basisReported` | `?bool` | Optional | Box 12, Basis reported to IRS | getBasisReported(): ?bool | setBasisReported(?bool basisReported): void |
| `stateAndLocal` | [`?(StateAndLocalTaxWithholding[])`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 14-16, State and Local tax withholding | getStateAndLocal(): ?array | setStateAndLocal(?array stateAndLocal): void |
| `cusip` | `?string` | Optional | CUSIP number | getCusip(): ?string | setCusip(?string cusip): void |
| `foreignAccountTaxCompliance` | `?bool` | Optional | Foreign account tax compliance | getForeignAccountTaxCompliance(): ?bool | setForeignAccountTaxCompliance(?bool foreignAccountTaxCompliance): void |
| `expiredOption` | [`?string(ExpiredOptionType1)`](../../doc/models/expired-option-type-1.md) | Optional | To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED | getExpiredOption(): ?string | setExpiredOption(?string expiredOption): void |
| `investmentSaleType` | [`?string(InvestmentSaleType)`](../../doc/models/investment-sale-type.md) | Optional | Type of investment sale | getInvestmentSaleType(): ?string | setInvestmentSaleType(?string investmentSaleType): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "dateAcquired": "2021-07-15",
  "dateOfSale": "2021-07-15",
  "checkboxOnForm8949": "checkboxOnForm89498",
  "securityName": "securityName6",
  "numberOfShares": 126.44,
  "saleDescription": "saleDescription4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

