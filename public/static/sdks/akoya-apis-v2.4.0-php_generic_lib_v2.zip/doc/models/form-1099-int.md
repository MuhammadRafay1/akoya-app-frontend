
# Form 1099 Int

Interest Income, from PAYER (1st-2nd boxes as issuer) to RECIPIENT (3rd-4th boxes)

*This model accepts additional fields of type array.*

## Structure

`Form1099Int`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxYear` | `?int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | getTaxYear(): ?int | setTaxYear(?int taxYear): void |
| `corrected` | `?bool` | Optional | True to indicate this is a corrected tax form | getCorrected(): ?bool | setCorrected(?bool corrected): void |
| `accountId` | `?string` | Optional | Long-term persistent identity of the source account. Not the account number | getAccountId(): ?string | setAccountId(?string accountId): void |
| `taxFormId` | `?string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | getTaxFormId(): ?string | setTaxFormId(?string taxFormId): void |
| `taxFormDate` | `?DateTime` | Optional | Date of production or delivery of the tax form | getTaxFormDate(): ?\DateTime | setTaxFormDate(?\DateTime taxFormDate): void |
| `additionalInformation` | `?string` | Optional | Additional explanation text or content about this tax form | getAdditionalInformation(): ?string | setAdditionalInformation(?string additionalInformation): void |
| `taxFormType` | [`?string(TypeFormType2)`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | getTaxFormType(): ?string | setTaxFormType(?string taxFormType): void |
| `issuer` | [`?TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getIssuer(): ?TaxParty8 | setIssuer(?TaxParty8 issuer): void |
| `recipient` | [`?TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getRecipient(): ?TaxParty1 | setRecipient(?TaxParty1 recipient): void |
| `attributes` | [`?(TaxFormAttribute[])`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | getAttributes(): ?array | setAttributes(?array attributes): void |
| `error` | [`?Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | getError(): ?Error2 | setError(?Error2 error): void |
| `links` | [`?(HateoasLink[])`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | getLinks(): ?array | setLinks(?array links): void |
| `foreignAccountTaxCompliance` | `?bool` | Optional | FATCA filing requirement | getForeignAccountTaxCompliance(): ?bool | setForeignAccountTaxCompliance(?bool foreignAccountTaxCompliance): void |
| `accountNumber` | `?string` | Optional | Account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `payerRtn` | `?string` | Optional | Payer's RTN | getPayerRtn(): ?string | setPayerRtn(?string payerRtn): void |
| `interestIncome` | `?float` | Optional | Box 1, Interest income | getInterestIncome(): ?float | setInterestIncome(?float interestIncome): void |
| `earlyWithdrawalPenalty` | `?float` | Optional | Box 2, Early withdrawal penalty | getEarlyWithdrawalPenalty(): ?float | setEarlyWithdrawalPenalty(?float earlyWithdrawalPenalty): void |
| `usBondInterest` | `?float` | Optional | Box 3, Interest on U.S. Savings Bonds and Treasury obligations | getUsBondInterest(): ?float | setUsBondInterest(?float usBondInterest): void |
| `federalTaxWithheld` | `?float` | Optional | Box 4, Federal income tax withheld | getFederalTaxWithheld(): ?float | setFederalTaxWithheld(?float federalTaxWithheld): void |
| `investmentExpenses` | `?float` | Optional | Box 5, Investment expenses | getInvestmentExpenses(): ?float | setInvestmentExpenses(?float investmentExpenses): void |
| `foreignTaxPaid` | `?float` | Optional | Box 6, Foreign tax paid | getForeignTaxPaid(): ?float | setForeignTaxPaid(?float foreignTaxPaid): void |
| `foreignCountry` | `?string` | Optional | Box 7, Foreign country or U.S. possession | getForeignCountry(): ?string | setForeignCountry(?string foreignCountry): void |
| `taxExemptInterest` | `?float` | Optional | Box 8, Tax-exempt interest | getTaxExemptInterest(): ?float | setTaxExemptInterest(?float taxExemptInterest): void |
| `specifiedPabInterest` | `?float` | Optional | Box 9, Specified private activity bond interest | getSpecifiedPabInterest(): ?float | setSpecifiedPabInterest(?float specifiedPabInterest): void |
| `marketDiscount` | `?float` | Optional | Box 10, Market discount | getMarketDiscount(): ?float | setMarketDiscount(?float marketDiscount): void |
| `bondPremium` | `?float` | Optional | Box 11, Bond premium | getBondPremium(): ?float | setBondPremium(?float bondPremium): void |
| `usBondPremium` | `?float` | Optional | Box 12, Bond premium on Treasury obligations | getUsBondPremium(): ?float | setUsBondPremium(?float usBondPremium): void |
| `taxExemptBondPremium` | `?float` | Optional | Box 13, Bond premium on tax-exempt bond | getTaxExemptBondPremium(): ?float | setTaxExemptBondPremium(?float taxExemptBondPremium): void |
| `cusipNumber` | `?string` | Optional | Box 14, Tax-exempt bond CUSIP no. | getCusipNumber(): ?string | setCusipNumber(?string cusipNumber): void |
| `stateAndLocal` | [`?(StateAndLocalTaxWithholding[])`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 15-17, State and Local tax withholding | getStateAndLocal(): ?array | setStateAndLocal(?array stateAndLocal): void |
| `foreignIncomes` | [`?(DescriptionAndAmount[])`](../../doc/models/description-and-amount.md) | Optional | Supplemental foreign income amount information (description is country) | getForeignIncomes(): ?array | setForeignIncomes(?array foreignIncomes): void |
| `stateTaxExemptIncome` | [`?(DescriptionAndAmount[])`](../../doc/models/description-and-amount.md) | Optional | Supplemental tax-exempt income by state (description is state) | getStateTaxExemptIncome(): ?array | setStateTaxExemptIncome(?array stateTaxExemptIncome): void |
| `secondTinNotice` | `?bool` | Optional | Second TIN Notice | getSecondTinNotice(): ?bool | setSecondTinNotice(?bool secondTinNotice): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId2",
  "taxFormId": "taxFormId0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

