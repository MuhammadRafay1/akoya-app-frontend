
# Local Tax Withholding 1

Amount of local income tax withheld, if any

*This model accepts additional fields of type array.*

## Structure

`LocalTaxWithholding1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxWithheld` | `?float` | Optional | Amount of local income tax withheld | getTaxWithheld(): ?float | setTaxWithheld(?float taxWithheld): void |
| `localityName` | `?string` | Optional | Locality name | getLocalityName(): ?string | setLocalityName(?string localityName): void |
| `income` | `?float` | Optional | Income amount for local tax purposes | getIncome(): ?float | setIncome(?float income): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxWithheld": 15.4,
  "localityName": "localityName2",
  "income": 207.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

