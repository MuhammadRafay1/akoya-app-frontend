
# Option Security Entity

Information about the option security specific to the type of security

*This model accepts additional fields of type array.*

## Structure

`OptionSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `secured` | [`?string(Secured)`](../../doc/models/secured.md) | Optional | How the option is secured | getSecured(): ?string | setSecured(?string secured): void |
| `optionType` | [`?string(OptionType)`](../../doc/models/option-type.md) | Optional | - | getOptionType(): ?string | setOptionType(?string optionType): void |
| `strikePrice` | `?float` | Optional | Strike price / Unit price | getStrikePrice(): ?float | setStrikePrice(?float strikePrice): void |
| `expireDate` | `?DateTime` | Optional | Expiration date of option | getExpireDate(): ?\DateTime | setExpireDate(?\DateTime expireDate): void |
| `sharesPerContract` | `?float` | Optional | Shares per contract | getSharesPerContract(): ?float | setSharesPerContract(?float sharesPerContract): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "secured": "COVERED",
  "optionType": "CALL",
  "strikePrice": 0.6,
  "expireDate": "2016-03-13T12:52:32.123Z",
  "sharesPerContract": 217.4,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

