
# Sweep Security Entity

Information about the sweep security specific to the type of security

*This model accepts additional fields of type array.*

## Structure

`SweepSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `currentBalance` | `?float` | Optional | Balance of funds in account | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `availableBalance` | `?float` | Optional | Balance of funds available for use | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `balanceAsOf` | `?DateTime` | Optional | As-of date of balances | getBalanceAsOf(): ?\DateTime | setBalanceAsOf(?\DateTime balanceAsOf): void |
| `checks` | `?bool` | Optional | Whether or not checks can be written on the account | getChecks(): ?bool | setChecks(?bool checks): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "currentBalance": 188.98,
  "availableBalance": 101.4,
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "checks": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

