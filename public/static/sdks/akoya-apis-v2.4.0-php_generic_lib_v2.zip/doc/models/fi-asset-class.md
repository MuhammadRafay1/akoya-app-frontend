
# Fi Asset Class

*This model accepts additional fields of type array.*

## Structure

`FiAssetClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `assetClass` | `?string` | Optional | FI-specific asset class | getAssetClass(): ?string | setAssetClass(?string assetClass): void |
| `percent` | `?float` | Optional | Percentage of asset class that falls under this asset | getPercent(): ?float | setPercent(?float percent): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 193.72,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

