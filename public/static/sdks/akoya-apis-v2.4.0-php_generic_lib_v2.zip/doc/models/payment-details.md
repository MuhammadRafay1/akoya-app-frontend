
# Payment Details

Payment details for some transactions

*This model accepts additional fields of type array.*

## Structure

`PaymentDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `escrowAmount` | `?float` | Optional | The amount of payment applied to escrow | getEscrowAmount(): ?float | setEscrowAmount(?float escrowAmount): void |
| `feesAmount` | `?float` | Optional | The amount of payment applied to fees | getFeesAmount(): ?float | setFeesAmount(?float feesAmount): void |
| `insuranceAmount` | `?float` | Optional | The amount of payment applied to life/health/accident insurance on the loan | getInsuranceAmount(): ?float | setInsuranceAmount(?float insuranceAmount): void |
| `interestAmount` | `?float` | Optional | The amount of payment applied to interest | getInterestAmount(): ?float | setInterestAmount(?float interestAmount): void |
| `pmiAmount` | `?float` | Optional | The amount of payment applied to PMI | getPmiAmount(): ?float | setPmiAmount(?float pmiAmount): void |
| `principalAmount` | `?float` | Optional | The amount of payment applied to principal | getPrincipalAmount(): ?float | setPrincipalAmount(?float principalAmount): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "escrowAmount": 171.3,
  "feesAmount": 83.52,
  "insuranceAmount": 63.4,
  "interestAmount": 64.72,
  "pmiAmount": 217.98,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

