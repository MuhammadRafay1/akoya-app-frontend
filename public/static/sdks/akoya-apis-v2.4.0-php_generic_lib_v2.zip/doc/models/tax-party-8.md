
# Tax Party 8

Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms.

*This model accepts additional fields of type array.*

## Structure

`TaxParty8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tin` | `?string` | Optional | Issuer or recipient Tax Identification Number. Usually EIN for issuer and SSN for recipient | getTin(): ?string | setTin(?string tin): void |
| `partyType` | [`?string(TaxPartyType2)`](../../doc/models/tax-party-type-2.md) | Optional | Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient | getPartyType(): ?string | setPartyType(?string partyType): void |
| `individualName` | [`?IndividualName4`](../../doc/models/individual-name-4.md) | Optional | Individual issuer or recipient name | getIndividualName(): ?IndividualName4 | setIndividualName(?IndividualName4 individualName): void |
| `businessName` | [`?BusinessName1`](../../doc/models/business-name-1.md) | Optional | Business issuer or recipient name | getBusinessName(): ?BusinessName1 | setBusinessName(?BusinessName1 businessName): void |
| `address` | [`?Address1`](../../doc/models/address-1.md) | Optional | Issuer or recipient address | getAddress(): ?Address1 | setAddress(?Address1 address): void |
| `phone` | [`?TelephoneNumberPlusExtension4`](../../doc/models/telephone-number-plus-extension-4.md) | Optional | Issuer or recipient telephone number | getPhone(): ?TelephoneNumberPlusExtension4 | setPhone(?TelephoneNumberPlusExtension4 phone): void |
| `email` | `?string` | Optional | Issuer or recipient email address. (Additional information, not part of IRS forms) | getEmail(): ?string | setEmail(?string email): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "tin": "tin0",
  "partyType": "BUSINESS",
  "individualName": {
    "first": "first0",
    "middle": "middle0",
    "last": "last4",
    "suffix": "suffix4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "businessName": {
    "name1": "name18",
    "name2": "name22",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

