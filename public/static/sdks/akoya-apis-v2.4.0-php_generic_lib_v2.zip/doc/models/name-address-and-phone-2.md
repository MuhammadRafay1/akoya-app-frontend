
# Name Address and Phone 2

Issuer's information contact name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone no. (if different from ISSUER)

*This model accepts additional fields of type array.*

## Structure

`NameAddressAndPhone2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `line1` | `?string` | Optional | Address line 1 | getLine1(): ?string | setLine1(?string line1): void |
| `line2` | `?string` | Optional | Address line 2 | getLine2(): ?string | setLine2(?string line2): void |
| `line3` | `?string` | Optional | Address line 3 | getLine3(): ?string | setLine3(?string line3): void |
| `city` | `?string` | Optional | City | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode' | getRegion(): ?string | setRegion(?string region): void |
| `postalCode` | `?string` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `country` | [`?string(Iso3166CountryCode2)`](../../doc/models/iso-3166-country-code-2.md) | Optional | Country code | getCountry(): ?string | setCountry(?string country): void |
| `name1` | `?string` | Optional | Name line 1 | getName1(): ?string | setName1(?string name1): void |
| `name2` | `?string` | Optional | Name line 2 | getName2(): ?string | setName2(?string name2): void |
| `phone` | [`?TelephoneNumberPlusExtension1`](../../doc/models/telephone-number-plus-extension-1.md) | Optional | Phone number | getPhone(): ?TelephoneNumberPlusExtension1 | setPhone(?TelephoneNumberPlusExtension1 phone): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "line1": "line12",
  "line2": "line24",
  "line3": "line32",
  "city": "city0",
  "region": "region6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

