
# Open Order Entity

Information on an open order.

*This model accepts additional fields of type array.*

## Structure

`OpenOrderEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderId` | `?string` | Optional | Long term persistent identity of the order. Id for this order transaction. | getOrderId(): ?string | setOrderId(?string orderId): void |
| `securityId` | `?string` | Optional | Unique identifier of the security. | getSecurityId(): ?string | setSecurityId(?string securityId): void |
| `securityIdType` | [`?string(SecurityIdType)`](../../doc/models/security-id-type.md) | Optional | Security identifier type | getSecurityIdType(): ?string | setSecurityIdType(?string securityIdType): void |
| `symbol` | `?string` | Optional | Market symbol | getSymbol(): ?string | setSymbol(?string symbol): void |
| `description` | `?string` | Optional | Description of order | getDescription(): ?string | setDescription(?string description): void |
| `units` | `?float` | Optional | Number of units (shares, bonds, etc.) | getUnits(): ?float | setUnits(?float units): void |
| `orderType` | [`?string(OrderType)`](../../doc/models/order-type.md) | Optional | Type of order. | getOrderType(): ?string | setOrderType(?string orderType): void |
| `orderDate` | `?DateTime` | Optional | Order date | getOrderDate(): ?\DateTime | setOrderDate(?\DateTime orderDate): void |
| `unitPrice` | `?float` | Optional | Unit price | getUnitPrice(): ?float | setUnitPrice(?float unitPrice): void |
| `unitType` | [`?string(UnitType)`](../../doc/models/unit-type.md) | Optional | Type of unit. | getUnitType(): ?string | setUnitType(?string unitType): void |
| `orderDuration` | [`?string(OrderDuration)`](../../doc/models/order-duration.md) | Optional | This order is good for DAY, GOODTILLCANCEL, IMMEDIATE | getOrderDuration(): ?string | setOrderDuration(?string orderDuration): void |
| `subAccount` | [`?string(SubAccount)`](../../doc/models/sub-account.md) | Optional | - | getSubAccount(): ?string | setSubAccount(?string subAccount): void |
| `limitPrice` | `?float` | Optional | Limit Price | getLimitPrice(): ?float | setLimitPrice(?float limitPrice): void |
| `stopPrice` | `?float` | Optional | Stop price | getStopPrice(): ?float | setStopPrice(?float stopPrice): void |
| `inv401KSource` | [`?string(Inv401KSource)`](../../doc/models/inv-401-k-source.md) | Optional | For 401(k) accounts, source of money for this order. Default if not present is OTHERNONVEST. | getInv401KSource(): ?string | setInv401KSource(?string inv401KSource): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "orderId": "orderId4",
  "securityId": "securityId6",
  "securityIdType": "VALOR",
  "symbol": "symbol0",
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

