
# Form 1099 R

Distributions from Pensions, Annuities, Retirement or Profit-Sharing Plans, IRAs, Insurance Contracts, etc., from PAYER (1st-2nd boxes as issuer) to RECIPIENT (3rd-4th boxes)

*This model accepts additional fields of type array.*

## Structure

`Form1099R`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxYear` | `?int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | getTaxYear(): ?int | setTaxYear(?int taxYear): void |
| `corrected` | `?bool` | Optional | True to indicate this is a corrected tax form | getCorrected(): ?bool | setCorrected(?bool corrected): void |
| `accountId` | `?string` | Optional | Long-term persistent identity of the source account. Not the account number | getAccountId(): ?string | setAccountId(?string accountId): void |
| `taxFormId` | `?string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | getTaxFormId(): ?string | setTaxFormId(?string taxFormId): void |
| `taxFormDate` | `?DateTime` | Optional | Date of production or delivery of the tax form | getTaxFormDate(): ?\DateTime | setTaxFormDate(?\DateTime taxFormDate): void |
| `additionalInformation` | `?string` | Optional | Additional explanation text or content about this tax form | getAdditionalInformation(): ?string | setAdditionalInformation(?string additionalInformation): void |
| `taxFormType` | [`?string(TypeFormType2)`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | getTaxFormType(): ?string | setTaxFormType(?string taxFormType): void |
| `issuer` | [`?TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getIssuer(): ?TaxParty8 | setIssuer(?TaxParty8 issuer): void |
| `recipient` | [`?TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getRecipient(): ?TaxParty1 | setRecipient(?TaxParty1 recipient): void |
| `attributes` | [`?(TaxFormAttribute[])`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | getAttributes(): ?array | setAttributes(?array attributes): void |
| `error` | [`?Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | getError(): ?Error2 | setError(?Error2 error): void |
| `links` | [`?(HateoasLink[])`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | getLinks(): ?array | setLinks(?array links): void |
| `allocableToIrr` | `?float` | Optional | Box 10, Amount allocable to IRR within 5 years | getAllocableToIrr(): ?float | setAllocableToIrr(?float allocableToIrr): void |
| `firstYearOfRoth` | `?int` | Optional | Box 11, First year of designated Roth contributions. A four-digit year. (Like `TaxYear` definition, but lower minimum since first year of Roth IRAs was 1997)<br><br>**Constraints**: `>= 1997`, `<= 2050` | getFirstYearOfRoth(): ?int | setFirstYearOfRoth(?int firstYearOfRoth): void |
| `recipientAccountNumber` | `?string` | Optional | Account number | getRecipientAccountNumber(): ?string | setRecipientAccountNumber(?string recipientAccountNumber): void |
| `grossDistribution` | `?float` | Optional | Box 1, Gross distribution | getGrossDistribution(): ?float | setGrossDistribution(?float grossDistribution): void |
| `taxableAmount` | `?float` | Optional | Box 2a, Taxable amount | getTaxableAmount(): ?float | setTaxableAmount(?float taxableAmount): void |
| `taxableAmountNotDetermined` | `?bool` | Optional | Box 2b, Taxable amount not determined | getTaxableAmountNotDetermined(): ?bool | setTaxableAmountNotDetermined(?bool taxableAmountNotDetermined): void |
| `totalDistribution` | `?bool` | Optional | Box 2c, Total distribution | getTotalDistribution(): ?bool | setTotalDistribution(?bool totalDistribution): void |
| `capitalGain` | `?float` | Optional | Box 3, Capital gain | getCapitalGain(): ?float | setCapitalGain(?float capitalGain): void |
| `federalTaxWithheld` | `?float` | Optional | Box 4, Federal income tax withheld | getFederalTaxWithheld(): ?float | setFederalTaxWithheld(?float federalTaxWithheld): void |
| `employeeContributions` | `?float` | Optional | Box 5, Employee contributions | getEmployeeContributions(): ?float | setEmployeeContributions(?float employeeContributions): void |
| `netUnrealizedAppreciation` | `?float` | Optional | Box 6, Net unrealized appreciation | getNetUnrealizedAppreciation(): ?float | setNetUnrealizedAppreciation(?float netUnrealizedAppreciation): void |
| `distributionCodes` | `?(string[])` | Optional | Box 7, Distribution codes | getDistributionCodes(): ?array | setDistributionCodes(?array distributionCodes): void |
| `iraSepSimple` | `?bool` | Optional | Box 7b, IRA/SEP/SIMPLE | getIraSepSimple(): ?bool | setIraSepSimple(?bool iraSepSimple): void |
| `otherAmount` | `?float` | Optional | Box 8, Other | getOtherAmount(): ?float | setOtherAmount(?float otherAmount): void |
| `otherPercent` | `?float` | Optional | Box 8, Other percent | getOtherPercent(): ?float | setOtherPercent(?float otherPercent): void |
| `yourPercentOfTotal` | `?float` | Optional | Box 9a, Your percent of total distribution | getYourPercentOfTotal(): ?float | setYourPercentOfTotal(?float yourPercentOfTotal): void |
| `totalEmployeeContributions` | `?float` | Optional | Box 9b, Total employee contributions | getTotalEmployeeContributions(): ?float | setTotalEmployeeContributions(?float totalEmployeeContributions): void |
| `foreignAccountTaxCompliance` | `?bool` | Optional | Box 12, FATCA filing requirement | getForeignAccountTaxCompliance(): ?bool | setForeignAccountTaxCompliance(?bool foreignAccountTaxCompliance): void |
| `dateOfPayment` | `?DateTime` | Optional | Box 13, Date of payment | getDateOfPayment(): ?\DateTime | setDateOfPayment(?\DateTime dateOfPayment): void |
| `stateAndLocal` | [`?(StateAndLocalTaxWithholding[])`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 14-19, State and Local tax withholding | getStateAndLocal(): ?array | setStateAndLocal(?array stateAndLocal): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "firstYearOfRoth": 2020,
  "dateOfPayment": "2021-07-15",
  "corrected": false,
  "accountId": "accountId8",
  "taxFormId": "taxFormId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

