
# Business Income Statement

Business Income Statement for IRS Form 1040 Schedule C

*This model accepts additional fields of type array.*

## Structure

`BusinessIncomeStatement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxYear` | `?int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | getTaxYear(): ?int | setTaxYear(?int taxYear): void |
| `corrected` | `?bool` | Optional | True to indicate this is a corrected tax form | getCorrected(): ?bool | setCorrected(?bool corrected): void |
| `accountId` | `?string` | Optional | Long-term persistent identity of the source account. Not the account number | getAccountId(): ?string | setAccountId(?string accountId): void |
| `taxFormId` | `?string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | getTaxFormId(): ?string | setTaxFormId(?string taxFormId): void |
| `taxFormDate` | `?DateTime` | Optional | Date of production or delivery of the tax form | getTaxFormDate(): ?\DateTime | setTaxFormDate(?\DateTime taxFormDate): void |
| `additionalInformation` | `?string` | Optional | Additional explanation text or content about this tax form | getAdditionalInformation(): ?string | setAdditionalInformation(?string additionalInformation): void |
| `taxFormType` | [`?string(TypeFormType2)`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | getTaxFormType(): ?string | setTaxFormType(?string taxFormType): void |
| `issuer` | [`?TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getIssuer(): ?TaxParty8 | setIssuer(?TaxParty8 issuer): void |
| `recipient` | [`?TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getRecipient(): ?TaxParty1 | setRecipient(?TaxParty1 recipient): void |
| `attributes` | [`?(TaxFormAttribute[])`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | getAttributes(): ?array | setAttributes(?array attributes): void |
| `error` | [`?Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | getError(): ?Error2 | setError(?Error2 error): void |
| `links` | [`?(HateoasLink[])`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | getLinks(): ?array | setLinks(?array links): void |
| `businessName` | `?string` | Optional | Box C, Business name | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `sales` | `?float` | Optional | Box 1, Gross receipts or sales | getSales(): ?float | setSales(?float sales): void |
| `returns` | `?float` | Optional | Box 2, Returns and allowances | getReturns(): ?float | setReturns(?float returns): void |
| `otherIncome` | [`?(DescriptionAndAmount[])`](../../doc/models/description-and-amount.md) | Optional | Box 6, Other income, including federal and state gasoline or fuel tax credit or refund | getOtherIncome(): ?array | setOtherIncome(?array otherIncome): void |
| `advertising` | `?float` | Optional | Box 8, Advertising | getAdvertising(): ?float | setAdvertising(?float advertising): void |
| `carAndTruck` | `?float` | Optional | Box 9, Car and truck expenses | getCarAndTruck(): ?float | setCarAndTruck(?float carAndTruck): void |
| `commissions` | `?float` | Optional | Box 10, Commissions and fees | getCommissions(): ?float | setCommissions(?float commissions): void |
| `contractLabor` | `?float` | Optional | Box 11, Contract labor | getContractLabor(): ?float | setContractLabor(?float contractLabor): void |
| `depletion` | `?float` | Optional | Box 12, Depletion | getDepletion(): ?float | setDepletion(?float depletion): void |
| `depreciation` | `?float` | Optional | Box 13, Depreciation | getDepreciation(): ?float | setDepreciation(?float depreciation): void |
| `employeeBenefits` | `?float` | Optional | Box 14, Employee benefit programs | getEmployeeBenefits(): ?float | setEmployeeBenefits(?float employeeBenefits): void |
| `insurance` | `?float` | Optional | Box 15, Insurance | getInsurance(): ?float | setInsurance(?float insurance): void |
| `mortgageInterest` | `?float` | Optional | Box 16a, Mortgage interest | getMortgageInterest(): ?float | setMortgageInterest(?float mortgageInterest): void |
| `otherInterest` | `?float` | Optional | Box 16b, Other interest | getOtherInterest(): ?float | setOtherInterest(?float otherInterest): void |
| `legal` | `?float` | Optional | Box 17, Legal and professional services | getLegal(): ?float | setLegal(?float legal): void |
| `office` | `?float` | Optional | Box 18, Office expense | getOffice(): ?float | setOffice(?float office): void |
| `pension` | `?float` | Optional | Box 19, Pension and profit-sharing plans | getPension(): ?float | setPension(?float pension): void |
| `equipmentRent` | `?float` | Optional | Box 20a, Equipment rent | getEquipmentRent(): ?float | setEquipmentRent(?float equipmentRent): void |
| `otherRent` | `?float` | Optional | Box 20b, Other rent | getOtherRent(): ?float | setOtherRent(?float otherRent): void |
| `repairs` | `?float` | Optional | Box 21, Repairs and maintenance | getRepairs(): ?float | setRepairs(?float repairs): void |
| `supplies` | `?float` | Optional | Box 22, Supplies | getSupplies(): ?float | setSupplies(?float supplies): void |
| `taxes` | `?float` | Optional | Box 23, Taxes and licenses | getTaxes(): ?float | setTaxes(?float taxes): void |
| `travel` | `?float` | Optional | Box 24a, Travel | getTravel(): ?float | setTravel(?float travel): void |
| `meals` | `?float` | Optional | Box 24b, Deductible meals | getMeals(): ?float | setMeals(?float meals): void |
| `utilities` | `?float` | Optional | Box 25, Utilities | getUtilities(): ?float | setUtilities(?float utilities): void |
| `wages` | `?float` | Optional | Box 26, Wages | getWages(): ?float | setWages(?float wages): void |
| `otherExpenses` | [`?(DescriptionAndAmount[])`](../../doc/models/description-and-amount.md) | Optional | Box 27, Other expenses | getOtherExpenses(): ?array | setOtherExpenses(?array otherExpenses): void |
| `beginningInventory` | `?float` | Optional | Box 35, Inventory at beginning of year | getBeginningInventory(): ?float | setBeginningInventory(?float beginningInventory): void |
| `purchases` | `?float` | Optional | Box 36, Purchases | getPurchases(): ?float | setPurchases(?float purchases): void |
| `costOfLabor` | `?float` | Optional | Box 37, Cost of labor | getCostOfLabor(): ?float | setCostOfLabor(?float costOfLabor): void |
| `materials` | `?float` | Optional | Box 38, Materials and supplies | getMaterials(): ?float | setMaterials(?float materials): void |
| `otherCosts` | [`?(DescriptionAndAmount[])`](../../doc/models/description-and-amount.md) | Optional | Box 39, Other costs | getOtherCosts(): ?array | setOtherCosts(?array otherCosts): void |
| `endingInventory` | `?float` | Optional | Box 41, Inventory at end of year | getEndingInventory(): ?float | setEndingInventory(?float endingInventory): void |
| `capitalExpenditures` | [`?(DateAndAmount[])`](../../doc/models/date-and-amount.md) | Optional | Capital expenditures, for use in calculating Depreciation | getCapitalExpenditures(): ?array | setCapitalExpenditures(?array capitalExpenditures): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId0",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

