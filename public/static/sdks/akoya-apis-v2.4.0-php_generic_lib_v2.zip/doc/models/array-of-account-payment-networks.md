
# Array of Account Payment Networks

*This model accepts additional fields of type array.*

## Structure

`ArrayOfAccountPaymentNetworks`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paymentNetworks` | [`?(PaymentNetworkSupportedByAccount[])`](../../doc/models/payment-network-supported-by-account.md) | Optional | Array of payment networks | getPaymentNetworks(): ?array | setPaymentNetworks(?array paymentNetworks): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "paymentNetworks": [
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "identifierType4",
      "type": "type0",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "identifierType4",
      "type": "type0",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "identifierType4",
      "type": "type0",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

