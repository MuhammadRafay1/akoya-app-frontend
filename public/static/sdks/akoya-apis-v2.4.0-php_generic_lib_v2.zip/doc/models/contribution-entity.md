
# Contribution Entity

Describes how new contributions are distributed among the available securities.

*This model accepts additional fields of type array.*

## Structure

`ContributionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `securityId` | `?string` | Optional | Unique identifier of security | getSecurityId(): ?string | setSecurityId(?string securityId): void |
| `securityIdType` | [`?string(SecurityIdType)`](../../doc/models/security-id-type.md) | Optional | Security identifier type | getSecurityIdType(): ?string | setSecurityIdType(?string securityIdType): void |
| `employerMatchPercentage` | `?float` | Optional | Employer contribution match percentage | getEmployerMatchPercentage(): ?float | setEmployerMatchPercentage(?float employerMatchPercentage): void |
| `employerMatchAmount` | `?float` | Optional | Employer contribution match amount | getEmployerMatchAmount(): ?float | setEmployerMatchAmount(?float employerMatchAmount): void |
| `employeePreTaxAmount` | `?float` | Optional | Employee pre‐tax contribution amount | getEmployeePreTaxAmount(): ?float | setEmployeePreTaxAmount(?float employeePreTaxAmount): void |
| `employeePreTaxPercentage` | `?float` | Optional | Employee pre‐tax contribution percentage | getEmployeePreTaxPercentage(): ?float | setEmployeePreTaxPercentage(?float employeePreTaxPercentage): void |
| `employeeAfterTaxAmount` | `?float` | Optional | Employee after tax contribution amount | getEmployeeAfterTaxAmount(): ?float | setEmployeeAfterTaxAmount(?float employeeAfterTaxAmount): void |
| `employeeAfterTaxPercentage` | `?float` | Optional | Employee after tax contribution percentage | getEmployeeAfterTaxPercentage(): ?float | setEmployeeAfterTaxPercentage(?float employeeAfterTaxPercentage): void |
| `employeeDeferPreTaxAmount` | `?float` | Optional | Employee defer pre‐tax contribution match amount | getEmployeeDeferPreTaxAmount(): ?float | setEmployeeDeferPreTaxAmount(?float employeeDeferPreTaxAmount): void |
| `employeeDeferPreTaxPercentage` | `?float` | Optional | Employee defer pre‐tax contribution match percentage | getEmployeeDeferPreTaxPercentage(): ?float | setEmployeeDeferPreTaxPercentage(?float employeeDeferPreTaxPercentage): void |
| `employeeYearToDate` | `?float` | Optional | Employee total year to date contribution | getEmployeeYearToDate(): ?float | setEmployeeYearToDate(?float employeeYearToDate): void |
| `employerYearToDate` | `?float` | Optional | Employer total year to date contribution | getEmployerYearToDate(): ?float | setEmployerYearToDate(?float employerYearToDate): void |
| `rolloverContributionPercentage` | `?float` | Optional | Rollover contribution percentage | getRolloverContributionPercentage(): ?float | setRolloverContributionPercentage(?float rolloverContributionPercentage): void |
| `rolloverContributionAmount` | `?float` | Optional | Rollover contribution Amount | getRolloverContributionAmount(): ?float | setRolloverContributionAmount(?float rolloverContributionAmount): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "employerMatchPercentage": 195.92,
  "employerMatchAmount": 120.16,
  "employeePreTaxAmount": 147.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

