
# Tax Refund Direct Deposit 2

Tax refund direct deposit information

*This model accepts additional fields of type array.*

## Structure

`TaxRefundDirectDeposit2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `institutionName` | `?string` | Optional | Name of institution | getInstitutionName(): ?string | setInstitutionName(?string institutionName): void |
| `rtn` | `?string` | Optional | Routing transit number | getRtn(): ?string | setRtn(?string rtn): void |
| `accountNumber` | `?string` | Optional | Account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `accountNickName` | `?string` | Optional | Account nickname | getAccountNickName(): ?string | setAccountNickName(?string accountNickName): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "institutionName": "institutionName0",
  "rtn": "rtn6",
  "accountNumber": "accountNumber0",
  "accountNickName": "accountNickName8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

