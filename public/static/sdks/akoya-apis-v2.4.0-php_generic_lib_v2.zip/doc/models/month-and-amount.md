
# Month and Amount

Month and amount pair used on IRS Form 1099-K, etc.

*This model accepts additional fields of type array.*

## Structure

`MonthAndAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | [`?string(MonthAbbreviation1)`](../../doc/models/month-abbreviation-1.md) | Optional | Month | getMonth(): ?string | setMonth(?string month): void |
| `amount` | `?float` | Optional | Amount | getAmount(): ?float | setAmount(?float amount): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "month": "SEP",
  "amount": 97.94,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

