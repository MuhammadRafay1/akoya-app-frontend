
# State Tax Withholding

Income in a state and its tax withholding

*This model accepts additional fields of type array.*

## Structure

`StateTaxWithholding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxWithheld` | `?float` | Optional | Amount of state income tax withheld | getTaxWithheld(): ?float | setTaxWithheld(?float taxWithheld): void |
| `taxId` | `?string` | Optional | Filer's state tax id | getTaxId(): ?string | setTaxId(?string taxId): void |
| `income` | `?float` | Optional | Income amount for state tax purposes | getIncome(): ?float | setIncome(?float income): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxWithheld": 48.38,
  "taxId": "taxId0",
  "income": 15.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

