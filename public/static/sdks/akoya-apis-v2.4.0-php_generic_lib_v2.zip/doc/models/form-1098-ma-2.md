
# Form 1098 Ma 2

Mortgage Assistance Payments

*This model accepts additional fields of type array.*

## Structure

`Form1098Ma2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxYear` | `?int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | getTaxYear(): ?int | setTaxYear(?int taxYear): void |
| `corrected` | `?bool` | Optional | True to indicate this is a corrected tax form | getCorrected(): ?bool | setCorrected(?bool corrected): void |
| `accountId` | `?string` | Optional | Long-term persistent identity of the source account. Not the account number | getAccountId(): ?string | setAccountId(?string accountId): void |
| `taxFormId` | `?string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | getTaxFormId(): ?string | setTaxFormId(?string taxFormId): void |
| `taxFormDate` | `?DateTime` | Optional | Date of production or delivery of the tax form | getTaxFormDate(): ?\DateTime | setTaxFormDate(?\DateTime taxFormDate): void |
| `additionalInformation` | `?string` | Optional | Additional explanation text or content about this tax form | getAdditionalInformation(): ?string | setAdditionalInformation(?string additionalInformation): void |
| `taxFormType` | [`?string(TypeFormType2)`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | getTaxFormType(): ?string | setTaxFormType(?string taxFormType): void |
| `issuer` | [`?TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getIssuer(): ?TaxParty8 | setIssuer(?TaxParty8 issuer): void |
| `recipient` | [`?TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | getRecipient(): ?TaxParty1 | setRecipient(?TaxParty1 recipient): void |
| `attributes` | [`?(TaxFormAttribute[])`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | getAttributes(): ?array | setAttributes(?array attributes): void |
| `error` | [`?Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | getError(): ?Error2 | setError(?Error2 error): void |
| `links` | [`?(HateoasLink[])`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | getLinks(): ?array | setLinks(?array links): void |
| `accountNumber` | `?string` | Optional | Account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `totalMortgagePayments` | `?float` | Optional | Box 1, Total State HFA (Housing Finance Agency) and homeowner mortgage payments | getTotalMortgagePayments(): ?float | setTotalMortgagePayments(?float totalMortgagePayments): void |
| `mortgageAssistancePayments` | `?float` | Optional | Box 2, State HFA (Housing Finance Agency) mortgage assistance payments | getMortgageAssistancePayments(): ?float | setMortgageAssistancePayments(?float mortgageAssistancePayments): void |
| `homeownerMortgagePayments` | `?float` | Optional | Box 3, Homeowner mortgage payments | getHomeownerMortgagePayments(): ?float | setHomeownerMortgagePayments(?float homeownerMortgagePayments): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId0",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

