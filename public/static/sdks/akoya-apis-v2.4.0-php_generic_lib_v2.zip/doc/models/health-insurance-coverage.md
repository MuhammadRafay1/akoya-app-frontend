
# Health Insurance Coverage

Used on Form 1095-A Part III

*This model accepts additional fields of type array.*

## Structure

`HealthInsuranceCoverage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enrollmentPremium` | `?float` | Optional | Monthly enrollment premiums | getEnrollmentPremium(): ?float | setEnrollmentPremium(?float enrollmentPremium): void |
| `slcspPremium` | `?float` | Optional | Monthly second lowest cost silver plan (SLCSP) premium | getSlcspPremium(): ?float | setSlcspPremium(?float slcspPremium): void |
| `advancePremiumTaxCreditPayment` | `?float` | Optional | Monthly advance payment of premium tax credit | getAdvancePremiumTaxCreditPayment(): ?float | setAdvancePremiumTaxCreditPayment(?float advancePremiumTaxCreditPayment): void |
| `month` | [`?string(CoverageMonth1)`](../../doc/models/coverage-month-1.md) | Optional | Month of coverage | getMonth(): ?string | setMonth(?string month): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "enrollmentPremium": 139.74,
  "slcspPremium": 163.34,
  "advancePremiumTaxCreditPayment": 197.06,
  "month": "MAY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

