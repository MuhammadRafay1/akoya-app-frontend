
# Line of Credit Balances

Data elements included with balances specific to line of credit accounts

*This model accepts additional fields of type array.*

## Structure

`LineOfCreditBalances`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountId` | `?string` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. | getAccountId(): ?string | setAccountId(?string accountId): void |
| `accountType` | `?string` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. | getAccountType(): ?string | setAccountType(?string accountType): void |
| `accountNumberDisplay` | `?string` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. | getAccountNumberDisplay(): ?string | setAccountNumberDisplay(?string accountNumberDisplay): void |
| `currency` | [`?CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | getCurrency(): ?CurrencyEntity | setCurrency(?CurrencyEntity currency): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `fiAttributes` | [`?(FiAttributeEntity[])`](../../doc/models/fi-attribute-entity.md) | Optional | - | getFiAttributes(): ?array | setFiAttributes(?array fiAttributes): void |
| `nickname` | `?string` | Optional | Name given by the user. Used in UIs to assist in account selection | getNickname(): ?string | setNickname(?string nickname): void |
| `productName` | `?string` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection | getProductName(): ?string | setProductName(?string productName): void |
| `status` | [`?string(Status)`](../../doc/models/status.md) | Optional | The status of an account. | getStatus(): ?string | setStatus(?string status): void |
| `lineOfBusiness` | `?string` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. | getLineOfBusiness(): ?string | setLineOfBusiness(?string lineOfBusiness): void |
| `balanceType` | [`?string(BalanceType)`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) | getBalanceType(): ?string | setBalanceType(?string balanceType): void |
| `interestRate` | `?float` | Optional | Interest Rate of Account | getInterestRate(): ?float | setInterestRate(?float interestRate): void |
| `interestRateType` | [`?string(InterestRateType)`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. | getInterestRateType(): ?string | setInterestRateType(?string interestRateType): void |
| `interestRateAsOf` | `?DateTime` | Optional | Date of account’s interest rate | getInterestRateAsOf(): ?\DateTime | setInterestRateAsOf(?\DateTime interestRateAsOf): void |
| `lastActivityDate` | `?DateTime` | Optional | Date that last transaction occurred on account | getLastActivityDate(): ?\DateTime | setLastActivityDate(?\DateTime lastActivityDate): void |
| `micrNumber` | `?string` | Optional | MICR Number | getMicrNumber(): ?string | setMicrNumber(?string micrNumber): void |
| `parentAccountId` | `?string` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. | getParentAccountId(): ?string | setParentAccountId(?string parentAccountId): void |
| `priorInterestRate` | `?float` | Optional | Previous Interest Rate of Account | getPriorInterestRate(): ?float | setPriorInterestRate(?float priorInterestRate): void |
| `transferIn` | `?bool` | Optional | Account is eligible for incoming transfers | getTransferIn(): ?bool | setTransferIn(?bool transferIn): void |
| `transferOut` | `?bool` | Optional | Account is eligible for outgoing transfers | getTransferOut(): ?bool | setTransferOut(?bool transferOut): void |
| `balanceAsOf` | `?DateTime` | Optional | As-of date of balances | getBalanceAsOf(): ?\DateTime | setBalanceAsOf(?\DateTime balanceAsOf): void |
| `advancesApr` | `?float` | Optional | Advances APR | getAdvancesApr(): ?float | setAdvancesApr(?float advancesApr): void |
| `availableCash` | `?float` | Optional | Available cash | getAvailableCash(): ?float | setAvailableCash(?float availableCash): void |
| `availableCredit` | `?float` | Optional | Available credit | getAvailableCredit(): ?float | setAvailableCredit(?float availableCredit): void |
| `cashAdvanceLimit` | `?float` | Optional | Cash advance limit | getCashAdvanceLimit(): ?float | setCashAdvanceLimit(?float cashAdvanceLimit): void |
| `creditLine` | `?float` | Optional | Credit limit | getCreditLine(): ?float | setCreditLine(?float creditLine): void |
| `currentBalance` | `?float` | Optional | Current balance LOC | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `currentRewardsBalance` | `?float` | Optional | Current rewards balance | getCurrentRewardsBalance(): ?float | setCurrentRewardsBalance(?float currentRewardsBalance): void |
| `financeCharges` | `?float` | Optional | Finance charges | getFinanceCharges(): ?float | setFinanceCharges(?float financeCharges): void |
| `lastPaymentAmount` | `?float` | Optional | Last payment amount | getLastPaymentAmount(): ?float | setLastPaymentAmount(?float lastPaymentAmount): void |
| `lastPaymentDate` | `?DateTime` | Optional | Last payment date | getLastPaymentDate(): ?\DateTime | setLastPaymentDate(?\DateTime lastPaymentDate): void |
| `lastStmtBalance` | `?float` | Optional | Last Statement Balance | getLastStmtBalance(): ?float | setLastStmtBalance(?float lastStmtBalance): void |
| `lastStmtDate` | `?DateTime` | Optional | Last Statement Date | getLastStmtDate(): ?\DateTime | setLastStmtDate(?\DateTime lastStmtDate): void |
| `minimumPaymentAmount` | `?float` | Optional | Minimum payment amount | getMinimumPaymentAmount(): ?float | setMinimumPaymentAmount(?float minimumPaymentAmount): void |
| `nextPaymentAmount` | `?float` | Optional | Amount of next payment | getNextPaymentAmount(): ?float | setNextPaymentAmount(?float nextPaymentAmount): void |
| `nextPaymentDate` | `?DateTime` | Optional | Due date of next payment | getNextPaymentDate(): ?\DateTime | setNextPaymentDate(?\DateTime nextPaymentDate): void |
| `pastDueAmount` | `?float` | Optional | Past Due Amount | getPastDueAmount(): ?float | setPastDueAmount(?float pastDueAmount): void |
| `pointsAccrued` | `?float` | Optional | Points accrued | getPointsAccrued(): ?float | setPointsAccrued(?float pointsAccrued): void |
| `principalBalance` | `?float` | Optional | Principal balance | getPrincipalBalance(): ?float | setPrincipalBalance(?float principalBalance): void |
| `pointsRedeemed` | `?float` | Optional | Points redeemed | getPointsRedeemed(): ?float | setPointsRedeemed(?float pointsRedeemed): void |
| `purchasesApr` | `?float` | Optional | Purchases APR | getPurchasesApr(): ?float | setPurchasesApr(?float purchasesApr): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "accountId": "accountId6",
  "accountType": "accountType6",
  "accountNumberDisplay": "accountNumberDisplay2",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

