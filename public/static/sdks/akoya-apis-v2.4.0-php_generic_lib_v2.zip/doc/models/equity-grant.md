
# Equity Grant

*This model accepts additional fields of type array.*

## Structure

`EquityGrant`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `grantId` | `?string` | Optional | Unique identifier of grant | getGrantId(): ?string | setGrantId(?string grantId): void |
| `grantDate` | `?DateTime` | Optional | Date grant was given | getGrantDate(): ?\DateTime | setGrantDate(?\DateTime grantDate): void |
| `grantType` | `?string` | Optional | Type of grant | getGrantType(): ?string | setGrantType(?string grantType): void |
| `seqNum` | `?float` | Optional | - | getSeqNum(): ?float | setSeqNum(?float seqNum): void |
| `grantPrice` | `?float` | Optional | Grant price | getGrantPrice(): ?float | setGrantPrice(?float grantPrice): void |
| `grantCurrencyCode` | `?string` | Optional | Indicates the currency of grant USD vs AUD vs EUR etc (for share awards, you will still get a USD) | getGrantCurrencyCode(): ?string | setGrantCurrencyCode(?string grantCurrencyCode): void |
| `quantityGranted` | `?float` | Optional | Number of options | getQuantityGranted(): ?float | setQuantityGranted(?float quantityGranted): void |
| `quantityOutstanding` | `?float` | Optional | - | getQuantityOutstanding(): ?float | setQuantityOutstanding(?float quantityOutstanding): void |
| `expirationDate` | `?DateTime` | Optional | Date grant expires | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `vestings` | [`?(Vesting[])`](../../doc/models/vesting.md) | Optional | An array of equityGrant vestings. Provides the past, present, and future vesting schedule and percentages. | getVestings(): ?array | setVestings(?array vestings): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "grantId": "grantId0",
  "grantDate": "2016-03-13T12:52:32.123Z",
  "grantType": "grantType0",
  "seqNum": 174.64,
  "grantPrice": 12.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

