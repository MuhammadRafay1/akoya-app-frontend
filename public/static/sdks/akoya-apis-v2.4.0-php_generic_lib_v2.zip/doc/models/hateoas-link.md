
# Hateoas Link

REST application constraint (Hypermedia As The Engine Of Application State)

*This model accepts additional fields of type array.*

## Structure

`HateoasLink`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `href` | `string` | Required | URL to invoke the action on the resource | getHref(): string | setHref(string href): void |
| `action` | [`?string(Action)`](../../doc/models/action.md) | Optional | HTTP Method to use for the request | getAction(): ?string | setAction(?string action): void |
| `types` | [`?(string(Type)[])`](../../doc/models/type.md) | Optional | Content-types that can be used in the Accept header. | getTypes(): ?array | setTypes(?array types): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "href": "https://api.fi.com/fdx/v4/accounts/12345",
  "action": "DELETE",
  "types": [
    "image/gif"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

