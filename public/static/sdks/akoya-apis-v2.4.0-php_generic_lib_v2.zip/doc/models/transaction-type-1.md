
# Transaction Type 1

InsuranceTransaction Type

## Enumeration

`TransactionType1`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `FEE` |
| `ADJUSTMENT` |
| `INTEREST` |

