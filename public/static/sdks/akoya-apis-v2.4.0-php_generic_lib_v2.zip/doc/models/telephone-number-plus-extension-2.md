
# Telephone Number Plus Extension 2

PSE's phone number

*This model accepts additional fields of type array.*

## Structure

`TelephoneNumberPlusExtension2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string(TelephoneNumberType2)`](../../doc/models/telephone-number-type-2.md) | Optional | Type of phone number: HOME, BUSINESS, CELL, FAX | getType(): ?string | setType(?string type): void |
| `country` | `?string` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164<br><br>**Constraints**: *Maximum Length*: `3` | getCountry(): ?string | setCountry(?string country): void |
| `number` | `?string` | Optional | Telephone subscriber number defined by ITU-T recommendation E.164<br><br>**Constraints**: *Maximum Length*: `15`, *Pattern*: `\d+` | getNumber(): ?string | setNumber(?string number): void |
| `extension` | `?string` | Optional | An arbitrary length telephone number extension | getExtension(): ?string | setExtension(?string extension): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "type": "FAX",
  "country": "country4",
  "number": "number2",
  "extension": "extension6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

