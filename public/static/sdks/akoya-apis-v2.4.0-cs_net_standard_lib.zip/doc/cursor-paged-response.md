
# CursorPagedResponse

This class represents a paginated API response for cursor based pagination.

## Base Class

[`ApiResponse`](../doc/api-response.md)

## Fields

| Name | Description | Type |
|  --- | --- | --- |
| `NextCursor` | Represents the next cursor using which the current paginated response is fetched. | `string` |
| `Items` | The collection of items contained in this page. | `IEnumerable<object>` |

