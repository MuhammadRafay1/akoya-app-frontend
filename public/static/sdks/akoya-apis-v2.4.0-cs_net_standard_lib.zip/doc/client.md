
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(30)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](../doc/log-builder.md) | Represents the logging configuration builder for API calls |
| BasicAuthCredentials | [`BasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |
| BearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| AcgAuthCredentials | [`AcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```csharp
using AkoyaApIsV240.Standard;
using AkoyaApIsV240.Standard.Authentication;
using AkoyaApIsV240.Standard.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace ConsoleApp;

AkoyaApIsV240Client client = new AkoyaApIsV240Client.Builder()
    .BasicAuthCredentials(
        new BasicAuthModel.Builder(
            "Username",
            "Password"
        )
        .Build())
    .BearerAuthCredentials(
        new BearerAuthModel.Builder(
            "AccessToken"
        )
        .Build())
    .AcgAuthCredentials(
        new AcgAuthModel.Builder(
            "OAuthClientId",
            "OAuthClientSecret",
            "OAuthRedirectUri"
        )
        .OauthScopes(
            new List<OauthScopeAcgAuth>
            {
                OauthScopeAcgAuth.Openid,
                OauthScopeAcgAuth.Profile,
            })
        .Build())
    .Environment(AkoyaApIsV240.Standard.Environment.Production)
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

## Akoya APIs v2.4.0Client Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| AccountInformationApi | Gets AccountInformationApi. |
| BalancesApi | Gets BalancesApi. |
| CustomersApi | Gets CustomersApi. |
| InvestmentsApi | Gets InvestmentsApi. |
| PaymentsApi | Gets PaymentsApi. |
| StatementsApi | Gets StatementsApi. |
| TaxBetaApi | Gets TaxBetaApi. |
| TransactionsApi | Gets TransactionsApi. |
| OauthAuthorizationApi | Gets OauthAuthorizationApi. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| BasicAuthCredentials | Gets the credentials to use with BasicAuth. | [`IBasicAuthCredentials`](auth/basic-authentication.md) |
| BearerAuthCredentials | Gets the credentials to use with BearerAuth. | [`IBearerAuthCredentials`](auth/oauth-2-bearer-token.md) |
| AcgAuthCredentials | Gets the credentials to use with AcgAuth. | [`IAcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Akoya APIs v2.4.0Client using the values provided for the builder. | `Builder` |

## Akoya APIs v2.4.0Client Builder Class

Class to build instances of Akoya APIs v2.4.0Client.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `BasicAuthCredentials(Action<BasicAuthModel.Builder> action)` | Sets credentials for BasicAuth. | `Builder` |
| `BearerAuthCredentials(Action<BearerAuthModel.Builder> action)` | Sets credentials for BearerAuth. | `Builder` |
| `AcgAuthCredentials(Action<AcgAuthModel.Builder> action)` | Sets credentials for AcgAuth. | `Builder` |

