
# AsyncPageable

An asynchronous iterable wrapper for paginated data that allows asynchronous iteration over pages or individual items. It fetches and iterates over each element in all the pages lazily and asynchronously.

This class implements 'IAsyncEnumerable`to provide lazy asynchronous iteration over all items and exposes a`GetPagesAsync()` method for page-level asynchronous iteration.

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `GetAsyncEnumerator()` | Provides an asynchronous enumerator to sequentially access all items across all pages. Pages are fetched lazily and asynchronously. | `IAsyncEnumerator of items` |
| `GetPagesAsync()` | Retrieves an asynchronous enumerable collection of all pages, enabling lazy asynchronous iteration through pages. Supports multiple paging types. | <code>AsyncPageable<BasePagedResponse<TItem, TPage>></code> |

Here the BasePagedResponse is a base class and it can be an instance of [`LinkPagedResponse`](../doc/link-paged-response.md), [`CursorPagedResponse`](../doc/cursor-paged-response.md), [`NumberPagedResponse`](../doc/number-paged-response.md) or [`OffsetPagedResponse`](../doc/offset-paged-response.md).

## Usage Example

```csharp
// Asynchronously iterating over items in all pages.
await foreach (var item in asyncPageable)
{
    Console.WriteLine(item);
}

// Asynchronously iterating over pages in the paginated response.
await foreach (var pagedResponse in asyncPageable.GetPagesAsync())
{
    switch (pagedResponse)
    {
        case CursorPagedResponse<TItem, TPage> cursorPagedResponse:
            Console.WriteLine(cursorPagedResponse.NextCursor);
            break;
        case NumberPagedResponse<TItem, TPage> numberPagedResponse:
            Console.WriteLine(numberPagedResponse.PageNumber);
            break;
        case LinkPagedResponse<TItem, TPage> linkPagedResponse:
            Console.WriteLine(linkPagedResponse.NextLink);
            break;
        case OffsetPagedResponse<TItem, TPage> offsetPagedResponse:
            Console.WriteLine(offsetPagedResponse.Offset);
            break;
    }

    Console.WriteLine(pagedResponse.Data);

    // Iterating over items in the current page (synchronously).
    foreach (var item in pagedResponse.Items)
    {
        Console.WriteLine(item);
    }
}
```

