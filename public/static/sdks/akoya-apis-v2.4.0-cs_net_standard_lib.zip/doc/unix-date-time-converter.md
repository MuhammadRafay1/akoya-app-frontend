
# UnixDateTimeConverter

Extends from DateTimeConverterBase, uses unix DateTime format.

## Properties

| Name | Description | Type |
|  --- | --- | --- |
| DateTimeStyles | Gets or sets DateTimeStyles. | `DateTimeStyles` |

