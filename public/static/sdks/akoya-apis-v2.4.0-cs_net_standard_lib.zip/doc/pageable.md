
# Pageable

An iterable wrapper for paginated data that allows iteration over pages or individual items. It fetches and iterates over each element in all the pages lazily.

This class implements 'IEnumerable`to provide lazy iteration over all items and exposes a`GetPages()` method for page-level iteration.

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `GetEnumerator()` | Provides an enumerator to sequentially access all items across all pages. Pages are fetched lazily. | `IEnumerator of items` |
| `GetPages()` | Retrieves an enumerable collection of all pages, enabling lazy iteration through pages. Supports multiple paging types. | <code>Pageable<BasePagedResponse<TItem, TPage>></code> |

Here the BasePagedResponse is a base class and it can be an instance of [`LinkPagedResponse`](../doc/link-paged-response.md), [`CursorPagedResponse`](../doc/cursor-paged-response.md), [`NumberPagedResponse`](../doc/number-paged-response.md) or [`OffsetPagedResponse`](../doc/offset-paged-response.md).

## Usage Example

```csharp
// Iterating over items in all pages.
foreach (var item in pageable)
{
    Console.WriteLine(item);
}

// Iterating over pages in the paginated response.
foreach (var pagedResponse in pageable.GetPages())
{
    switch (pagedResponse)
    {
        case CursorPagedResponse<TItem, TPage> cursorPagedResponse:
            Console.WriteLine(cursorPagedResponse.NextCursor);
            break;
        case NumberPagedResponse<TItem, TPage> numberPagedResponse:
            Console.WriteLine(numberPagedResponse.PageNumber);
            break;
        case LinkPagedResponse<TItem, TPage> linkPagedResponse:
            Console.WriteLine(linkPagedResponse.NextLink);
            break;
        case OffsetPagedResponse<TItem, TPage> offsetPagedResponse:
            Console.WriteLine(offsetPagedResponse.Offset);
            break;
    }

    Console.WriteLine(pagedResponse.Data);

    // Iterating over items in the current page.
    foreach (var item in pagedResponse.Items)
    {
        Console.WriteLine(item);
    }
}
```

