
# Open Order Entity

Information on an open order.

*This model accepts additional fields of type object.*

## Structure

`OpenOrderEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OrderId` | `string` | Optional | Long term persistent identity of the order. Id for this order transaction. |
| `SecurityId` | `string` | Optional | Unique identifier of the security. |
| `SecurityIdType` | [`SecurityIdType?`](../../doc/models/security-id-type.md) | Optional | Security identifier type |
| `Symbol` | `string` | Optional | Market symbol |
| `Description` | `string` | Optional | Description of order |
| `Units` | `double?` | Optional | Number of units (shares, bonds, etc.) |
| `OrderType` | [`OrderType?`](../../doc/models/order-type.md) | Optional | Type of order. |
| `OrderDate` | `DateTime?` | Optional | Order date |
| `UnitPrice` | `double?` | Optional | Unit price |
| `UnitType` | [`UnitType?`](../../doc/models/unit-type.md) | Optional | Type of unit. |
| `OrderDuration` | [`OrderDuration?`](../../doc/models/order-duration.md) | Optional | This order is good for DAY, GOODTILLCANCEL, IMMEDIATE |
| `SubAccount` | [`SubAccount?`](../../doc/models/sub-account.md) | Optional | - |
| `LimitPrice` | `double?` | Optional | Limit Price |
| `StopPrice` | `double?` | Optional | Stop price |
| `Inv401KSource` | [`Inv401KSource?`](../../doc/models/inv-401-k-source.md) | Optional | For 401(k) accounts, source of money for this order. Default if not present is OTHERNONVEST. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "orderId": "orderId4",
  "securityId": "securityId6",
  "securityIdType": "VALOR",
  "symbol": "symbol0",
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

