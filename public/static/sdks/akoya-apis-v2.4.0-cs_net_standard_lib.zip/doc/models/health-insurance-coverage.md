
# Health Insurance Coverage

Used on Form 1095-A Part III

*This model accepts additional fields of type object.*

## Structure

`HealthInsuranceCoverage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EnrollmentPremium` | `double?` | Optional | Monthly enrollment premiums |
| `SlcspPremium` | `double?` | Optional | Monthly second lowest cost silver plan (SLCSP) premium |
| `AdvancePremiumTaxCreditPayment` | `double?` | Optional | Monthly advance payment of premium tax credit |
| `Month` | [`CoverageMonth1?`](../../doc/models/coverage-month-1.md) | Optional | Month of coverage |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "enrollmentPremium": 139.74,
  "slcspPremium": 163.34,
  "advancePremiumTaxCreditPayment": 197.06,
  "month": "MAY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

