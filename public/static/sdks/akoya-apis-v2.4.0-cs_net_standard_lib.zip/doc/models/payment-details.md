
# Payment Details

Payment details for some transactions

*This model accepts additional fields of type object.*

## Structure

`PaymentDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EscrowAmount` | `double?` | Optional | The amount of payment applied to escrow |
| `FeesAmount` | `double?` | Optional | The amount of payment applied to fees |
| `InsuranceAmount` | `double?` | Optional | The amount of payment applied to life/health/accident insurance on the loan |
| `InterestAmount` | `double?` | Optional | The amount of payment applied to interest |
| `PmiAmount` | `double?` | Optional | The amount of payment applied to PMI |
| `PrincipalAmount` | `double?` | Optional | The amount of payment applied to principal |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "escrowAmount": 171.3,
  "feesAmount": 83.52,
  "insuranceAmount": 63.4,
  "interestAmount": 64.72,
  "pmiAmount": 217.98,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

