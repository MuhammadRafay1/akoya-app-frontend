
# Name and Address

Individual or business name with address

*This model accepts additional fields of type object.*

## Structure

`NameAndAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Line1` | `string` | Optional | Address line 1 |
| `Line2` | `string` | Optional | Address line 2 |
| `Line3` | `string` | Optional | Address line 3 |
| `City` | `string` | Optional | City |
| `Region` | `string` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode' |
| `PostalCode` | `string` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` |
| `Country` | [`Iso3166CountryCode2?`](../../doc/models/iso-3166-country-code-2.md) | Optional | Country code |
| `Name1` | `string` | Optional | Name line 1 |
| `Name2` | `string` | Optional | Name line 2 |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "line1": "line10",
  "line2": "line22",
  "line3": "line30",
  "city": "city8",
  "region": "region4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

