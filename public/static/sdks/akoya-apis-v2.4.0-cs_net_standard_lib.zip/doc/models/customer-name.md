
# Customer Name

*This model accepts additional fields of type object.*

## Structure

`CustomerName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `First` | `string` | Optional | First or given name. This data element may contain first & last name if not separated. |
| `Middle` | `string` | Optional | - |
| `Last` | `string` | Optional | - |
| `Prefix` | `string` | Optional | Name prefix, e.g. Mr. |
| `Suffix` | `string` | Optional | Generational or academic suffix |
| `Company` | `string` | Optional | Company name |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

