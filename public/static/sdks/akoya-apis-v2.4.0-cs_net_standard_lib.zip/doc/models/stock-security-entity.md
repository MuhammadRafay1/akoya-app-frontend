
# Stock Security Entity

Information about the stock security specific to the type of security

*This model accepts additional fields of type object.*

## Structure

`StockSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UnitsStreet` | `double?` | Optional | Units in the FI's street name, positive quantity |
| `UnitsUser` | `double?` | Optional | Units in user's name directly, positive  quantity |
| `ReinvestDividends` | `bool?` | Optional | Reinvest dividends |
| `StockType` | [`StockType?`](../../doc/models/stock-type.md) | Optional | - |
| `Yield` | `double?` | Optional | Current yield |
| `YieldAsOfDate` | `DateTime?` | Optional | Yield as-of date |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "unitsStreet": 117.56,
  "unitsUser": 92.52,
  "reinvestDividends": false,
  "stockType": "STOCK",
  "yield": 211.18,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

