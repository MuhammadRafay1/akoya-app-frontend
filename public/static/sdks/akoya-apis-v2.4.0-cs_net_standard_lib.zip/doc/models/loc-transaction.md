
# Loc Transaction

A line of credit transaction of type

*This model accepts additional fields of type object.*

## Structure

`LocTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `string` | Optional | Corresponds to AccountId in Account |
| `Amount` | `double?` | Optional | The amount of money in the account currency.<br><br>If balanceType is `ASSET`:<br><br>1. If `debitCreditMemo` = `DEBIT`, sign is "+" or not present<br>2. If `CREDIT`, sign is "-"<br><br>If balanceType is `LIABILITY`:<br><br>1. If `debitCreditMemo` = `DEBIT`, sign is "-"<br>2. If `CREDIT`, sign is "+" or not present |
| `Category` | `string` | Optional | Transaction category, preferably MCC or SIC. |
| `DebitCreditMemo` | [`DebitCreditMemo?`](../../doc/models/debit-credit-memo.md) | Optional | Akoya will ensure that this is correctly populated with one of DEBIT or CREDIT and matches the sign of the status field. |
| `Description` | `string` | Optional | The description of the transaction |
| `ImageIds` | `List<string>` | Optional | Array of image identifiers (unique to transaction) used to retrieve images of check or transaction receipt. |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ForeignAmount` | `double?` | Optional | The amount of money in the foreign currency |
| `ForeignCurrency` | `string` | Optional | The ISO 4217 code of the foreign currency |
| `LineItem` | [`List<LineItem>`](../../doc/models/line-item.md) | Optional | Breakdown of the transaction details |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links (unique to this Transaction) used to retrieve images of checks or transaction receipts, or invoke other APIs |
| `Memo` | `string` | Optional | Secondary transaction description |
| `PostedTimestamp` | `DateTime?` | Optional | The date and time that the transaction was posted to the account. If not provided then TransactionTimestamp can be used as PostedTimeStamp. |
| `Reference` | `string` | Optional | A tracking reference identifier |
| `ReferenceTransactionId` | `string` | Optional | Akoya ensures that this field is populated for all transactions which are reversals, otherwise it is null. Either way it is always present.<br><br>For reverse postings, the identity of the transaction being reversed. For the correction transaction, the identity of the reversing post. For credit card posting transactions, the identity of the authorization transaction. |
| `Status` | [`Status1?`](../../doc/models/status-1.md) | Optional | AUTHORIZATION, MEMO, PENDING, or POSTED |
| `SubCategory` | `string` | Optional | Transaction category detail |
| `TransactionId` | `string` | Optional | Long term persistent identity of the transaction (unique to account).<br>Transaction IDs should:<br><br>1. be the same for pending and posted<br>2. be different for reversed transactions<br>3. `referenceTransactionId` should be present for reversed transactions' |
| `TransactionTimestamp` | `DateTime?` | Optional | The date and time that the transaction was added to the server backend systems.<br><br>Akoya ensures that this field is populated for all transactions to which it applies, otherwise it is null. Either way it is always present. |
| `CheckNumber` | `int?` | Optional | Check number |
| `PaymentDetails` | [`PaymentDetails`](../../doc/models/payment-details.md) | Optional | Payment details for some transactions |
| `TransactionType` | [`TransactionType4?`](../../doc/models/transaction-type-4.md) | Optional | LocTransaction Type |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId6",
  "amount": 70.88,
  "category": "category4",
  "debitCreditMemo": "DEBIT",
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

