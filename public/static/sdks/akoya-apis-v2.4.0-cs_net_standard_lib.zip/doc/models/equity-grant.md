
# Equity Grant

*This model accepts additional fields of type object.*

## Structure

`EquityGrant`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GrantId` | `string` | Optional | Unique identifier of grant |
| `GrantDate` | `DateTime?` | Optional | Date grant was given |
| `GrantType` | `string` | Optional | Type of grant |
| `SeqNum` | `double?` | Optional | - |
| `GrantPrice` | `double?` | Optional | Grant price |
| `GrantCurrencyCode` | `string` | Optional | Indicates the currency of grant USD vs AUD vs EUR etc (for share awards, you will still get a USD) |
| `QuantityGranted` | `double?` | Optional | Number of options |
| `QuantityOutstanding` | `double?` | Optional | - |
| `ExpirationDate` | `DateTime?` | Optional | Date grant expires |
| `Vestings` | [`List<Vesting>`](../../doc/models/vesting.md) | Optional | An array of equityGrant vestings. Provides the past, present, and future vesting schedule and percentages. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "grantId": "grantId0",
  "grantDate": "2016-03-13T12:52:32.123Z",
  "grantType": "grantType0",
  "seqNum": 174.64,
  "grantPrice": 12.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

