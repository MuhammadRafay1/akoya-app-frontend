
# Sweep Security Entity

Information about the sweep security specific to the type of security

*This model accepts additional fields of type object.*

## Structure

`SweepSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CurrentBalance` | `double?` | Optional | Balance of funds in account |
| `AvailableBalance` | `double?` | Optional | Balance of funds available for use |
| `BalanceAsOf` | `DateTime?` | Optional | As-of date of balances |
| `Checks` | `bool?` | Optional | Whether or not checks can be written on the account |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "currentBalance": 188.98,
  "availableBalance": 101.4,
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "checks": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

