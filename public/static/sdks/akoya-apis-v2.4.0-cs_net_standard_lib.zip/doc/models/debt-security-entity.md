
# Debt Security Entity

Information about the debt security specific to the type of security

*This model accepts additional fields of type object.*

## Structure

`DebtSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParValue` | `double?` | Optional | Par value amount |
| `DebtType` | [`DebtType?`](../../doc/models/debt-type.md) | Optional | Debt type |
| `DebtClass` | [`DebtClass?`](../../doc/models/debt-class.md) | Optional | Classification of debt |
| `CouponRate` | `double?` | Optional | Bond coupon rate for next closest call date |
| `CouponDate` | `DateTime?` | Optional | Maturity date for next coupon |
| `CouponMatureFrequency` | [`CouponMatureFrequency?`](../../doc/models/coupon-mature-frequency.md) | Optional | When coupons mature |
| `CallPrice` | `double?` | Optional | Bond call price |
| `YieldToCall` | `double?` | Optional | Yield to next call |
| `CallDate` | `DateTime?` | Optional | Next call date |
| `CallType` | [`CallType?`](../../doc/models/call-type.md) | Optional | Type of next call |
| `YieldToMaturity` | `double?` | Optional | Yield to maturity |
| `BondMaturityDate` | `DateTime?` | Optional | Bond Maturity date |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "parValue": 18.14,
  "debtType": "ASSET",
  "debtClass": "CORPORATE",
  "couponRate": 229.02,
  "couponDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

