
# Business Income Statement

Business Income Statement for IRS Form 1040 Schedule C

*This model accepts additional fields of type object.*

## Structure

`BusinessIncomeStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxYear` | `int?` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `Corrected` | `bool?` | Optional | True to indicate this is a corrected tax form |
| `AccountId` | `string` | Optional | Long-term persistent identity of the source account. Not the account number |
| `TaxFormId` | `string` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. |
| `TaxFormDate` | `DateTime?` | Optional | Date of production or delivery of the tax form |
| `AdditionalInformation` | `string` | Optional | Additional explanation text or content about this tax form |
| `TaxFormType` | [`TypeFormType2?`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. |
| `Error` | [`Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs |
| `BusinessName` | `string` | Optional | Box C, Business name |
| `Sales` | `double?` | Optional | Box 1, Gross receipts or sales |
| `Returns` | `double?` | Optional | Box 2, Returns and allowances |
| `OtherIncome` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 6, Other income, including federal and state gasoline or fuel tax credit or refund |
| `Advertising` | `double?` | Optional | Box 8, Advertising |
| `CarAndTruck` | `double?` | Optional | Box 9, Car and truck expenses |
| `Commissions` | `double?` | Optional | Box 10, Commissions and fees |
| `ContractLabor` | `double?` | Optional | Box 11, Contract labor |
| `Depletion` | `double?` | Optional | Box 12, Depletion |
| `Depreciation` | `double?` | Optional | Box 13, Depreciation |
| `EmployeeBenefits` | `double?` | Optional | Box 14, Employee benefit programs |
| `Insurance` | `double?` | Optional | Box 15, Insurance |
| `MortgageInterest` | `double?` | Optional | Box 16a, Mortgage interest |
| `OtherInterest` | `double?` | Optional | Box 16b, Other interest |
| `Legal` | `double?` | Optional | Box 17, Legal and professional services |
| `Office` | `double?` | Optional | Box 18, Office expense |
| `Pension` | `double?` | Optional | Box 19, Pension and profit-sharing plans |
| `EquipmentRent` | `double?` | Optional | Box 20a, Equipment rent |
| `OtherRent` | `double?` | Optional | Box 20b, Other rent |
| `Repairs` | `double?` | Optional | Box 21, Repairs and maintenance |
| `Supplies` | `double?` | Optional | Box 22, Supplies |
| `Taxes` | `double?` | Optional | Box 23, Taxes and licenses |
| `Travel` | `double?` | Optional | Box 24a, Travel |
| `Meals` | `double?` | Optional | Box 24b, Deductible meals |
| `Utilities` | `double?` | Optional | Box 25, Utilities |
| `Wages` | `double?` | Optional | Box 26, Wages |
| `OtherExpenses` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 27, Other expenses |
| `BeginningInventory` | `double?` | Optional | Box 35, Inventory at beginning of year |
| `Purchases` | `double?` | Optional | Box 36, Purchases |
| `CostOfLabor` | `double?` | Optional | Box 37, Cost of labor |
| `Materials` | `double?` | Optional | Box 38, Materials and supplies |
| `OtherCosts` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 39, Other costs |
| `EndingInventory` | `double?` | Optional | Box 41, Inventory at end of year |
| `CapitalExpenditures` | [`List<DateAndAmount>`](../../doc/models/date-and-amount.md) | Optional | Capital expenditures, for use in calculating Depreciation |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId0",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

