
# Local Tax Withholding 1

Amount of local income tax withheld, if any

*This model accepts additional fields of type object.*

## Structure

`LocalTaxWithholding1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxWithheld` | `double?` | Optional | Amount of local income tax withheld |
| `LocalityName` | `string` | Optional | Locality name |
| `Income` | `double?` | Optional | Income amount for local tax purposes |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 15.4,
  "localityName": "localityName2",
  "income": 207.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

