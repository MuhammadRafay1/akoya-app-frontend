
# Contribution Entity

Describes how new contributions are distributed among the available securities.

*This model accepts additional fields of type object.*

## Structure

`ContributionEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SecurityId` | `string` | Optional | Unique identifier of security |
| `SecurityIdType` | [`SecurityIdType?`](../../doc/models/security-id-type.md) | Optional | Security identifier type |
| `EmployerMatchPercentage` | `double?` | Optional | Employer contribution match percentage |
| `EmployerMatchAmount` | `double?` | Optional | Employer contribution match amount |
| `EmployeePreTaxAmount` | `double?` | Optional | Employee pre‐tax contribution amount |
| `EmployeePreTaxPercentage` | `double?` | Optional | Employee pre‐tax contribution percentage |
| `EmployeeAfterTaxAmount` | `double?` | Optional | Employee after tax contribution amount |
| `EmployeeAfterTaxPercentage` | `double?` | Optional | Employee after tax contribution percentage |
| `EmployeeDeferPreTaxAmount` | `double?` | Optional | Employee defer pre‐tax contribution match amount |
| `EmployeeDeferPreTaxPercentage` | `double?` | Optional | Employee defer pre‐tax contribution match percentage |
| `EmployeeYearToDate` | `double?` | Optional | Employee total year to date contribution |
| `EmployerYearToDate` | `double?` | Optional | Employer total year to date contribution |
| `RolloverContributionPercentage` | `double?` | Optional | Rollover contribution percentage |
| `RolloverContributionAmount` | `double?` | Optional | Rollover contribution Amount |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "employerMatchPercentage": 195.92,
  "employerMatchAmount": 120.16,
  "employeePreTaxAmount": 147.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

