
# Holding Sub Type

## Enumeration

`HoldingSubType`

## Fields

| Name |
|  --- |
| `Moneymarket` |
| `Cash` |

