
# Business Name

Name 1, Name 2

*This model accepts additional fields of type object.*

## Structure

`BusinessName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name1` | `string` | Optional | Name line 1 |
| `Name2` | `string` | Optional | Name line 2 |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "name1": "name16",
  "name2": "name20",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

