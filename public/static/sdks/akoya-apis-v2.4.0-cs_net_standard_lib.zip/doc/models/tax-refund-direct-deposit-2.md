
# Tax Refund Direct Deposit 2

Tax refund direct deposit information

*This model accepts additional fields of type object.*

## Structure

`TaxRefundDirectDeposit2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InstitutionName` | `string` | Optional | Name of institution |
| `Rtn` | `string` | Optional | Routing transit number |
| `AccountNumber` | `string` | Optional | Account number |
| `AccountNickName` | `string` | Optional | Account nickname |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "institutionName": "institutionName0",
  "rtn": "rtn6",
  "accountNumber": "accountNumber0",
  "accountNickName": "accountNickName8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

