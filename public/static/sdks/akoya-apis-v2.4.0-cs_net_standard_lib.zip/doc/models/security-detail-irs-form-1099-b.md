
# Security Detail Irs Form 1099 B

Tax information for a single security transaction

*This model accepts additional fields of type object.*

## Structure

`SecurityDetailIrsForm1099B`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CheckboxOnForm8949` | `string` | Optional | Applicable checkbox on Form 8949 |
| `SecurityName` | `string` | Optional | Security name |
| `NumberOfShares` | `double?` | Optional | Number of shares |
| `SaleDescription` | `string` | Optional | Box 1a, Description of property |
| `DateAcquired` | `DateTime?` | Optional | Box 1b, Date acquired |
| `VariousDatesAcquired` | `bool?` | Optional | Box 1b, Date acquired Various |
| `DateOfSale` | `DateTime?` | Optional | Box 1c, Date sold or disposed |
| `SalesPrice` | `double?` | Optional | Box 1d, Proceeds (not price per share) |
| `AccruedMarketDiscount` | `double?` | Optional | Box 1f, Accrued market discount |
| `AdjustmentCodes` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Other adjustments (code and amount) |
| `CostBasis` | `double?` | Optional | Box 1e, Cost or other basis |
| `CorrectedCostBasis` | `double?` | Optional | Corrected cost basis. May be supplied in lieu of adjustmentCode code B. If both adjustmentCodes and correctedCostBasis are supplied, costBasis plus adjustmentCode B should equal correctedCostBasis |
| `WashSaleLossDisallowed` | `double?` | Optional | Box 1g, Wash sale loss disallowed |
| `LongOrShort` | [`SaleTermType2?`](../../doc/models/sale-term-type-2.md) | Optional | Box 2, LONG or SHORT |
| `Ordinary` | `bool?` | Optional | Box 2, Ordinary |
| `Collectible` | `bool?` | Optional | Box 3, Collectibles |
| `Qof` | `bool?` | Optional | Box 3, Qualified Opportunity Fund (QOF) |
| `FederalTaxWithheld` | `double?` | Optional | Box 4, Federal income tax withheld |
| `NoncoveredSecurity` | `bool?` | Optional | Box 5, Noncovered security |
| `GrossOrNet` | [`SaleProceedsType1?`](../../doc/models/sale-proceeds-type-1.md) | Optional | Box 6, Reported to IRS: GROSS or NET |
| `LossNotAllowed` | `bool?` | Optional | Box 7, Loss not allowed based on proceeds |
| `BasisReported` | `bool?` | Optional | Box 12, Basis reported to IRS |
| `StateAndLocal` | [`List<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 14-16, State and Local tax withholding |
| `Cusip` | `string` | Optional | CUSIP number |
| `ForeignAccountTaxCompliance` | `bool?` | Optional | Foreign account tax compliance |
| `ExpiredOption` | [`ExpiredOptionType1?`](../../doc/models/expired-option-type-1.md) | Optional | To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED |
| `InvestmentSaleType` | [`InvestmentSaleType?`](../../doc/models/investment-sale-type.md) | Optional | Type of investment sale |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "dateAcquired": "2021-07-15",
  "dateOfSale": "2021-07-15",
  "checkboxOnForm8949": "checkboxOnForm89498",
  "securityName": "securityName6",
  "numberOfShares": 126.44,
  "saleDescription": "saleDescription4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

