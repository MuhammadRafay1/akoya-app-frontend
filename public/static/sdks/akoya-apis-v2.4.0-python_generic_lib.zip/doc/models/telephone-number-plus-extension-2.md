
# Telephone Number Plus Extension 2

PSE's phone number

*This model accepts additional fields of type Any.*

## Structure

`TelephoneNumberPlusExtension2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`TelephoneNumberType2`](../../doc/models/telephone-number-type-2.md) | Optional | Type of phone number: HOME, BUSINESS, CELL, FAX |
| `country` | `str` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164<br><br>**Constraints**: *Maximum Length*: `3` |
| `number` | `str` | Optional | Telephone subscriber number defined by ITU-T recommendation E.164<br><br>**Constraints**: *Maximum Length*: `15`, *Pattern*: `\d+` |
| `extension` | `str` | Optional | An arbitrary length telephone number extension |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "FAX",
  "country": "country4",
  "number": "number2",
  "extension": "extension6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

