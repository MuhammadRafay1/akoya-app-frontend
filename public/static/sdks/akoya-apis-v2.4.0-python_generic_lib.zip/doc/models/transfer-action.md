
# Transfer Action

Transfer direction.

## Enumeration

`TransferAction`

## Fields

| Name |
|  --- |
| `IN` |
| `OUT` |

