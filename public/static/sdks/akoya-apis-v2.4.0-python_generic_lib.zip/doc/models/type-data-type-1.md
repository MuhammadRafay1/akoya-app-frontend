
# Type Data Type 1

Whether this `application/json` tax form response contains data in `forms` property (as 'JSON' format) or `pdf` property (as 'BASE64_PDF' format)

## Enumeration

`TypeDataType1`

## Fields

| Name |
|  --- |
| `BASE64_PDF` |
| `JSON` |

