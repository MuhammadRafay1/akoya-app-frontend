
# Investment Sale Type

Type of investment sale

## Enumeration

`InvestmentSaleType`

## Fields

| Name |
|  --- |
| `CRYPTOCURRENCY` |
| `EMPLOYEE_STOCK_PURCHASE_PLAN` |
| `INCENTIVE_STOCK_OPTION` |
| `NONQUALIFIED_STOCK_OPTIONS` |
| `OTHER` |
| `RESTRICTED_STOCK` |
| `RESTRICTED_STOCK_UNITS` |

