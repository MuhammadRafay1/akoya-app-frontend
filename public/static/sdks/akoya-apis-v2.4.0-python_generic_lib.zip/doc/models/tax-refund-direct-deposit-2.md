
# Tax Refund Direct Deposit 2

Tax refund direct deposit information

*This model accepts additional fields of type Any.*

## Structure

`TaxRefundDirectDeposit2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_name` | `str` | Optional | Name of institution |
| `rtn` | `str` | Optional | Routing transit number |
| `account_number` | `str` | Optional | Account number |
| `account_nick_name` | `str` | Optional | Account nickname |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "institutionName": "institutionName0",
  "rtn": "rtn6",
  "accountNumber": "accountNumber0",
  "accountNickName": "accountNickName8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

