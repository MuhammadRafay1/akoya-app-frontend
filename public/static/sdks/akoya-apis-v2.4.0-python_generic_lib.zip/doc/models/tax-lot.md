
# Tax Lot

*This model accepts additional fields of type Any.*

## Structure

`TaxLot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cost_basis` | `float` | Optional | Total amount of money spent acquiring this lot including any fees or commission expenses incurred. |
| `current_value` | `float` | Optional | Lot market value |
| `original_purchase_date` | `datetime` | Optional | Lot acquired date. |
| `postion_type` | [`PostionType`](../../doc/models/postion-type.md) | Optional | LONG, SHORT. |
| `purchased_price` | `float` | Optional | Original purchase price. |
| `quantity` | `float` | Optional | Lot quantity. |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "costBasis": 225.68,
  "currentValue": 37.64,
  "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
  "postionType": "LONG",
  "purchasedPrice": 14.46,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

