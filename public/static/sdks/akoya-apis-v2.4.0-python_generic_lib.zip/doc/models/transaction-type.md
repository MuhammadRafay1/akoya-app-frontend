
# Transaction Type

DepositTransaction Type

## Enumeration

`TransactionType`

## Fields

| Name |
|  --- |
| `CHECK` |
| `WITHDRAWAL` |
| `TRANSFER` |
| `POSDEBIT` |
| `ATMWITHDRAWAL` |
| `BILLPAYMENT` |
| `FEE` |
| `DEPOSIT` |
| `ADJUSTMENT` |
| `INTEREST` |
| `DIVIDEND` |
| `DIRECTDEPOSIT` |
| `ATMDEPOSIT` |
| `POSCREDIT` |

