
# Interaction Type

## Enumeration

`InteractionType`

## Fields

| Name |
|  --- |
| `USER` |
| `BATCH` |

