
# Frequency

## Enumeration

`Frequency`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BIWEEKLY` |
| `DAILY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `SEMIMONTHLY` |
| `WEEKLY` |

