
# Postion Type

LONG, SHORT.

## Enumeration

`PostionType`

## Fields

| Name |
|  --- |
| `LONG` |
| `SHORT` |

