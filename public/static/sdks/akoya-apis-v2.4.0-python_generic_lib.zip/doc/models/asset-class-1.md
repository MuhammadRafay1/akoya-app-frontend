
# Asset Class 1

## Enumeration

`AssetClass1`

## Fields

| Name |
|  --- |
| `DOMESTICBOND` |
| `INTLBOND` |
| `LARGESTOCK` |
| `SMALLSTOCK` |
| `INTLSTOCK` |
| `MONEYMARKET` |
| `OTHER` |

