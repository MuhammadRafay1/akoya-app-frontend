
# Sale Term Type

Long or short term. Used by Form 1099-B

## Enumeration

`SaleTermType`

## Fields

| Name |
|  --- |
| `LONG` |
| `SHORT` |

