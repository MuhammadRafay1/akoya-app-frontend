
# Mutual Fund Type

Mutual fund type

## Enumeration

`MutualFundType`

## Fields

| Name |
|  --- |
| `OPENEND` |
| `CLOSEEND` |
| `OTHER` |

