
# Status

The status of an account.

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `OPEN` |
| `CLOSED` |
| `PENDINGOPEN` |
| `PENDINGCLOSE` |
| `DELINQUENT` |
| `PAID` |
| `NEGATIVECURRENTBALANCE` |

