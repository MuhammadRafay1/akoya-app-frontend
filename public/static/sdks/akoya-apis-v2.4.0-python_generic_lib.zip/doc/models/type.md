
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONPDF` |
| `ENUM_IMAGEGIF` |
| `ENUM_IMAGEJPEG` |
| `ENUM_IMAGETIFF` |
| `ENUM_IMAGEPNG` |
| `ENUM_APPLICATIONJSON` |

## Example

```
application/json
```

