
# Account Category

The account category of the insurance account. Possible enums: DEPOSIT_ACCOUNT, INVESTMENT_ACCOUNT, LOAN_ACCOUNT, LOC_ACCOUNT, INSURANCE_ACCOUNT

## Enumeration

`AccountCategory`

## Fields

| Name |
|  --- |
| `DEPOSIT_ACCOUNT` |
| `INVESTMENT_ACCOUNT` |
| `LOAN_ACCOUNT` |
| `LOC_ACCOUNT` |
| `INSURANCE_ACCOUNT` |

