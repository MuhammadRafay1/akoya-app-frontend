
# Coupon Mature Frequency

When coupons mature

## Enumeration

`CouponMatureFrequency`

## Fields

| Name |
|  --- |
| `MONTHLY` |
| `QUARTERLY` |
| `SEMIANNUAL` |
| `ANNUAL` |
| `OTHER` |

