
# Accept Media Type

## Enumeration

`AcceptMediaType`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONPDF` |

