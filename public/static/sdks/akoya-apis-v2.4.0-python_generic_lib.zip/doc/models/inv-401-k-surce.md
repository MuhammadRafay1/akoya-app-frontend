
# Inv 401 K Surce

Source for money for this security.

## Enumeration

`Inv401KSurce`

## Fields

| Name |
|  --- |
| `PRETAX` |
| `AFTERTAX` |
| `MATCH` |
| `PROFITSHARING` |
| `ROLLOVER` |
| `OTHERVEST` |
| `OTHERNONVEST` |

