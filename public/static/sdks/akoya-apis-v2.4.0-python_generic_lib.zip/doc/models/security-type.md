
# Security Type

## Enumeration

`SecurityType`

## Fields

| Name |
|  --- |
| `STOCK` |
| `MUTUALFUND` |
| `DEBT` |
| `OPTION` |
| `SWEEP` |
| `OTHER` |
| `BOND` |

