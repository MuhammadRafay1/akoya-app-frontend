
# Individual Name 3

Box g, Employee's previously reported name

*This model accepts additional fields of type Any.*

## Structure

`IndividualName3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `str` | Optional | First name |
| `middle` | `str` | Optional | Middle initial |
| `last` | `str` | Optional | Last name |
| `suffix` | `str` | Optional | Generational or academic suffix |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first8",
  "middle": "middle8",
  "last": "last8",
  "suffix": "suffix8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

