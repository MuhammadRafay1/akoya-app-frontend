
# Transaction Reason

Reason for this transaction; CALL (the debt was called), SELL (the debt was sold), MATURITY (the debt reached maturity)

## Enumeration

`TransactionReason`

## Fields

| Name |
|  --- |
| `CALL` |
| `SELL` |
| `MATURITY` |

