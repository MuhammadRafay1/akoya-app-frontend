
# Security Id Type

Security identifier type

## Enumeration

`SecurityIdType`

## Fields

| Name |
|  --- |
| `CUSIP` |
| `ISIN` |
| `SEDOL` |
| `SICC` |
| `VALOR` |
| `WKN` |

