
# Security Id Type 3

Security identifier type.

## Enumeration

`SecurityIdType3`

## Fields

| Name |
|  --- |
| `BUSIP` |
| `ISIN` |
| `SEDOL` |
| `SICC` |
| `VALOR` |
| `WKN` |

