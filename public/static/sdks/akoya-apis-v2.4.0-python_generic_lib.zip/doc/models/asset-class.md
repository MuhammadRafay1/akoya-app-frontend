
# Asset Class

*This model accepts additional fields of type Any.*

## Structure

`AssetClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_class` | [`AssetClass1`](../../doc/models/asset-class-1.md) | Optional | - |
| `percent` | `float` | Optional | Percentage of asset class that falls under this asset |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "assetClass": "INTLSTOCK",
  "percent": 150.26,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

