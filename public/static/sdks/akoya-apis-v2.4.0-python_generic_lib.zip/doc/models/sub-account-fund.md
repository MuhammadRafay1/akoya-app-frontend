
# Sub Account Fund

From which account money came in.

## Enumeration

`SubAccountFund`

## Fields

| Name |
|  --- |
| `CASH` |
| `MARGIN` |
| `SHORT` |
| `OTHERS` |

