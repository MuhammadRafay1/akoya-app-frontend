
# Expired Option Type 1

To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED

## Enumeration

`ExpiredOptionType1`

## Fields

| Name |
|  --- |
| `GRANTED` |
| `PURCHASED` |

