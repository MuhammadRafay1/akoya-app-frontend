
# Stock Type

## Enumeration

`StockType`

## Fields

| Name |
|  --- |
| `BOND` |
| `DEBT` |
| `MUTUALFUND` |
| `OPTION` |
| `OTHER` |
| `STOCK` |
| `SWEEP` |

