
# Address 2

*This model accepts additional fields of type Any.*

## Structure

`Address2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`LocationType`](../../doc/models/location-type.md) | Optional | The location type of an address |
| `line_1` | `str` | Optional | May contain full address if not separated |
| `line_2` | `str` | Optional | - |
| `line_3` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `state` | `str` | Optional | - |
| `postal_code` | `str` | Optional | - |
| `country` | `str` | Optional | ISO 3166 Country Code |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "HOME",
  "line1": "line14",
  "line2": "line26",
  "line3": "line34",
  "city": "city2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

