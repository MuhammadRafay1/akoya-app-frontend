
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| timeout | `number` | Timeout for API calls.<br>*Default*: `30000` |
| httpClientOptions | [`Partial<HttpClientOptions>`](../doc/http-client-options.md) | Stable configurable http client options. |
| unstableHttpClientOptions | `any` | Unstable configurable http client options. |
| logging | [`PartialLoggingOptions`](../doc/partial-logging-options.md) | Logging Configuration to enable logging |
| basicAuthCredentials | [`BasicAuthCredentials`](auth/basic-authentication.md) | The credential object for basicAuth |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The credential object for bearerAuth |
| acgAuthCredentials | [`AcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) | The credential object for acgAuth |

The API client can be initialized as follows:

```ts
import {
  Client,
  Environment,
  LogLevel,
  OauthScopeAcgAuth,
} from 'akoya-apis-v-2-4-0-lib';

const client = new Client({
  basicAuthCredentials: {
    username: 'Username',
    password: 'Password'
  },
  bearerAuthCredentials: {
    accessToken: 'AccessToken'
  },
  acgAuthCredentials: {
    oauthClientId: 'OAuthClientId',
    oauthClientSecret: 'OAuthClientSecret',
    oauthRedirectUri: 'OAuthRedirectUri',
    oauthScopes: [
      OauthScopeAcgAuth.Openid,
      OauthScopeAcgAuth.Profile
    ]
  },
  timeout: 30000,
  environment: Environment.Production,
  logging: {
    logLevel: LogLevel.Info,
    logRequest: {
      logBody: true
    },
    logResponse: {
      logHeaders: true
    }
  },
});
```

