
# Fi Asset Class

*This model accepts additional fields of type unknown.*

## Structure

`FiAssetClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assetClass` | `string \| undefined` | Optional | FI-specific asset class |
| `percent` | `number \| undefined` | Optional | Percentage of asset class that falls under this asset |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 193.72,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

