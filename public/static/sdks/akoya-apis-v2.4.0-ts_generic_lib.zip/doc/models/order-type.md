
# Order Type

Type of order.

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `Buy` |
| `Sell` |
| `Buytocover` |
| `Buytoopen` |
| `Selltocover` |
| `Selltoopen` |
| `Sellshort` |
| `Sellclose` |

