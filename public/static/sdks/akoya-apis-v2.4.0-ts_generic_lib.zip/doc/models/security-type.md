
# Security Type

## Enumeration

`SecurityType`

## Fields

| Name |
|  --- |
| `Stock` |
| `Mutualfund` |
| `Debt` |
| `Option` |
| `Sweep` |
| `Other` |
| `Bond` |

