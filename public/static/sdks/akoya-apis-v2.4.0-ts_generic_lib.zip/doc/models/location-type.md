
# Location Type

The location type of an address

## Enumeration

`LocationType`

## Fields

| Name |
|  --- |
| `Business` |
| `Home` |
| `Mailing` |

