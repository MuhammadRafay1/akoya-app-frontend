
# Stock Type

## Enumeration

`StockType`

## Fields

| Name |
|  --- |
| `Bond` |
| `Debt` |
| `Mutualfund` |
| `Option` |
| `Other` |
| `Stock` |
| `Sweep` |

