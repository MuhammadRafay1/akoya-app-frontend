
# Form W2

Wage and Tax Statement, from Employer (boxes b-c as issuer) to Employee (boxes a, e-f as recipient)

*This model accepts additional fields of type unknown.*

## Structure

`FormW2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `taxYear` | `number \| undefined` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `corrected` | `boolean \| undefined` | Optional | True to indicate this is a corrected tax form |
| `accountId` | `string \| undefined` | Optional | Long-term persistent identity of the source account. Not the account number |
| `taxFormId` | `string \| undefined` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. |
| `taxFormDate` | `string \| undefined` | Optional | Date of production or delivery of the tax form |
| `additionalInformation` | `string \| undefined` | Optional | Additional explanation text or content about this tax form |
| `taxFormType` | [`TypeFormType2 \| undefined`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `issuer` | [`TaxParty8 \| undefined`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `recipient` | [`TaxParty1 \| undefined`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `attributes` | [`TaxFormAttribute[] \| undefined`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. |
| `error` | [`Error2 \| undefined`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form |
| `links` | [`HateoasLink[] \| undefined`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs |
| `controlNumber` | `string \| undefined` | Optional | Control number |
| `wages` | `number \| undefined` | Optional | Box 1, Wages, tips, other compensation |
| `federalTaxWithheld` | `number \| undefined` | Optional | Box 2, Federal income tax withheld |
| `socialSecurityWages` | `number \| undefined` | Optional | Box 3, Social security wages |
| `socialSecurityTaxWithheld` | `number \| undefined` | Optional | Box 4, Social security tax withheld |
| `medicareWages` | `number \| undefined` | Optional | Box 5, Medicare wages and tips |
| `medicareTaxWithheld` | `number \| undefined` | Optional | Box 6, Medicare tax withheld |
| `socialSecurityTips` | `number \| undefined` | Optional | Box 7, Social security tips |
| `allocatedTips` | `number \| undefined` | Optional | Box 8, Allocated tips |
| `dependentCareBenefit` | `number \| undefined` | Optional | Box 10, Dependent care benefits |
| `nonQualifiedPlan` | `number \| undefined` | Optional | Box 11, Nonqualified plans |
| `codes` | [`CodeAndAmount[] \| undefined`](../../doc/models/code-and-amount.md) | Optional | Box 12, Codes and amounts |
| `statutory` | `boolean \| undefined` | Optional | Box 13, Statutory employee |
| `retirementPlan` | `boolean \| undefined` | Optional | Box 13, Retirement plan |
| `thirdPartySickPay` | `boolean \| undefined` | Optional | Box 13, Third-party sick pay |
| `esppQualified` | `number \| undefined` | Optional | Employee Stock Purchase Plan Qualified Disposition amount |
| `esppNonQualified` | `number \| undefined` | Optional | Employee Stock Purchase Plan Nonqualified Disposition amount |
| `other` | [`DescriptionAndAmount[] \| undefined`](../../doc/models/description-and-amount.md) | Optional | Box 14, Other descriptions and amounts |
| `stateAndLocal` | [`StateAndLocalTaxWithholding[] \| undefined`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 15-20, State and Local tax withholding |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId4",
  "taxFormId": "taxFormId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

