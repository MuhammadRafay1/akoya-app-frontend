
# Getting Started with Akoya APIs v2.4.0

## Introduction

Akoya product APIs for data access. Default servers are set for the Akoya sandbox environment.

Akoya APIs include the following updates:

- v2.4.0
  - Added Tax product
- v2.3.0
  - Removed erroneous `accountId` query param from Taxlots endpoint
  - Added TaxLots endpoint
- v2.2.2
  - Added mode query parameter to Account Information, Balances, Investments, and Transactions to support standard mode.
  - Edited callouts for Account Holder endpoint
- v2.2.1
  - Fixed typo in `accountIds` query parameter for `/accounts-info`, `/balances`, `/accounts`
  - Added security method for `Account holder information` to bear token. Missing method defaulted to basic auth.
  - Added examples and descriptions to some schemas
  - Added HTTP status `429` FDX error `1207`.
- v2.2 Additions
  - Added optional `x-akoya-interaction-type` header to all endpoints to specify if a request is part of a batch process
  - Update of tags to organize endpoints by Akoya product
  - `206` response added to `/accounts-info`, `/balances`, `/accounts`
- v2.1 New Statements product and Customers product updated with additional endpoint, `Account holder information`.
- v2.0 Launch of Akoya products: Account Info, Balances, Investments, Transactions, Payments, Customers.

## Building

Supported Java version is **8+**.

The generated code uses a few Maven dependencies e.g., Jackson, OkHttp,
and Apache HttpClient. The reference to these dependencies is already
added in the pom.xml file will be installed automatically. Therefore,
you will need internet access for a successful build.

* In order to open the client library in Eclipse click on `File -> Import`.

![Importing SDK into Eclipse - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=import0)

* In the import dialog, select `Existing Java Project` and click `Next`.

![Importing SDK into Eclipse - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=import1)

* Browse to locate the folder containing the source code. Select the detected location of the project and click `Finish`.

![Importing SDK into Eclipse - Step 3](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=import2)

* Upon successful import, the project will be automatically built by Eclipse after automatically resolving the dependencies.

![Importing SDK into Eclipse - Step 4](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=import3)

* After successfully building the project, the client library needs to be installed as a Maven package in your local cache. Right-click on the project, select `Show in Local Terminal -> Terminal` or use `Ctrl + Alt + T` to open Terminal.

![Importing SDK into Eclipse - Step 5](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=openTerminal)

* In the terminal dialog, run the following command to install client library.

```
mvn install -Dmaven.test.skip=true -Dmaven.javadoc.skip=true
```

![Importing SDK into Eclipse - Step 6](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=installCommand)

## Installation

The following section explains how to use the AkoyaApIsV240Lib library in a new project.

### 1. Starting a new project

For starting a new project, click the menu command `File > New > Project`.

![Add a new project in Eclipse](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=createNewProject0)

Next, choose `Maven > Maven Project` and click `Next`.

![Create a new Maven Project - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=createNewProject1)

Here, make sure to use the current workspace by choosing `Use default Workspace location`, as shown in the picture below and click `Next`.

![Create a new Maven Project - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=createNewProject2)

Following this, select the *quick start* project type to create a simple project with an existing class and a `main` method. To do this, choose `maven-archetype-quickstart` item from the list and click `Next`.

![Create a new Maven Project - Step 3](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=createNewProject3)

In the last step, provide a `Group Id` and `Artifact Id` as shown in the picture below and click `Finish`.

![Create a new Maven Project - Step 4](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=createNewProject4)

### 2. Add reference of the library project

The created Maven project manages its dependencies using its `pom.xml` file. In order to add a dependency on the *AkoyaApIsV240Lib* client library, double click on the `pom.xml` file in the `Package Explorer`. Opening the `pom.xml` file will render a graphical view on the canvas. Here, switch to the `Dependencies` tab and click the `Add` button as shown in the picture below.

![Adding dependency to the client library - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=testProject0)

Clicking the `Add` button will open a dialog where you need to specify AkoyaApIsV240Lib in `Group Id`, akoya-ap-is-v240-lib in `Artifact Id` and 2.4.0 in the `Version` fields. Once added click `OK`. Save the `pom.xml` file.

![Adding dependency to the client library - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=testProject1)

![Adding sample code](https://apidocs.io/illustration/java?workspaceFolder=Akoya%20APIs%20v2.4.0-Java&workspaceName=AkoyaApIsV240&projectName=AkoyaApIsV240Lib&rootNamespace=com.akoya.ddp.sandboxproducts&groupId=AkoyaApIsV240Lib&artifactId=akoya-ap-is-v240-lib&version=2.4.0&step=testProject2)

### 3. Write sample code

Once the `SimpleConsoleApp` is created, a file named `App.java` will be visible in the *Package Explorer* with a `main` method. This is the entry point for the execution of the created project.
Here, you can add code to initialize the client library and instantiate a *Controller* class. Sample code to initialize the client library and using controller methods is given in the subsequent sections.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| basicAuthCredentials | [`BasicAuthCredentials`](doc/auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |
| bearerAuthCredentials | [`BearerAuthCredentials`](doc/auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| acgAuthCredentials | [`AcgAuthCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```java
import com.akoya.ddp.sandboxproducts.AkoyaApIsV240Client;
import com.akoya.ddp.sandboxproducts.Environment;
import com.akoya.ddp.sandboxproducts.authentication.AcgAuthModel;
import com.akoya.ddp.sandboxproducts.authentication.BasicAuthModel;
import com.akoya.ddp.sandboxproducts.authentication.BearerAuthModel;
import com.akoya.ddp.sandboxproducts.exceptions.ApiException;
import com.akoya.ddp.sandboxproducts.http.response.ApiResponse;
import com.akoya.ddp.sandboxproducts.models.OauthScopeAcgAuth;
import com.akoya.ddp.sandboxproducts.models.OauthToken;
import java.io.IOException;
import java.util.Arrays;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        AkoyaApIsV240Client client = new AkoyaApIsV240Client.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .basicAuthCredentials(new BasicAuthModel.Builder(
                    "Username",
                    "Password"
                )
                .build())
            .bearerAuthCredentials(new BearerAuthModel.Builder(
                    "AccessToken"
                )
                .build())
            .acgAuthCredentials(new AcgAuthModel.Builder(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri"
                )
                .oauthScopes(Arrays.asList(
                        OauthScopeAcgAuth.OPENID,
                        OauthScopeAcgAuth.PROFILE
                    ))
                .build())
            .environment(Environment.PRODUCTION)
            .build();

    }
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Sandbox server |
| environment2 | Products server |

## Authorization

This API uses the following authentication schemes.

* [`basicAuth (Basic Authentication)`](doc/auth/basic-authentication.md)
* [`bearerAuth (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)
* [`acgAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Accountinformation](doc/controllers/accountinformation.md)
* [Tax Beta](doc/controllers/tax-beta.md)
* [Balances](doc/controllers/balances.md)
* [Customers](doc/controllers/customers.md)
* [Investments](doc/controllers/investments.md)
* [Payments](doc/controllers/payments.md)
* [Statements](doc/controllers/statements.md)
* [Transactions](doc/controllers/transactions.md)

## SDK Infrastructure

### Configuration

* [ApiLoggingConfiguration](doc/api-logging-configuration.md)
* [ApiLoggingConfiguration.Builder](doc/api-logging-configuration-builder.md)
* [ApiRequestLoggingConfiguration.Builder](doc/api-request-logging-configuration-builder.md)
* [ApiResponseLoggingConfiguration.Builder](doc/api-response-logging-configuration-builder.md)
* [Configuration Interface](doc/configuration-interface.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration.Builder](doc/http-client-configuration-builder.md)
* [HttpProxyConfiguration](doc/http-proxy-configuration.md)
* [HttpProxyConfiguration.Builder](doc/http-proxy-configuration-builder.md)

### HTTP

* [Headers](doc/headers.md)
* [HttpCallback Interface](doc/http-callback-interface.md)
* [HttpContext](doc/http-context.md)
* [HttpBodyRequest](doc/http-body-request.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)

### Utilities

* [ApiException](doc/api-exception.md)
* [ApiResponse](doc/api-response.md)
* [LinkPagedResponse](doc/link-paged-response.md)
* [PagedFlux](doc/paged-flux.md)
* [PagedIterable](doc/paged-iterable.md)
* [PagedSupplier](doc/paged-supplier.md)
* [ApiHelper](doc/api-helper.md)
* [FileWrapper](doc/file-wrapper.md)
* [DateTimeHelper](doc/date-time-helper.md)

