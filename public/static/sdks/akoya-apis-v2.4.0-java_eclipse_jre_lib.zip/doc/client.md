
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](../doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| basicAuthCredentials | [`BasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| acgAuthCredentials | [`AcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```java
import com.akoya.ddp.sandboxproducts.AkoyaApIsV240Client;
import com.akoya.ddp.sandboxproducts.Environment;
import com.akoya.ddp.sandboxproducts.authentication.AcgAuthModel;
import com.akoya.ddp.sandboxproducts.authentication.BasicAuthModel;
import com.akoya.ddp.sandboxproducts.authentication.BearerAuthModel;
import com.akoya.ddp.sandboxproducts.exceptions.ApiException;
import com.akoya.ddp.sandboxproducts.http.response.ApiResponse;
import com.akoya.ddp.sandboxproducts.models.OauthScopeAcgAuth;
import com.akoya.ddp.sandboxproducts.models.OauthToken;
import java.io.IOException;
import java.util.Arrays;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        AkoyaApIsV240Client client = new AkoyaApIsV240Client.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .basicAuthCredentials(new BasicAuthModel.Builder(
                    "Username",
                    "Password"
                )
                .build())
            .bearerAuthCredentials(new BearerAuthModel.Builder(
                    "AccessToken"
                )
                .build())
            .acgAuthCredentials(new AcgAuthModel.Builder(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri"
                )
                .oauthScopes(Arrays.asList(
                        OauthScopeAcgAuth.OPENID,
                        OauthScopeAcgAuth.PROFILE
                    ))
                .build())
            .environment(Environment.PRODUCTION)
            .build();

    }
}
```

## Akoya APIs v2.4.0Client Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Apis

| Name | Description | Return Type |
|  --- | --- | --- |
| `getAccountinformationApi()` | Provides access to Accountinformation controller. | `AccountinformationApi` |
| `getBalancesApi()` | Provides access to Balances controller. | `BalancesApi` |
| `getCustomersApi()` | Provides access to Customers controller. | `CustomersApi` |
| `getInvestmentsApi()` | Provides access to Investments controller. | `InvestmentsApi` |
| `getPaymentsApi()` | Provides access to Payments controller. | `PaymentsApi` |
| `getStatementsApi()` | Provides access to Statements controller. | `StatementsApi` |
| `getTaxBetaApi()` | Provides access to TaxBeta controller. | `TaxBetaApi` |
| `getTransactionsApi()` | Provides access to Transactions controller. | `TransactionsApi` |
| `getOauthAuthorizationApi()` | Provides access to OauthAuthorization controller. | `OauthAuthorizationApi` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getLoggingConfig()` | Logging Configuration instance. | [`ReadonlyLoggingConfiguration`](../doc/api-logging-configuration.md) |
| `getBasicAuthCredentials()` | The credentials to use with BasicAuth. | [`BasicAuthCredentials`](auth/basic-authentication.md) |
| `getBearerAuthCredentials()` | The credentials to use with BearerAuth. | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) |
| `getAcgAuthCredentials()` | The credentials to use with AcgAuth. | [`AcgAuthCredentials`](auth/oauth-2-authorization-code-grant.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

