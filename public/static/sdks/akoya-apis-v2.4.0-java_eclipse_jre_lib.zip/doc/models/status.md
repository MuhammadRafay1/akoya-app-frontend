
# Status

The status of an account.

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `Open` |
| `Closed` |
| `Pendingopen` |
| `Pendingclose` |
| `Delinquent` |
| `Paid` |
| `Negativecurrentbalance` |

