
# Customer Name

*This model accepts additional fields of type Object.*

## Structure

`CustomerName`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `First` | `String` | Optional | First or given name. This data element may contain first & last name if not separated. | String getFirst() | setFirst(String first) |
| `Middle` | `String` | Optional | - | String getMiddle() | setMiddle(String middle) |
| `Last` | `String` | Optional | - | String getLast() | setLast(String last) |
| `Prefix` | `String` | Optional | Name prefix, e.g. Mr. | String getPrefix() | setPrefix(String prefix) |
| `Suffix` | `String` | Optional | Generational or academic suffix | String getSuffix() | setSuffix(String suffix) |
| `Company` | `String` | Optional | Company name | String getCompany() | setCompany(String company) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

