
# Loan Account

Loan Account

*This model accepts additional fields of type Object.*

## Structure

`LoanAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. | String getAccountId() | setAccountId(String accountId) |
| `AccountType` | `String` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. | String getAccountType() | setAccountType(String accountType) |
| `AccountNumberDisplay` | `String` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. | String getAccountNumberDisplay() | setAccountNumberDisplay(String accountNumberDisplay) |
| `Currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | CurrencyEntity getCurrency() | setCurrency(CurrencyEntity currency) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | - | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `Nickname` | `String` | Optional | Name given by the user. Used in UIs to assist in account selection | String getNickname() | setNickname(String nickname) |
| `ProductName` | `String` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection | String getProductName() | setProductName(String productName) |
| `Status` | [`Status`](../../doc/models/status.md) | Optional | The status of an account. | Status getStatus() | setStatus(Status status) |
| `LineOfBusiness` | `String` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. | String getLineOfBusiness() | setLineOfBusiness(String lineOfBusiness) |
| `BalanceType` | [`BalanceType`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) | BalanceType getBalanceType() | setBalanceType(BalanceType balanceType) |
| `InterestRate` | `Double` | Optional | Interest Rate of Account | Double getInterestRate() | setInterestRate(Double interestRate) |
| `InterestRateType` | [`InterestRateType`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. | InterestRateType getInterestRateType() | setInterestRateType(InterestRateType interestRateType) |
| `InterestRateAsOf` | `LocalDateTime` | Optional | Date of account’s interest rate | LocalDateTime getInterestRateAsOf() | setInterestRateAsOf(LocalDateTime interestRateAsOf) |
| `LastActivityDate` | `LocalDateTime` | Optional | Date that last transaction occurred on account | LocalDateTime getLastActivityDate() | setLastActivityDate(LocalDateTime lastActivityDate) |
| `MicrNumber` | `String` | Optional | MICR Number | String getMicrNumber() | setMicrNumber(String micrNumber) |
| `ParentAccountId` | `String` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. | String getParentAccountId() | setParentAccountId(String parentAccountId) |
| `PriorInterestRate` | `Double` | Optional | Previous Interest Rate of Account | Double getPriorInterestRate() | setPriorInterestRate(Double priorInterestRate) |
| `TransferIn` | `Boolean` | Optional | Account is eligible for incoming transfers | Boolean getTransferIn() | setTransferIn(Boolean transferIn) |
| `TransferOut` | `Boolean` | Optional | Account is eligible for outgoing transfers | Boolean getTransferOut() | setTransferOut(Boolean transferOut) |
| `CompoundingPeriod` | [`CompoundingPeriod`](../../doc/models/compounding-period.md) | Optional | - | CompoundingPeriod getCompoundingPeriod() | setCompoundingPeriod(CompoundingPeriod compoundingPeriod) |
| `LoanTerm` | `Integer` | Optional | Term of loan in months | Integer getLoanTerm() | setLoanTerm(Integer loanTerm) |
| `MaturityDate` | `LocalDateTime` | Optional | Maturity date | LocalDateTime getMaturityDate() | setMaturityDate(LocalDateTime maturityDate) |
| `OriginatingDate` | `LocalDateTime` | Optional | Loan origination date | LocalDateTime getOriginatingDate() | setOriginatingDate(LocalDateTime originatingDate) |
| `PaymentFrequency` | [`PaymentFrequency`](../../doc/models/payment-frequency.md) | Optional | - | PaymentFrequency getPaymentFrequency() | setPaymentFrequency(PaymentFrequency paymentFrequency) |
| `TotalNumberOfPayments` | `Integer` | Optional | Total number of payments | Integer getTotalNumberOfPayments() | setTotalNumberOfPayments(Integer totalNumberOfPayments) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId6",
  "accountType": "accountType6",
  "accountNumberDisplay": "accountNumberDisplay2",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

