
# Fi Asset Class

*This model accepts additional fields of type Object.*

## Structure

`FiAssetClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetClass` | `String` | Optional | FI-specific asset class | String getAssetClass() | setAssetClass(String assetClass) |
| `Percent` | `Double` | Optional | Percentage of asset class that falls under this asset | Double getPercent() | setPercent(Double percent) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 193.72,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

