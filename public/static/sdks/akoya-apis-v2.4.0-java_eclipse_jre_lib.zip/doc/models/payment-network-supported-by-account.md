
# Payment Network Supported by Account

This provides details required to execute a transaction against the account within the payment network

*This model accepts additional fields of type Object.*

## Structure

`PaymentNetworkSupportedByAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankId` | `String` | Optional | Bank identifier used by the payment network ie. Routing Number | String getBankId() | setBankId(String bankId) |
| `Identifier` | `String` | Optional | The number used to identify the account within the payment network. If identifierType is ACCOUNT_NUMBER, this is the account number. | String getIdentifier() | setIdentifier(String identifier) |
| `IdentifierType` | `String` | Optional | Type of identifier | String getIdentifierType() | setIdentifierType(String identifierType) |
| `Type` | `String` | Optional | Type of payment network | String getType() | setType(String type) |
| `TransferIn` | `Boolean` | Optional | Can transfer funds to the account using this information | Boolean getTransferIn() | setTransferIn(Boolean transferIn) |
| `TransferOut` | `Boolean` | Optional | Can transfer funds from the account using this information | Boolean getTransferOut() | setTransferOut(Boolean transferOut) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "bankId": "bankId0",
  "identifier": "identifier2",
  "identifierType": "identifierType4",
  "type": "type0",
  "transferIn": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

