
# Postion Type

LONG, SHORT.

## Enumeration

`PostionType`

## Fields

| Name |
|  --- |
| `MLong` |
| `MShort` |

