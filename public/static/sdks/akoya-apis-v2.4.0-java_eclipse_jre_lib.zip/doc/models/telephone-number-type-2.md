
# Telephone Number Type 2

Type of phone number: HOME, BUSINESS, CELL, FAX

## Enumeration

`TelephoneNumberType2`

## Fields

| Name |
|  --- |
| `Business` |
| `Cell` |
| `Fax` |
| `Home` |

