
# Holding

*This model accepts additional fields of type Object.*

## Structure

`Holding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `HoldingId` | `String` | Optional | Long term persistent identity of the holding | String getHoldingId() | setHoldingId(String holdingId) |
| `SecurityId` | `String` | Optional | Unique identifier of the security. | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type | SecurityIdType getSecurityIdType() | setSecurityIdType(SecurityIdType securityIdType) |
| `TaxLots` | [`List<Items>`](../../doc/models/items.md) | Optional | Breakdown by tax lot.<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<Items> getTaxLots() | setTaxLots(List<Items> taxLots) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "holdingId": "holdingId0",
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "taxLots": [
    {
      "costBasis": 131.38,
      "currentValue": 199.34,
      "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
      "positionType": "LONG",
      "purchasedPrice": 176.16,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "costBasis": 131.38,
      "currentValue": 199.34,
      "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
      "positionType": "LONG",
      "purchasedPrice": 176.16,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "costBasis": 131.38,
      "currentValue": 199.34,
      "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
      "positionType": "LONG",
      "purchasedPrice": 176.16,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

