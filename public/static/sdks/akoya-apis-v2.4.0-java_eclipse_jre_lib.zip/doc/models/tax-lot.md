
# Tax Lot

*This model accepts additional fields of type Object.*

## Structure

`TaxLot`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CostBasis` | `Double` | Optional | Total amount of money spent acquiring this lot including any fees or commission expenses incurred. | Double getCostBasis() | setCostBasis(Double costBasis) |
| `CurrentValue` | `Double` | Optional | Lot market value | Double getCurrentValue() | setCurrentValue(Double currentValue) |
| `OriginalPurchaseDate` | `LocalDateTime` | Optional | Lot acquired date. | LocalDateTime getOriginalPurchaseDate() | setOriginalPurchaseDate(LocalDateTime originalPurchaseDate) |
| `PostionType` | [`PostionType`](../../doc/models/postion-type.md) | Optional | LONG, SHORT. | PostionType getPostionType() | setPostionType(PostionType postionType) |
| `PurchasedPrice` | `Double` | Optional | Original purchase price. | Double getPurchasedPrice() | setPurchasedPrice(Double purchasedPrice) |
| `Quantity` | `Double` | Optional | Lot quantity. | Double getQuantity() | setQuantity(Double quantity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "costBasis": 225.68,
  "currentValue": 37.64,
  "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
  "postionType": "LONG",
  "purchasedPrice": 14.46,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

