
# Domicile

The country and region of the business customer's location

*This model accepts additional fields of type Object.*

## Structure

`Domicile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Region` | `String` | Optional | - | String getRegion() | setRegion(String region) |
| `Country` | `String` | Optional | - | String getCountry() | setCountry(String country) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "region": "region2",
  "country": "country0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

