
# Transaction Type 3

LoanTransaction Type

## Enumeration

`TransactionType3`

## Fields

| Name |
|  --- |
| `Adjustment` |
| `Fee` |
| `Interest` |
| `Payment` |

