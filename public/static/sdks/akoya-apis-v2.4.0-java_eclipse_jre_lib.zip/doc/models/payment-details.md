
# Payment Details

Payment details for some transactions

*This model accepts additional fields of type Object.*

## Structure

`PaymentDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EscrowAmount` | `Double` | Optional | The amount of payment applied to escrow | Double getEscrowAmount() | setEscrowAmount(Double escrowAmount) |
| `FeesAmount` | `Double` | Optional | The amount of payment applied to fees | Double getFeesAmount() | setFeesAmount(Double feesAmount) |
| `InsuranceAmount` | `Double` | Optional | The amount of payment applied to life/health/accident insurance on the loan | Double getInsuranceAmount() | setInsuranceAmount(Double insuranceAmount) |
| `InterestAmount` | `Double` | Optional | The amount of payment applied to interest | Double getInterestAmount() | setInterestAmount(Double interestAmount) |
| `PmiAmount` | `Double` | Optional | The amount of payment applied to PMI | Double getPmiAmount() | setPmiAmount(Double pmiAmount) |
| `PrincipalAmount` | `Double` | Optional | The amount of payment applied to principal | Double getPrincipalAmount() | setPrincipalAmount(Double principalAmount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "escrowAmount": 171.3,
  "feesAmount": 83.52,
  "insuranceAmount": 63.4,
  "interestAmount": 64.72,
  "pmiAmount": 217.98,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

