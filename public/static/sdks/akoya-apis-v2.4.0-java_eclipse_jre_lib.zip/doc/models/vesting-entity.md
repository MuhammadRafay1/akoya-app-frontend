
# Vesting Entity

Provides the past, present, and future vesting schedule and percentages.

*This model accepts additional fields of type Object.*

## Structure

`VestingEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `VestingDate` | `LocalDateTime` | Optional | Vesting date | LocalDateTime getVestingDate() | setVestingDate(LocalDateTime vestingDate) |
| `Symbol` | `String` | Optional | Security symbol | String getSymbol() | setSymbol(String symbol) |
| `StrikePrice` | `Double` | Optional | Strike price | Double getStrikePrice() | setStrikePrice(Double strikePrice) |
| `VestingPercentage` | `Double` | Optional | Vesting percentage | Double getVestingPercentage() | setVestingPercentage(Double vestingPercentage) |
| `OtherVestAmount` | `Double` | Optional | Other vest amount | Double getOtherVestAmount() | setOtherVestAmount(Double otherVestAmount) |
| `OtherVestPercentage` | `Double` | Optional | Other vest percentage | Double getOtherVestPercentage() | setOtherVestPercentage(Double otherVestPercentage) |
| `VestedBalance` | `Double` | Optional | Vested balance | Double getVestedBalance() | setVestedBalance(Double vestedBalance) |
| `UnVestedBalance` | `Double` | Optional | Unvested balance | Double getUnVestedBalance() | setUnVestedBalance(Double unVestedBalance) |
| `VestedQuantity` | `Double` | Optional | Vested qualtity | Double getVestedQuantity() | setVestedQuantity(Double vestedQuantity) |
| `UnVestedQuantity` | `Double` | Optional | Unvested quantity | Double getUnVestedQuantity() | setUnVestedQuantity(Double unVestedQuantity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "vestingDate": "2016-03-13T12:52:32.123Z",
  "symbol": "symbol0",
  "strikePrice": 216.86,
  "vestingPercentage": 250.28,
  "otherVestAmount": 111.28,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

