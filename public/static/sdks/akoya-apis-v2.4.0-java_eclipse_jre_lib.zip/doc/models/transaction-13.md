
# Transaction 13

*This model accepts additional fields of type Object.*

## Structure

`Transaction13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InvestmentTransaction` | [`InvestmentTransaction`](../../doc/models/investment-transaction.md) | Optional | Investment Transactions | InvestmentTransaction getInvestmentTransaction() | setInvestmentTransaction(InvestmentTransaction investmentTransaction) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "investmentTransaction": {
    "accountId": "accountId2",
    "amount": 139.34,
    "category": "category0",
    "debitCreditMemo": "DEBIT",
    "description": "description2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

