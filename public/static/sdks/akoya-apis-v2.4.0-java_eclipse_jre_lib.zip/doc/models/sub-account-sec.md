
# Sub Account Sec

Sub-account security type.

## Enumeration

`SubAccountSec`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `MShort` |
| `Others` |

