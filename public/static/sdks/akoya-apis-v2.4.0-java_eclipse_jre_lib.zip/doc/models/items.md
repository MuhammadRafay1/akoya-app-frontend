
# Items

*This model accepts additional fields of type Object.*

## Structure

`Items`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CostBasis` | `Double` | Optional | Total amount of money spent acquiring this lot including any fees or commission expenses incurred. | Double getCostBasis() | setCostBasis(Double costBasis) |
| `CurrentValue` | `Double` | Optional | Lot market value | Double getCurrentValue() | setCurrentValue(Double currentValue) |
| `OriginalPurchaseDate` | `LocalDateTime` | Optional | Lot acquired date. | LocalDateTime getOriginalPurchaseDate() | setOriginalPurchaseDate(LocalDateTime originalPurchaseDate) |
| `PositionType` | [`PositionType2`](../../doc/models/position-type-2.md) | Optional | LONG, SHORT. | PositionType2 getPositionType() | setPositionType(PositionType2 positionType) |
| `PurchasedPrice` | `Double` | Optional | Original purchase price. | Double getPurchasedPrice() | setPurchasedPrice(Double purchasedPrice) |
| `Quantity` | `Double` | Optional | Lot quantity. | Double getQuantity() | setQuantity(Double quantity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "costBasis": 220.88,
  "currentValue": 32.84,
  "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
  "positionType": "LONG",
  "purchasedPrice": 246.34,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

