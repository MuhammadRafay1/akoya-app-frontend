
# Loan Payment Frequency

## Enumeration

`LoanPaymentFrequency`

## Fields

| Name |
|  --- |
| `Weekly` |
| `Biweekly` |
| `Twicemonthly` |
| `Monthly` |
| `Fourweeks` |
| `Bimonthly` |
| `Quarterly` |
| `Semiannually` |
| `Annually` |
| `Other` |

