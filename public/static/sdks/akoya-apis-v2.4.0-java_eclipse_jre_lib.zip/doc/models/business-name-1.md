
# Business Name 1

Business issuer or recipient name

*This model accepts additional fields of type Object.*

## Structure

`BusinessName1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name1` | `String` | Optional | Name line 1 | String getName1() | setName1(String name1) |
| `Name2` | `String` | Optional | Name line 2 | String getName2() | setName2(String name2) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name1": "name18",
  "name2": "name22",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

