
# Transaction Type 4

LocTransaction Type

## Enumeration

`TransactionType4`

## Fields

| Name |
|  --- |
| `Check` |
| `Withdrawal` |
| `Transfer` |
| `Posdebit` |
| `Atmwithdrawal` |
| `Billpayment` |
| `Fee` |
| `Deposit` |
| `Adjustment` |
| `Interest` |
| `Dividend` |
| `Directdeposit` |
| `Atmdeposit` |
| `Poscredit` |

