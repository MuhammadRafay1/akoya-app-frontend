
# Gain or Loss From Cryptocurrency Transaction

Tax information for a single cryptocurrency transaction. If reported on Form 1099-B, use Tax1099B and SecurityDetail instead of this entity.

*This model accepts additional fields of type Object.*

## Structure

`GainOrLossFromCryptocurrencyTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CryptocurrencyName` | `String` | Optional | Cryptocurrency name (e.g. Bitcoin) | String getCryptocurrencyName() | setCryptocurrencyName(String cryptocurrencyName) |
| `Symbol` | `String` | Optional | Cryptocurrency abbreviation or symbol (e.g. BTC) | String getSymbol() | setSymbol(String symbol) |
| `Quantity` | `Double` | Optional | Quantity (e.g. 0.0125662) | Double getQuantity() | setQuantity(Double quantity) |
| `SaleDescription` | `String` | Optional | Description of property (1099-B box 1a) | String getSaleDescription() | setSaleDescription(String saleDescription) |
| `DateAcquired` | `LocalDate` | Optional | Date acquired (1099-B box 1b) | LocalDate getDateAcquired() | setDateAcquired(LocalDate dateAcquired) |
| `VariousDatesAcquired` | `Boolean` | Optional | Acquired on various dates (1099-B box 1b) | Boolean getVariousDatesAcquired() | setVariousDatesAcquired(Boolean variousDatesAcquired) |
| `DateOfSale` | `LocalDate` | Optional | Date sold or disposed (1099-B box 1c) | LocalDate getDateOfSale() | setDateOfSale(LocalDate dateOfSale) |
| `SalesPrice` | `Double` | Optional | Proceeds (not price per share, 1099-B box 1d) | Double getSalesPrice() | setSalesPrice(Double salesPrice) |
| `CostBasis` | `Double` | Optional | Cost or other basis (1099-B box 1e) | Double getCostBasis() | setCostBasis(Double costBasis) |
| `LongOrShort` | [`SaleTermType3`](../../doc/models/sale-term-type-3.md) | Optional | LONG or SHORT (1099-B box 2) | SaleTermType3 getLongOrShort() | setLongOrShort(SaleTermType3 longOrShort) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateAcquired": "2021-07-15",
  "dateOfSale": "2021-07-15",
  "cryptocurrencyName": "cryptocurrencyName6",
  "symbol": "symbol0",
  "quantity": 100.14,
  "saleDescription": "saleDescription2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

