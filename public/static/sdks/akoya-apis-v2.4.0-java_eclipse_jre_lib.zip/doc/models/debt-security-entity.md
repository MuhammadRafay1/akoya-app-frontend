
# Debt Security Entity

Information about the debt security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`DebtSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParValue` | `Double` | Optional | Par value amount | Double getParValue() | setParValue(Double parValue) |
| `DebtType` | [`DebtType`](../../doc/models/debt-type.md) | Optional | Debt type | DebtType getDebtType() | setDebtType(DebtType debtType) |
| `DebtClass` | [`DebtClass`](../../doc/models/debt-class.md) | Optional | Classification of debt | DebtClass getDebtClass() | setDebtClass(DebtClass debtClass) |
| `CouponRate` | `Double` | Optional | Bond coupon rate for next closest call date | Double getCouponRate() | setCouponRate(Double couponRate) |
| `CouponDate` | `LocalDateTime` | Optional | Maturity date for next coupon | LocalDateTime getCouponDate() | setCouponDate(LocalDateTime couponDate) |
| `CouponMatureFrequency` | [`CouponMatureFrequency`](../../doc/models/coupon-mature-frequency.md) | Optional | When coupons mature | CouponMatureFrequency getCouponMatureFrequency() | setCouponMatureFrequency(CouponMatureFrequency couponMatureFrequency) |
| `CallPrice` | `Double` | Optional | Bond call price | Double getCallPrice() | setCallPrice(Double callPrice) |
| `YieldToCall` | `Double` | Optional | Yield to next call | Double getYieldToCall() | setYieldToCall(Double yieldToCall) |
| `CallDate` | `LocalDateTime` | Optional | Next call date | LocalDateTime getCallDate() | setCallDate(LocalDateTime callDate) |
| `CallType` | [`CallType`](../../doc/models/call-type.md) | Optional | Type of next call | CallType getCallType() | setCallType(CallType callType) |
| `YieldToMaturity` | `Double` | Optional | Yield to maturity | Double getYieldToMaturity() | setYieldToMaturity(Double yieldToMaturity) |
| `BondMaturityDate` | `LocalDateTime` | Optional | Bond Maturity date | LocalDateTime getBondMaturityDate() | setBondMaturityDate(LocalDateTime bondMaturityDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "parValue": 18.14,
  "debtType": "ASSET",
  "debtClass": "CORPORATE",
  "couponRate": 229.02,
  "couponDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

