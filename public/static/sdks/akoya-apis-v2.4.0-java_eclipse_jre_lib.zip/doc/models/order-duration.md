
# Order Duration

This order is good for DAY, GOODTILLCANCEL, IMMEDIATE

## Enumeration

`OrderDuration`

## Fields

| Name |
|  --- |
| `Day` |
| `Goodtillcancel` |
| `Immediate` |

