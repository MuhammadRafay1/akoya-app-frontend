
# Security Id Type 3

Security identifier type.

## Enumeration

`SecurityIdType3`

## Fields

| Name |
|  --- |
| `Busip` |
| `Isin` |
| `Sedol` |
| `Sicc` |
| `Valor` |
| `Wkn` |

