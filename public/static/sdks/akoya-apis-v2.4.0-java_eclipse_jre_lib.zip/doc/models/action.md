
# Action

HTTP Method to use for the request

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `Get` |
| `Post` |
| `Patch` |
| `Delete` |
| `Put` |

