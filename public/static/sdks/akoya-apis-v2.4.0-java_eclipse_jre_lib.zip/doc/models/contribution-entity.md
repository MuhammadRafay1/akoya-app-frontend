
# Contribution Entity

Describes how new contributions are distributed among the available securities.

*This model accepts additional fields of type Object.*

## Structure

`ContributionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SecurityId` | `String` | Optional | Unique identifier of security | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type | SecurityIdType getSecurityIdType() | setSecurityIdType(SecurityIdType securityIdType) |
| `EmployerMatchPercentage` | `Double` | Optional | Employer contribution match percentage | Double getEmployerMatchPercentage() | setEmployerMatchPercentage(Double employerMatchPercentage) |
| `EmployerMatchAmount` | `Double` | Optional | Employer contribution match amount | Double getEmployerMatchAmount() | setEmployerMatchAmount(Double employerMatchAmount) |
| `EmployeePreTaxAmount` | `Double` | Optional | Employee pre‐tax contribution amount | Double getEmployeePreTaxAmount() | setEmployeePreTaxAmount(Double employeePreTaxAmount) |
| `EmployeePreTaxPercentage` | `Double` | Optional | Employee pre‐tax contribution percentage | Double getEmployeePreTaxPercentage() | setEmployeePreTaxPercentage(Double employeePreTaxPercentage) |
| `EmployeeAfterTaxAmount` | `Double` | Optional | Employee after tax contribution amount | Double getEmployeeAfterTaxAmount() | setEmployeeAfterTaxAmount(Double employeeAfterTaxAmount) |
| `EmployeeAfterTaxPercentage` | `Double` | Optional | Employee after tax contribution percentage | Double getEmployeeAfterTaxPercentage() | setEmployeeAfterTaxPercentage(Double employeeAfterTaxPercentage) |
| `EmployeeDeferPreTaxAmount` | `Double` | Optional | Employee defer pre‐tax contribution match amount | Double getEmployeeDeferPreTaxAmount() | setEmployeeDeferPreTaxAmount(Double employeeDeferPreTaxAmount) |
| `EmployeeDeferPreTaxPercentage` | `Double` | Optional | Employee defer pre‐tax contribution match percentage | Double getEmployeeDeferPreTaxPercentage() | setEmployeeDeferPreTaxPercentage(Double employeeDeferPreTaxPercentage) |
| `EmployeeYearToDate` | `Double` | Optional | Employee total year to date contribution | Double getEmployeeYearToDate() | setEmployeeYearToDate(Double employeeYearToDate) |
| `EmployerYearToDate` | `Double` | Optional | Employer total year to date contribution | Double getEmployerYearToDate() | setEmployerYearToDate(Double employerYearToDate) |
| `RolloverContributionPercentage` | `Double` | Optional | Rollover contribution percentage | Double getRolloverContributionPercentage() | setRolloverContributionPercentage(Double rolloverContributionPercentage) |
| `RolloverContributionAmount` | `Double` | Optional | Rollover contribution Amount | Double getRolloverContributionAmount() | setRolloverContributionAmount(Double rolloverContributionAmount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "employerMatchPercentage": 195.92,
  "employerMatchAmount": 120.16,
  "employeePreTaxAmount": 147.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

