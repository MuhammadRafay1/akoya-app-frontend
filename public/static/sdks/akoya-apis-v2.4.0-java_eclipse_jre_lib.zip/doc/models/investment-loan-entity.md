
# Investment Loan Entity

Information about an investment loan.

*This model accepts additional fields of type Object.*

## Structure

`InvestmentLoanEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `LoanId` | `String` | Optional | Unique identifier for this loan | String getLoanId() | setLoanId(String loanId) |
| `LoanDescription` | `String` | Optional | Description | String getLoanDescription() | setLoanDescription(String loanDescription) |
| `InitialLoanBalance` | `Double` | Optional | Initial loan balance amount | Double getInitialLoanBalance() | setInitialLoanBalance(Double initialLoanBalance) |
| `LoanStartDate` | `LocalDateTime` | Optional | Start date of the loan | LocalDateTime getLoanStartDate() | setLoanStartDate(LocalDateTime loanStartDate) |
| `CurrentLoanBalance` | `Double` | Optional | Current loan principal balance amount | Double getCurrentLoanBalance() | setCurrentLoanBalance(Double currentLoanBalance) |
| `DateAsOf` | `LocalDateTime` | Optional | Date and time of current loan balance | LocalDateTime getDateAsOf() | setDateAsOf(LocalDateTime dateAsOf) |
| `LoanRate` | `Double` | Optional | Loan annual interest rate for the loan | Double getLoanRate() | setLoanRate(Double loanRate) |
| `LoanPaymentAmount` | `Double` | Optional | Loan payment amount | Double getLoanPaymentAmount() | setLoanPaymentAmount(Double loanPaymentAmount) |
| `LoanPaymentFrequency` | [`LoanPaymentFrequency`](../../doc/models/loan-payment-frequency.md) | Optional | - | LoanPaymentFrequency getLoanPaymentFrequency() | setLoanPaymentFrequency(LoanPaymentFrequency loanPaymentFrequency) |
| `LoanPaymentInitial` | `Double` | Optional | Initial number of loan payments | Double getLoanPaymentInitial() | setLoanPaymentInitial(Double loanPaymentInitial) |
| `LoanPaymentsRemaining` | `Integer` | Optional | Remaining number of loan payments | Integer getLoanPaymentsRemaining() | setLoanPaymentsRemaining(Integer loanPaymentsRemaining) |
| `LoanMaturityDate` | `LocalDateTime` | Optional | Expected loan end date | LocalDateTime getLoanMaturityDate() | setLoanMaturityDate(LocalDateTime loanMaturityDate) |
| `LoanInterestToDate` | `Double` | Optional | Total interest paid to date on this loan | Double getLoanInterestToDate() | setLoanInterestToDate(Double loanInterestToDate) |
| `LoanTotalProjectedInterest` | `Double` | Optional | Total projected interest to be paid on this loan | Double getLoanTotalProjectedInterest() | setLoanTotalProjectedInterest(Double loanTotalProjectedInterest) |
| `LoanNextPaymentDate` | `LocalDateTime` | Optional | The next payment date for the loan | LocalDateTime getLoanNextPaymentDate() | setLoanNextPaymentDate(LocalDateTime loanNextPaymentDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "loanId": "loanId2",
  "loanDescription": "loanDescription4",
  "initialLoanBalance": 205.08,
  "loanStartDate": "2016-03-13T12:52:32.123Z",
  "currentLoanBalance": 206.82,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

