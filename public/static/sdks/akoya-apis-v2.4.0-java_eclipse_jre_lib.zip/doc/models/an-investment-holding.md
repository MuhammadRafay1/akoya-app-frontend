
# An Investment Holding

*This model accepts additional fields of type Object.*

## Structure

`AnInvestmentHolding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetClasses` | [`List<AssetClass>`](../../doc/models/asset-class.md) | Optional | Percent breakdown by asset class.<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<AssetClass> getAssetClasses() | setAssetClasses(List<AssetClass> assetClasses) |
| `AverageCost` | `Boolean` | Optional | Cost is average of all purchases for holding. | Boolean getAverageCost() | setAverageCost(Boolean averageCost) |
| `CashAccount` | `Boolean` | Optional | If true, indicates that this holding is used to maintain proceeds from sales, dividends, and other cash postings to the investment account. | Boolean getCashAccount() | setCashAccount(Boolean cashAccount) |
| `ChangeInPrice` | `Double` | Optional | Change in current price compared to previous day's close | Double getChangeInPrice() | setChangeInPrice(Double changeInPrice) |
| `Currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | CurrencyEntity getCurrency() | setCurrency(CurrencyEntity currency) |
| `CurrentUnitPrice` | `Double` | Optional | - | Double getCurrentUnitPrice() | setCurrentUnitPrice(Double currentUnitPrice) |
| `CurrentUnitPriceDate` | `LocalDateTime` | Optional | Current unit price as of date | LocalDateTime getCurrentUnitPriceDate() | setCurrentUnitPriceDate(LocalDateTime currentUnitPriceDate) |
| `Description` | `String` | Optional | Description of the holding | String getDescription() | setDescription(String description) |
| `ExpirationDate` | `LocalDateTime` | Optional | For CDs, bonds, and other time-based holdings. | LocalDateTime getExpirationDate() | setExpirationDate(LocalDateTime expirationDate) |
| `FaceValue` | `Double` | Optional | Face value at the time of data retrieved. | Double getFaceValue() | setFaceValue(Double faceValue) |
| `FiAssetClasses` | [`List<FiAssetClass>`](../../doc/models/fi-asset-class.md) | Optional | Percent breakdown by FI-specific asset class percentage breakdown | List<FiAssetClass> getFiAssetClasses() | setFiAssetClasses(List<FiAssetClass> fiAssetClasses) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `HeldInAccount` | [`HeldInAccount`](../../doc/models/held-in-account.md) | Optional | Sub-account | HeldInAccount getHeldInAccount() | setHeldInAccount(HeldInAccount heldInAccount) |
| `HoldingId` | `String` | Optional | Long term persistent identity of the holding | String getHoldingId() | setHoldingId(String holdingId) |
| `HoldingName` | `String` | Optional | Holding name or security name | String getHoldingName() | setHoldingName(String holdingName) |
| `HoldingSubType` | [`HoldingSubType`](../../doc/models/holding-sub-type.md) | Optional | - | HoldingSubType getHoldingSubType() | setHoldingSubType(HoldingSubType holdingSubType) |
| `HoldingType` | [`HoldingType`](../../doc/models/holding-type.md) | Optional | - | HoldingType getHoldingType() | setHoldingType(HoldingType holdingType) |
| `Inv401KSurce` | [`Inv401KSurce`](../../doc/models/inv-401-k-surce.md) | Optional | Source for money for this security. | Inv401KSurce getInv401KSurce() | setInv401KSurce(Inv401KSurce inv401KSurce) |
| `MarketValue` | `Double` | Optional | Market value at the time of data retrieved | Double getMarketValue() | setMarketValue(Double marketValue) |
| `OriginalPurchaseDate` | `LocalDateTime` | Optional | Date of original purchase | LocalDateTime getOriginalPurchaseDate() | setOriginalPurchaseDate(LocalDateTime originalPurchaseDate) |
| `PositionType` | [`PositionType`](../../doc/models/position-type.md) | Optional | - | PositionType getPositionType() | setPositionType(PositionType positionType) |
| `PurchasedPrice` | `Double` | Optional | Price of holding at the time of purchase | Double getPurchasedPrice() | setPurchasedPrice(Double purchasedPrice) |
| `Rate` | `Double` | Optional | For CDs, bonds, and other rate based holdings. | Double getRate() | setRate(Double rate) |
| `SecurityId` | `String` | Optional | Unique identifier of security | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type | SecurityIdType getSecurityIdType() | setSecurityIdType(SecurityIdType securityIdType) |
| `Symbol` | `String` | Optional | Ticker / Market symbol | String getSymbol() | setSymbol(String symbol) |
| `TaxLots` | [`List<TaxLot>`](../../doc/models/tax-lot.md) | Optional | Breakdown by tax lot.<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<TaxLot> getTaxLots() | setTaxLots(List<TaxLot> taxLots) |
| `Units` | `Double` | Optional | Number of shares (with decimals). | Double getUnits() | setUnits(Double units) |
| `MutualFundSecurity` | [`MutualFundSecurityEntity`](../../doc/models/mutual-fund-security-entity.md) | Optional | Information about the mutual fund security specific to the type of security | MutualFundSecurityEntity getMutualFundSecurity() | setMutualFundSecurity(MutualFundSecurityEntity mutualFundSecurity) |
| `OptionSecurity` | [`OptionSecurityEntity`](../../doc/models/option-security-entity.md) | Optional | Information about the option security specific to the type of security | OptionSecurityEntity getOptionSecurity() | setOptionSecurity(OptionSecurityEntity optionSecurity) |
| `OtherSecurity` | [`OtherSecurityEntity`](../../doc/models/other-security-entity.md) | Optional | Information about the security specific to the type of security | OtherSecurityEntity getOtherSecurity() | setOtherSecurity(OtherSecurityEntity otherSecurity) |
| `StockSecurity` | [`StockSecurityEntity`](../../doc/models/stock-security-entity.md) | Optional | Information about the stock security specific to the type of security | StockSecurityEntity getStockSecurity() | setStockSecurity(StockSecurityEntity stockSecurity) |
| `SweepSecurity` | [`SweepSecurityEntity`](../../doc/models/sweep-security-entity.md) | Optional | Information about the sweep security specific to the type of security | SweepSecurityEntity getSweepSecurity() | setSweepSecurity(SweepSecurityEntity sweepSecurity) |
| `DebtSecurity` | [`DebtSecurityEntity`](../../doc/models/debt-security-entity.md) | Optional | Information about the debt security specific to the type of security | DebtSecurityEntity getDebtSecurity() | setDebtSecurity(DebtSecurityEntity debtSecurity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetClasses": [
    {
      "assetClass": "DOMESTICBOND",
      "percent": 174.1,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "assetClass": "DOMESTICBOND",
      "percent": 174.1,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "averageCost": false,
  "cashAccount": false,
  "changeInPrice": 26.72,
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

