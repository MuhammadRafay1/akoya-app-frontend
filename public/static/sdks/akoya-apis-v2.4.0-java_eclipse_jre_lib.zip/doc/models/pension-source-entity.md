
# Pension Source Entity

Information about a pension source.

*This model accepts additional fields of type Object.*

## Structure

`PensionSourceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DisplayName` | `String` | Optional | Name of the Source | String getDisplayName() | setDisplayName(String displayName) |
| `Amount` | `Double` | Optional | Benefit Amount | Double getAmount() | setAmount(Double amount) |
| `PaymentOption` | `String` | Optional | Form of payment | String getPaymentOption() | setPaymentOption(String paymentOption) |
| `AsOfDate` | `LocalDateTime` | Optional | Date benefit was calculated | LocalDateTime getAsOfDate() | setAsOfDate(LocalDateTime asOfDate) |
| `Frequency` | [`Frequency`](../../doc/models/frequency.md) | Optional | - | Frequency getFrequency() | setFrequency(Frequency frequency) |
| `StartDate` | `LocalDateTime` | Optional | Assumed retirement date ‐ As of date amount is payable | LocalDateTime getStartDate() | setStartDate(LocalDateTime startDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "displayName": "displayName8",
  "amount": 9.06,
  "paymentOption": "paymentOption0",
  "asOfDate": "2016-03-13T12:52:32.123Z",
  "frequency": "ANNUALLY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

