
# Address 2

*This model accepts additional fields of type Object.*

## Structure

`Address2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`LocationType`](../../doc/models/location-type.md) | Optional | The location type of an address | LocationType getType() | setType(LocationType type) |
| `Line1` | `String` | Optional | May contain full address if not separated | String getLine1() | setLine1(String line1) |
| `Line2` | `String` | Optional | - | String getLine2() | setLine2(String line2) |
| `Line3` | `String` | Optional | - | String getLine3() | setLine3(String line3) |
| `City` | `String` | Optional | - | String getCity() | setCity(String city) |
| `State` | `String` | Optional | - | String getState() | setState(String state) |
| `PostalCode` | `String` | Optional | - | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Optional | ISO 3166 Country Code | String getCountry() | setCountry(String country) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "HOME",
  "line1": "line14",
  "line2": "line26",
  "line3": "line34",
  "city": "city2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

