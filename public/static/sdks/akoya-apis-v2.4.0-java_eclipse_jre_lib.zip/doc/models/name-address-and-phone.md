
# Name Address and Phone

Contact phone number with name and address

*This model accepts additional fields of type Object.*

## Structure

`NameAddressAndPhone`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Line1` | `String` | Optional | Address line 1 | String getLine1() | setLine1(String line1) |
| `Line2` | `String` | Optional | Address line 2 | String getLine2() | setLine2(String line2) |
| `Line3` | `String` | Optional | Address line 3 | String getLine3() | setLine3(String line3) |
| `City` | `String` | Optional | City | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode' | String getRegion() | setRegion(String region) |
| `PostalCode` | `String` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | [`Iso3166CountryCode2`](../../doc/models/iso-3166-country-code-2.md) | Optional | Country code | Iso3166CountryCode2 getCountry() | setCountry(Iso3166CountryCode2 country) |
| `Name1` | `String` | Optional | Name line 1 | String getName1() | setName1(String name1) |
| `Name2` | `String` | Optional | Name line 2 | String getName2() | setName2(String name2) |
| `Phone` | [`TelephoneNumberPlusExtension1`](../../doc/models/telephone-number-plus-extension-1.md) | Optional | Phone number | TelephoneNumberPlusExtension1 getPhone() | setPhone(TelephoneNumberPlusExtension1 phone) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "line1": "line16",
  "line2": "line28",
  "line3": "line36",
  "city": "city4",
  "region": "region0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

