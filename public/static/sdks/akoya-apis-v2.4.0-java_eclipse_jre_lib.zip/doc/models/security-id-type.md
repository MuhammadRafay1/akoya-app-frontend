
# Security Id Type

Security identifier type

## Enumeration

`SecurityIdType`

## Fields

| Name |
|  --- |
| `Cusip` |
| `Isin` |
| `Sedol` |
| `Sicc` |
| `Valor` |
| `Wkn` |

