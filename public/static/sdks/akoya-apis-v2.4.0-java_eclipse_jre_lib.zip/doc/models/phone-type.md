
# Phone Type

## Enumeration

`PhoneType`

## Fields

| Name |
|  --- |
| `Home` |
| `Business` |
| `Cell` |
| `Fax` |

