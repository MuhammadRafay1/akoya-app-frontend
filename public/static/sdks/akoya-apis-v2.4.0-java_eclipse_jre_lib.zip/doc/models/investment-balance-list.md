
# Investment Balance List

*This model accepts additional fields of type Object.*

## Structure

`InvestmentBalanceList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BalanceName` | `String` | Optional | Name of the balance. | String getBalanceName() | setBalanceName(String balanceName) |
| `BalanceDescription` | `String` | Optional | Description of balance. | String getBalanceDescription() | setBalanceDescription(String balanceDescription) |
| `BalanceType` | [`BalanceType1`](../../doc/models/balance-type-1.md) | Optional | The type of an investment balance. AMOUNT or PERCENTAGE. | BalanceType1 getBalanceType() | setBalanceType(BalanceType1 balanceType) |
| `BalanceValue` | `Double` | Optional | Value of balance name. | Double getBalanceValue() | setBalanceValue(Double balanceValue) |
| `BalanceDate` | `LocalDateTime` | Optional | Date as of this balance. | LocalDateTime getBalanceDate() | setBalanceDate(LocalDateTime balanceDate) |
| `Currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | CurrencyEntity getCurrency() | setCurrency(CurrencyEntity currency) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "balanceName": "balanceName0",
  "balanceDescription": "balanceDescription6",
  "balanceType": "AMOUNT",
  "balanceValue": 220.9,
  "balanceDate": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

