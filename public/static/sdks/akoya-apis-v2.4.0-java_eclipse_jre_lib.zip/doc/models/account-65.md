
# Account 65

*This model accepts additional fields of type Object.*

## Structure

`Account65`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AnnuityAccount` | [`AnnuityBalances`](../../doc/models/annuity-balances.md) | Optional | Data elements included with balances specific to annuity accounts | AnnuityBalances getAnnuityAccount() | setAnnuityAccount(AnnuityBalances annuityAccount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "annuityAccount": {
    "accountId": "accountId6",
    "accountType": "accountType4",
    "accountNumberDisplay": "accountNumberDisplay0",
    "currency": {
      "currencyCode": "currencyCode0",
      "currencyRate": 27.48,
      "originalCurrencyCode": "originalCurrencyCode4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "description": "description6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

