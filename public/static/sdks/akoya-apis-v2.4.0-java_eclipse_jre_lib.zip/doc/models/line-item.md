
# Line Item

*This model accepts additional fields of type Object.*

## Structure

`LineItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `Double` | Optional | The amount of money attributable to this line item | Double getAmount() | setAmount(Double amount) |
| `CheckNumber` | `Double` | Optional | Check number | Double getCheckNumber() | setCheckNumber(Double checkNumber) |
| `Description` | `String` | Optional | The description of the line item | String getDescription() | setDescription(String description) |
| `ImageIds` | `List<String>` | Optional | Array of image identifiers (unique to transaction) used to retrieve images of check or transaction receipt | List<String> getImageIds() | setImageIds(List<String> imageIds) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links (unique to this Transaction) used to retrieve images of checks or transaction receipts, or invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `Memo` | `String` | Optional | Secondary item description | String getMemo() | setMemo(String memo) |
| `Reference` | `String` | Optional | A reference number | String getReference() | setReference(String reference) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "amount": 197.28,
  "checkNumber": 134.12,
  "description": "description6",
  "imageIds": [
    "imageIds5",
    "imageIds6",
    "imageIds7"
  ],
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

