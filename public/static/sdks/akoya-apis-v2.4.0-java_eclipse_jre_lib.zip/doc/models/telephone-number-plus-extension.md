
# Telephone Number Plus Extension

A telephone number that can contain optional text for an arbitrary length telephone extension number

*This model accepts additional fields of type Object.*

## Structure

`TelephoneNumberPlusExtension`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TelephoneNumberType2`](../../doc/models/telephone-number-type-2.md) | Optional | Type of phone number: HOME, BUSINESS, CELL, FAX | TelephoneNumberType2 getType() | setType(TelephoneNumberType2 type) |
| `Country` | `String` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164<br><br>**Constraints**: *Maximum Length*: `3` | String getCountry() | setCountry(String country) |
| `Number` | `String` | Optional | Telephone subscriber number defined by ITU-T recommendation E.164<br><br>**Constraints**: *Maximum Length*: `15`, *Pattern*: `\d+` | String getNumber() | setNumber(String number) |
| `Extension` | `String` | Optional | An arbitrary length telephone number extension | String getExtension() | setExtension(String extension) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "FAX",
  "country": "country2",
  "number": "number6",
  "extension": "extension4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

