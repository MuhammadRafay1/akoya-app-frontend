
# Tax Party Type

Whether the tax legal entity is a business or an individual

## Enumeration

`TaxPartyType`

## Fields

| Name |
|  --- |
| `Business` |
| `Individual` |

