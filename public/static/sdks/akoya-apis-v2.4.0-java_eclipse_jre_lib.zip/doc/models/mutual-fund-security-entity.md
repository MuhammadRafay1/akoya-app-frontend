
# Mutual Fund Security Entity

Information about the mutual fund security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`MutualFundSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MutualFundType` | [`MutualFundType`](../../doc/models/mutual-fund-type.md) | Optional | Mutual fund type | MutualFundType getMutualFundType() | setMutualFundType(MutualFundType mutualFundType) |
| `UnitsStreet` | `Double` | Optional | Units in the FI's street name, positive quantity | Double getUnitsStreet() | setUnitsStreet(Double unitsStreet) |
| `UnitsUser` | `Double` | Optional | Units in user's name directly, positive  quantity | Double getUnitsUser() | setUnitsUser(Double unitsUser) |
| `ReinvestDividends` | `Boolean` | Optional | Reinvest dividends | Boolean getReinvestDividends() | setReinvestDividends(Boolean reinvestDividends) |
| `ReinvestCapitalGains` | `Boolean` | Optional | Reinvest capital gains | Boolean getReinvestCapitalGains() | setReinvestCapitalGains(Boolean reinvestCapitalGains) |
| `Yield` | `Double` | Optional | Current yield reported as portion of the fund's assets | Double getYield() | setYield(Double yield) |
| `YieldAsOfDate` | `LocalDateTime` | Optional | As-of date for yield value | LocalDateTime getYieldAsOfDate() | setYieldAsOfDate(LocalDateTime yieldAsOfDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "mutualFundType": "OPENEND",
  "unitsStreet": 101.68,
  "unitsUser": 108.4,
  "reinvestDividends": false,
  "reinvestCapitalGains": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

