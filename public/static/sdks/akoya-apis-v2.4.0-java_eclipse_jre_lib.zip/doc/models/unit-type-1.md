
# Unit Type 1

## Enumeration

`UnitType1`

## Fields

| Name |
|  --- |
| `Shares` |
| `Currency` |

