
# Month Abbreviation

Used by MonthAmount

## Enumeration

`MonthAbbreviation`

## Fields

| Name |
|  --- |
| `Jan` |
| `Feb` |
| `Mar` |
| `Apr` |
| `May` |
| `Jun` |
| `Jul` |
| `Aug` |
| `Sep` |
| `Oct` |
| `Nov` |
| `Dec` |

