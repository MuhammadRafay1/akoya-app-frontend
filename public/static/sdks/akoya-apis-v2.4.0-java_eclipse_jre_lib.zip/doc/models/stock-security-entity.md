
# Stock Security Entity

Information about the stock security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`StockSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UnitsStreet` | `Double` | Optional | Units in the FI's street name, positive quantity | Double getUnitsStreet() | setUnitsStreet(Double unitsStreet) |
| `UnitsUser` | `Double` | Optional | Units in user's name directly, positive  quantity | Double getUnitsUser() | setUnitsUser(Double unitsUser) |
| `ReinvestDividends` | `Boolean` | Optional | Reinvest dividends | Boolean getReinvestDividends() | setReinvestDividends(Boolean reinvestDividends) |
| `StockType` | [`StockType`](../../doc/models/stock-type.md) | Optional | - | StockType getStockType() | setStockType(StockType stockType) |
| `Yield` | `Double` | Optional | Current yield | Double getYield() | setYield(Double yield) |
| `YieldAsOfDate` | `LocalDateTime` | Optional | Yield as-of date | LocalDateTime getYieldAsOfDate() | setYieldAsOfDate(LocalDateTime yieldAsOfDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "unitsStreet": 117.56,
  "unitsUser": 92.52,
  "reinvestDividends": false,
  "stockType": "STOCK",
  "yield": 211.18,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

