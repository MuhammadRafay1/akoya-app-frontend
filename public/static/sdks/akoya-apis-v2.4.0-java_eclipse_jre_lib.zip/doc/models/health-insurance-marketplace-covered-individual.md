
# Health Insurance Marketplace Covered Individual

Used on Form 1095-A Part II

*This model accepts additional fields of type Object.*

## Structure

`HealthInsuranceMarketplaceCoveredIndividual`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Covered individual name | String getName() | setName(String name) |
| `Tin` | `String` | Optional | Covered individual SSN | String getTin() | setTin(String tin) |
| `DateOfBirth` | `LocalDate` | Optional | Covered individual date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `PolicyStartDate` | `LocalDate` | Optional | Coverage start date | LocalDate getPolicyStartDate() | setPolicyStartDate(LocalDate policyStartDate) |
| `PolicyTerminationDate` | `LocalDate` | Optional | Coverage termination date | LocalDate getPolicyTerminationDate() | setPolicyTerminationDate(LocalDate policyTerminationDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "policyStartDate": "2021-07-15",
  "policyTerminationDate": "2021-07-15",
  "name": "name2",
  "tin": "tin8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

