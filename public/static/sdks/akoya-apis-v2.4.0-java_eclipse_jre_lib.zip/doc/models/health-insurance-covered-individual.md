
# Health Insurance Covered Individual

Used on Form 1095-B Part IV and Form 1095-C Part III

*This model accepts additional fields of type Object.*

## Structure

`HealthInsuranceCoveredIndividual`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | [`IndividualName1`](../../doc/models/individual-name-1.md) | Optional | Name of responsible individual | IndividualName1 getName() | setName(IndividualName1 name) |
| `Tin` | `String` | Optional | Social security number or other TIN | String getTin() | setTin(String tin) |
| `DateOfBirth` | `LocalDate` | Optional | Date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `CoveredAll12Months` | `Boolean` | Optional | Covered all 12 months | Boolean getCoveredAll12Months() | setCoveredAll12Months(Boolean coveredAll12Months) |
| `CoveredMonths` | [`List<MonthAbbreviation>`](../../doc/models/month-abbreviation.md) | Optional | Months covered | List<MonthAbbreviation> getCoveredMonths() | setCoveredMonths(List<MonthAbbreviation> coveredMonths) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "tin": "tin4",
  "coveredAll12Months": false,
  "coveredMonths": [
    "FEB",
    "MAR"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

