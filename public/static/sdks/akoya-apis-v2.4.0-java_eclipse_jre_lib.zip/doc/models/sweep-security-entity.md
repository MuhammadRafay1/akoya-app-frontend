
# Sweep Security Entity

Information about the sweep security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`SweepSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CurrentBalance` | `Double` | Optional | Balance of funds in account | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `AvailableBalance` | `Double` | Optional | Balance of funds available for use | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `BalanceAsOf` | `LocalDateTime` | Optional | As-of date of balances | LocalDateTime getBalanceAsOf() | setBalanceAsOf(LocalDateTime balanceAsOf) |
| `Checks` | `Boolean` | Optional | Whether or not checks can be written on the account | Boolean getChecks() | setChecks(Boolean checks) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "currentBalance": 188.98,
  "availableBalance": 101.4,
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "checks": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

