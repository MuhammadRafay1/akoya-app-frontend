
# State Tax Withholding 2

Amount of state income tax withheld

*This model accepts additional fields of type Object.*

## Structure

`StateTaxWithholding2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxWithheld` | `Double` | Optional | Amount of state income tax withheld | Double getTaxWithheld() | setTaxWithheld(Double taxWithheld) |
| `TaxId` | `String` | Optional | Filer's state tax id | String getTaxId() | setTaxId(String taxId) |
| `Income` | `Double` | Optional | Income amount for state tax purposes | Double getIncome() | setIncome(Double income) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxWithheld": 252.7,
  "taxId": "taxId2",
  "income": 67.64,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

