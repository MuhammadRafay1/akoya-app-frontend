
# Secured

How the option is secured

## Enumeration

`Secured`

## Fields

| Name |
|  --- |
| `Covered` |
| `Naked` |

