
# Sub Account Fund

From which account money came in.

## Enumeration

`SubAccountFund`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `MShort` |
| `Others` |

