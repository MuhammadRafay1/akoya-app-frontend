
# Inv 401 K Source

For 401(k) accounts, source of money for this order. Default if not present is OTHERNONVEST.

## Enumeration

`Inv401KSource`

## Fields

| Name |
|  --- |
| `Aftertax` |
| `Match` |
| `Othernonvest` |
| `Othervest` |
| `Pretax` |
| `Profitsharing` |
| `Rollover` |

