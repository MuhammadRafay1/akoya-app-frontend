
# Investments Accounts

## Class Name

`InvestmentsAccounts`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Account8`](../../../doc/models/account-8.md) | InvestmentsAccounts.fromAccount8(Account8 account8) |
| [`Account6`](../../../doc/models/account-6.md) | InvestmentsAccounts.fromAccount6(Account6 account6) |
| [`Account61`](../../../doc/models/account-61.md) | InvestmentsAccounts.fromAccount61(Account61 account61) |
| [`Account62`](../../../doc/models/account-62.md) | InvestmentsAccounts.fromAccount62(Account62 account62) |
| [`Account64`](../../../doc/models/account-64.md) | InvestmentsAccounts.fromAccount64(Account64 account64) |
| [`Account65`](../../../doc/models/account-65.md) | InvestmentsAccounts.fromAccount65(Account65 account65) |

