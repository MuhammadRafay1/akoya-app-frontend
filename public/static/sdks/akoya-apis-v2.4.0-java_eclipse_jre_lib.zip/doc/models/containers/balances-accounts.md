
# Balances Accounts

## Class Name

`BalancesAccounts`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Account6`](../../../doc/models/account-6.md) | BalancesAccounts.fromAccount6(Account6 account6) |
| [`Account61`](../../../doc/models/account-61.md) | BalancesAccounts.fromAccount61(Account61 account61) |
| [`Account62`](../../../doc/models/account-62.md) | BalancesAccounts.fromAccount62(Account62 account62) |
| [`Account63`](../../../doc/models/account-63.md) | BalancesAccounts.fromAccount63(Account63 account63) |
| [`Account64`](../../../doc/models/account-64.md) | BalancesAccounts.fromAccount64(Account64 account64) |
| [`Account65`](../../../doc/models/account-65.md) | BalancesAccounts.fromAccount65(Account65 account65) |

