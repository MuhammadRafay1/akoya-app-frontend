
# Akoya Account Info Product Accounts

## Class Name

`AkoyaAccountInfoProductAccounts`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Account`](../../../doc/models/account.md) | AkoyaAccountInfoProductAccounts.fromAccount(Account account) |
| [`Account1`](../../../doc/models/account-1.md) | AkoyaAccountInfoProductAccounts.fromAccount1(Account1 account1) |
| [`Account2`](../../../doc/models/account-2.md) | AkoyaAccountInfoProductAccounts.fromAccount2(Account2 account2) |
| [`Account3`](../../../doc/models/account-3.md) | AkoyaAccountInfoProductAccounts.fromAccount3(Account3 account3) |
| [`Account4`](../../../doc/models/account-4.md) | AkoyaAccountInfoProductAccounts.fromAccount4(Account4 account4) |
| [`Account5`](../../../doc/models/account-5.md) | AkoyaAccountInfoProductAccounts.fromAccount5(Account5 account5) |

