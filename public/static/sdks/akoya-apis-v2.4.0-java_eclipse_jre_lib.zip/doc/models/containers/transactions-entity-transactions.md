
# Transactions Entity Transactions

## Class Name

`TransactionsEntityTransactions`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Transaction1`](../../../doc/models/transaction-1.md) | TransactionsEntityTransactions.fromTransaction1(Transaction1 transaction1) |
| [`Transaction11`](../../../doc/models/transaction-11.md) | TransactionsEntityTransactions.fromTransaction11(Transaction11 transaction11) |
| [`Transaction12`](../../../doc/models/transaction-12.md) | TransactionsEntityTransactions.fromTransaction12(Transaction12 transaction12) |
| [`Transaction13`](../../../doc/models/transaction-13.md) | TransactionsEntityTransactions.fromTransaction13(Transaction13 transaction13) |
| [`Transaction14`](../../../doc/models/transaction-14.md) | TransactionsEntityTransactions.fromTransaction14(Transaction14 transaction14) |

