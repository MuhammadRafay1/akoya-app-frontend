
# Mutual Fund Type

Mutual fund type

## Enumeration

`MutualFundType`

## Fields

| Name |
|  --- |
| `Openend` |
| `Closeend` |
| `Other` |

