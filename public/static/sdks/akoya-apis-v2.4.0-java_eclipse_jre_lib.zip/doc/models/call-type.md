
# Call Type

Type of next call

## Enumeration

`CallType`

## Fields

| Name |
|  --- |
| `Call` |
| `Put` |
| `Prefund` |
| `Maturity` |

