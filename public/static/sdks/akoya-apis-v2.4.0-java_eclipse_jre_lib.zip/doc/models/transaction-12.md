
# Transaction 12

*This model accepts additional fields of type Object.*

## Structure

`Transaction12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `LocTransaction` | [`LocTransaction`](../../doc/models/loc-transaction.md) | Optional | A line of credit transaction of type | LocTransaction getLocTransaction() | setLocTransaction(LocTransaction locTransaction) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "locTransaction": {
    "accountId": "accountId4",
    "amount": 130.76,
    "category": "category2",
    "debitCreditMemo": "DEBIT",
    "description": "description6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

