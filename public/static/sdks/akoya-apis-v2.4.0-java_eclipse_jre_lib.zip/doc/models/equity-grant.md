
# Equity Grant

*This model accepts additional fields of type Object.*

## Structure

`EquityGrant`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `GrantId` | `String` | Optional | Unique identifier of grant | String getGrantId() | setGrantId(String grantId) |
| `GrantDate` | `LocalDateTime` | Optional | Date grant was given | LocalDateTime getGrantDate() | setGrantDate(LocalDateTime grantDate) |
| `GrantType` | `String` | Optional | Type of grant | String getGrantType() | setGrantType(String grantType) |
| `SeqNum` | `Double` | Optional | - | Double getSeqNum() | setSeqNum(Double seqNum) |
| `GrantPrice` | `Double` | Optional | Grant price | Double getGrantPrice() | setGrantPrice(Double grantPrice) |
| `GrantCurrencyCode` | `String` | Optional | Indicates the currency of grant USD vs AUD vs EUR etc (for share awards, you will still get a USD) | String getGrantCurrencyCode() | setGrantCurrencyCode(String grantCurrencyCode) |
| `QuantityGranted` | `Double` | Optional | Number of options | Double getQuantityGranted() | setQuantityGranted(Double quantityGranted) |
| `QuantityOutstanding` | `Double` | Optional | - | Double getQuantityOutstanding() | setQuantityOutstanding(Double quantityOutstanding) |
| `ExpirationDate` | `LocalDateTime` | Optional | Date grant expires | LocalDateTime getExpirationDate() | setExpirationDate(LocalDateTime expirationDate) |
| `Vestings` | [`List<Vesting>`](../../doc/models/vesting.md) | Optional | An array of equityGrant vestings. Provides the past, present, and future vesting schedule and percentages. | List<Vesting> getVestings() | setVestings(List<Vesting> vestings) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "grantId": "grantId0",
  "grantDate": "2016-03-13T12:52:32.123Z",
  "grantType": "grantType0",
  "seqNum": 174.64,
  "grantPrice": 12.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

