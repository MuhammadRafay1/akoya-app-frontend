
# Transaction 1

*This model accepts additional fields of type Object.*

## Structure

`Transaction1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DepositTransaction` | [`DepositTransaction`](../../doc/models/deposit-transaction.md) | Optional | Deposit transaction | DepositTransaction getDepositTransaction() | setDepositTransaction(DepositTransaction depositTransaction) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "depositTransaction": {
    "accountId": "accountId0",
    "amount": 1.72,
    "category": "category8",
    "debitCreditMemo": "DEBIT",
    "description": "description0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

