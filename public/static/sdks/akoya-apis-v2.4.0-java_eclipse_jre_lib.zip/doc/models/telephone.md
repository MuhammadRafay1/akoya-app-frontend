
# Telephone

*This model accepts additional fields of type Object.*

## Structure

`Telephone`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Number` | `String` | Optional | - | String getNumber() | setNumber(String number) |
| `Type` | [`PhoneType`](../../doc/models/phone-type.md) | Optional | - | PhoneType getType() | setType(PhoneType type) |
| `Country` | `String` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164 | String getCountry() | setCountry(String country) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "number": "number6",
  "type": "HOME",
  "country": "country2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

