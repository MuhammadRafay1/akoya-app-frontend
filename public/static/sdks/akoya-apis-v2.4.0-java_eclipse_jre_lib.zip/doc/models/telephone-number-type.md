
# Telephone Number Type

Purpose or type of telephone number

## Enumeration

`TelephoneNumberType`

## Fields

| Name |
|  --- |
| `Business` |
| `Cell` |
| `Fax` |
| `Home` |

