
# Investments

*This model accepts additional fields of type Object.*

## Structure

`Investments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Accounts` | [`List<InvestmentsAccounts>`](../../doc/models/containers/investments-accounts.md) | Optional | This is List of a container for any-of cases. | List<InvestmentsAccounts> getAccounts() | setAccounts(List<InvestmentsAccounts> accounts) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accounts": [
    {
      "investmentAccount": {
        "accountId": "accountId8",
        "accountType": "accountType8",
        "accountNumberDisplay": "accountNumberDisplay4",
        "currency": {
          "currencyCode": "currencyCode0",
          "currencyRate": 27.48,
          "originalCurrencyCode": "originalCurrencyCode4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "description": "description8",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "investmentAccount": {
        "accountId": "accountId8",
        "accountType": "accountType8",
        "accountNumberDisplay": "accountNumberDisplay4",
        "currency": {
          "currencyCode": "currencyCode0",
          "currencyRate": 27.48,
          "originalCurrencyCode": "originalCurrencyCode4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "description": "description8",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

