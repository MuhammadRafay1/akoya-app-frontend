
# Sale Proceeds Type 1

Box 6, Reported to IRS: GROSS or NET

## Enumeration

`SaleProceedsType1`

## Fields

| Name |
|  --- |
| `Gross` |
| `Net` |

