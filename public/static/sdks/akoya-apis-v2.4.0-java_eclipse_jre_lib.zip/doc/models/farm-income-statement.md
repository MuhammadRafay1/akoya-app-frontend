
# Farm Income Statement

Farm Income Statement for IRS Form 1040 Schedule F

*This model accepts additional fields of type Object.*

## Structure

`FarmIncomeStatement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType2`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType2 getTaxFormType() | setTaxFormType(TypeFormType2 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form | Error2 getError() | setError(Error2 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `CropOrActivity` | `String` | Optional | Box A, Principal crop or activity | String getCropOrActivity() | setCropOrActivity(String cropOrActivity) |
| `Sales` | `Double` | Optional | Box 1a, Sales of livestock and other resale items | Double getSales() | setSales(Double sales) |
| `CostOfItemsSold` | `Double` | Optional | Box 1b, Cost or other basis of livestock or other items | Double getCostOfItemsSold() | setCostOfItemsSold(Double costOfItemsSold) |
| `SalesOfRaised` | `Double` | Optional | Box 2, Sales of livestock, produce, grains, and other products you raised | Double getSalesOfRaised() | setSalesOfRaised(Double salesOfRaised) |
| `CoopDistributions` | `Double` | Optional | Box 3a, Cooperative distributions | Double getCoopDistributions() | setCoopDistributions(Double coopDistributions) |
| `AgProgramPayments` | `Double` | Optional | Box 4a, Agricultural program payments | Double getAgProgramPayments() | setAgProgramPayments(Double agProgramPayments) |
| `CccLoans` | `Double` | Optional | Box 5a, Commodity Credit Corporation (CCC) loans reported under election | Double getCccLoans() | setCccLoans(Double cccLoans) |
| `CropInsuranceProceeds` | `Double` | Optional | Box 6a, Crop insurance proceeds and federal crop disaster payments | Double getCropInsuranceProceeds() | setCropInsuranceProceeds(Double cropInsuranceProceeds) |
| `CustomHireIncome` | `Double` | Optional | Box 7, Custom hire (machine work) income | Double getCustomHireIncome() | setCustomHireIncome(Double customHireIncome) |
| `OtherIncome` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 8, Other income | List<DescriptionAndAmount> getOtherIncome() | setOtherIncome(List<DescriptionAndAmount> otherIncome) |
| `CarAndTruck` | `Double` | Optional | Box 10, Car and truck expenses | Double getCarAndTruck() | setCarAndTruck(Double carAndTruck) |
| `Chemicals` | `Double` | Optional | Box 11, Chemicals | Double getChemicals() | setChemicals(Double chemicals) |
| `Conservation` | `Double` | Optional | Box 12, Conservation expenses | Double getConservation() | setConservation(Double conservation) |
| `CustomHireExpenses` | `Double` | Optional | Box 13, Custom hire (machine work) | Double getCustomHireExpenses() | setCustomHireExpenses(Double customHireExpenses) |
| `Depreciation` | `Double` | Optional | Box 14, Depreciation | Double getDepreciation() | setDepreciation(Double depreciation) |
| `EmployeeBenefitPrograms` | `Double` | Optional | Box 15, Employee benefit programs | Double getEmployeeBenefitPrograms() | setEmployeeBenefitPrograms(Double employeeBenefitPrograms) |
| `Feed` | `Double` | Optional | Box 16, Feed | Double getFeed() | setFeed(Double feed) |
| `Fertilizers` | `Double` | Optional | Box 17, Fertilizers and lime | Double getFertilizers() | setFertilizers(Double fertilizers) |
| `Freight` | `Double` | Optional | Box 18, Freight and trucking | Double getFreight() | setFreight(Double freight) |
| `Fuel` | `Double` | Optional | Box 19, Gasoline, fuel, and oil | Double getFuel() | setFuel(Double fuel) |
| `Insurance` | `Double` | Optional | Box 20, Insurance (other than health) | Double getInsurance() | setInsurance(Double insurance) |
| `MortgageInterest` | `Double` | Optional | Box 21a, Mortgage Interest | Double getMortgageInterest() | setMortgageInterest(Double mortgageInterest) |
| `OtherInterest` | `Double` | Optional | Box 21b, Other interest | Double getOtherInterest() | setOtherInterest(Double otherInterest) |
| `LaborHired` | `Double` | Optional | Box 22, Labor hired | Double getLaborHired() | setLaborHired(Double laborHired) |
| `Pension` | `Double` | Optional | Box 23, Pension and profit-sharing plans | Double getPension() | setPension(Double pension) |
| `EquipmentRent` | `Double` | Optional | Box 24a, Rent or lease: Vehicles, machinery, equipment | Double getEquipmentRent() | setEquipmentRent(Double equipmentRent) |
| `OtherRent` | `Double` | Optional | Box 24b, Rent or lease: Other | Double getOtherRent() | setOtherRent(Double otherRent) |
| `Repairs` | `Double` | Optional | Box 25, Repairs and maintenance | Double getRepairs() | setRepairs(Double repairs) |
| `Seeds` | `Double` | Optional | Box 26, Seeds and plants | Double getSeeds() | setSeeds(Double seeds) |
| `Storage` | `Double` | Optional | Box 27, Storage and warehousing | Double getStorage() | setStorage(Double storage) |
| `Supplies` | `Double` | Optional | Box 28, Supplies | Double getSupplies() | setSupplies(Double supplies) |
| `Taxes` | `Double` | Optional | Box 29, Taxes | Double getTaxes() | setTaxes(Double taxes) |
| `Utilities` | `Double` | Optional | Box 30, Utilities | Double getUtilities() | setUtilities(Double utilities) |
| `Veterinary` | `Double` | Optional | Box 31, Veterinary, breeding, and medicine | Double getVeterinary() | setVeterinary(Double veterinary) |
| `OtherExpenses` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 32, Other expenses | List<DescriptionAndAmount> getOtherExpenses() | setOtherExpenses(List<DescriptionAndAmount> otherExpenses) |
| `CapitalExpenditures` | [`List<DateAndAmount>`](../../doc/models/date-and-amount.md) | Optional | Capital expenditures, for use in calculating Depreciation | List<DateAndAmount> getCapitalExpenditures() | setCapitalExpenditures(List<DateAndAmount> capitalExpenditures) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId4",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

