
# Currency Entity

Indicates the currency code used by the account. May also include currency rate.

*This model accepts additional fields of type Object.*

## Structure

`CurrencyEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CurrencyCode` | `String` | Optional | Iso 4217 currency code. | String getCurrencyCode() | setCurrencyCode(String currencyCode) |
| `CurrencyRate` | `Double` | Optional | Currency rate between original and converted currency. | Double getCurrencyRate() | setCurrencyRate(Double currencyRate) |
| `OriginalCurrencyCode` | `String` | Optional | Iso 4217 currency code. | String getOriginalCurrencyCode() | setOriginalCurrencyCode(String originalCurrencyCode) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "currencyCode": "currencyCode4",
  "currencyRate": 203.06,
  "originalCurrencyCode": "originalCurrencyCode0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

