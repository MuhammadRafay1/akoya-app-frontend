
# Frequency

## Enumeration

`Frequency`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

