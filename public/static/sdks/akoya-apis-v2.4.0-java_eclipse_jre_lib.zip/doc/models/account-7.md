
# Account 7

*This model accepts additional fields of type Object.*

## Structure

`Account7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Account ID of the related account | String getAccountId() | setAccountId(String accountId) |
| `Relationship` | [`AccountHolderRelationship`](../../doc/models/account-holder-relationship.md) | Optional | Types of relationships between accounts and holders. Suggested values | AccountHolderRelationship getRelationship() | setRelationship(AccountHolderRelationship relationship) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId8",
  "relationship": "FOR_BENEFIT_OF_PRIMARY_JOINT_RESTRICTED",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

