
# Investment Account With All Details

Data elements included with the investment product

*This model accepts additional fields of type Object.*

## Structure

`InvestmentAccountWithAllDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. | String getAccountId() | setAccountId(String accountId) |
| `AccountType` | `String` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. | String getAccountType() | setAccountType(String accountType) |
| `AccountNumberDisplay` | `String` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. | String getAccountNumberDisplay() | setAccountNumberDisplay(String accountNumberDisplay) |
| `Currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. | CurrencyEntity getCurrency() | setCurrency(CurrencyEntity currency) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | - | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `Nickname` | `String` | Optional | Name given by the user. Used in UIs to assist in account selection | String getNickname() | setNickname(String nickname) |
| `ProductName` | `String` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection | String getProductName() | setProductName(String productName) |
| `Status` | [`Status`](../../doc/models/status.md) | Optional | The status of an account. | Status getStatus() | setStatus(Status status) |
| `LineOfBusiness` | `String` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. | String getLineOfBusiness() | setLineOfBusiness(String lineOfBusiness) |
| `BalanceType` | [`BalanceType`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) | BalanceType getBalanceType() | setBalanceType(BalanceType balanceType) |
| `InterestRate` | `Double` | Optional | Interest Rate of Account | Double getInterestRate() | setInterestRate(Double interestRate) |
| `InterestRateType` | [`InterestRateType`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. | InterestRateType getInterestRateType() | setInterestRateType(InterestRateType interestRateType) |
| `InterestRateAsOf` | `LocalDateTime` | Optional | Date of account’s interest rate | LocalDateTime getInterestRateAsOf() | setInterestRateAsOf(LocalDateTime interestRateAsOf) |
| `LastActivityDate` | `LocalDateTime` | Optional | Date that last transaction occurred on account | LocalDateTime getLastActivityDate() | setLastActivityDate(LocalDateTime lastActivityDate) |
| `MicrNumber` | `String` | Optional | MICR Number | String getMicrNumber() | setMicrNumber(String micrNumber) |
| `ParentAccountId` | `String` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. | String getParentAccountId() | setParentAccountId(String parentAccountId) |
| `PriorInterestRate` | `Double` | Optional | Previous Interest Rate of Account | Double getPriorInterestRate() | setPriorInterestRate(Double priorInterestRate) |
| `TransferIn` | `Boolean` | Optional | Account is eligible for incoming transfers | Boolean getTransferIn() | setTransferIn(Boolean transferIn) |
| `TransferOut` | `Boolean` | Optional | Account is eligible for outgoing transfers | Boolean getTransferOut() | setTransferOut(Boolean transferOut) |
| `AllowedCheckWriting` | `Boolean` | Optional | Check writing privileges | Boolean getAllowedCheckWriting() | setAllowedCheckWriting(Boolean allowedCheckWriting) |
| `AllowedOptionTrade` | `Boolean` | Optional | Allowed to trade options | Boolean getAllowedOptionTrade() | setAllowedOptionTrade(Boolean allowedOptionTrade) |
| `BrokerId` | `String` | Optional | Unique identifier FI | String getBrokerId() | setBrokerId(String brokerId) |
| `CalendarYearFor401K` | `String` | Optional | Date for this calendar year for 401K account | String getCalendarYearFor401K() | setCalendarYearFor401K(String calendarYearFor401K) |
| `EmployerName` | `String` | Optional | Name of the employer in investment 401k Plan | String getEmployerName() | setEmployerName(String employerName) |
| `Margin` | `Boolean` | Optional | Margin trading is allowed | Boolean getMargin() | setMargin(Boolean margin) |
| `PlanId` | `String` | Optional | Plan number for Investment 401k plan | String getPlanId() | setPlanId(String planId) |
| `AvailableCashBalance` | `Double` | Optional | Cash balance across all sub-accounts. Should include sweep funds. | Double getAvailableCashBalance() | setAvailableCashBalance(Double availableCashBalance) |
| `BalanceAsOf` | `LocalDateTime` | Optional | As-of date of balances | LocalDateTime getBalanceAsOf() | setBalanceAsOf(LocalDateTime balanceAsOf) |
| `BalanceList` | [`List<InvestmentBalanceList>`](../../doc/models/investment-balance-list.md) | Optional | Balance List. Name value pair aggregate. | List<InvestmentBalanceList> getBalanceList() | setBalanceList(List<InvestmentBalanceList> balanceList) |
| `CurrentValue` | `Double` | Optional | Total current value of all investments | Double getCurrentValue() | setCurrentValue(Double currentValue) |
| `DailyChange` | `Double` | Optional | Daily change | Double getDailyChange() | setDailyChange(Double dailyChange) |
| `MarginBalance` | `Double` | Optional | Margin balance | Double getMarginBalance() | setMarginBalance(Double marginBalance) |
| `PercentageChange` | `Double` | Optional | Percentage change | Double getPercentageChange() | setPercentageChange(Double percentageChange) |
| `RolloverAmount` | `Double` | Optional | Rollover amount | Double getRolloverAmount() | setRolloverAmount(Double rolloverAmount) |
| `ShortBalance` | `Double` | Optional | Short balance | Double getShortBalance() | setShortBalance(Double shortBalance) |
| `Holdings` | [`List<AnInvestmentHolding>`](../../doc/models/an-investment-holding.md) | Optional | Array of holdings | List<AnInvestmentHolding> getHoldings() | setHoldings(List<AnInvestmentHolding> holdings) |
| `OpenOrders` | [`List<OpenOrderEntity>`](../../doc/models/open-order-entity.md) | Optional | Array of open orders | List<OpenOrderEntity> getOpenOrders() | setOpenOrders(List<OpenOrderEntity> openOrders) |
| `Contribution` | [`List<ContributionEntity>`](../../doc/models/contribution-entity.md) | Optional | Array of contribution objects. Describes how new contributions are distributed among the available securities | List<ContributionEntity> getContribution() | setContribution(List<ContributionEntity> contribution) |
| `Vesting` | [`List<VestingEntity>`](../../doc/models/vesting-entity.md) | Optional | Array of vesting objects. Provides the past, present, and future vesting schedule and percentages | List<VestingEntity> getVesting() | setVesting(List<VestingEntity> vesting) |
| `InvestmentLoans` | [`List<InvestmentLoanEntity>`](../../doc/models/investment-loan-entity.md) | Optional | Array of investment loans | List<InvestmentLoanEntity> getInvestmentLoans() | setInvestmentLoans(List<InvestmentLoanEntity> investmentLoans) |
| `PensionSource` | [`List<PensionSourceEntity>`](../../doc/models/pension-source-entity.md) | Optional | Array of Pension Source | List<PensionSourceEntity> getPensionSource() | setPensionSource(List<PensionSourceEntity> pensionSource) |
| `EquityGrants` | [`List<EquityGrant>`](../../doc/models/equity-grant.md) | Optional | Provides equity grant information on Restricted Stock Units, Restricted Stock Awards, Stock Appreciation Right, Stock Options, Performance Awards, and Total Share Return Units | List<EquityGrant> getEquityGrants() | setEquityGrants(List<EquityGrant> equityGrants) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId2",
  "accountType": "accountType2",
  "accountNumberDisplay": "accountNumberDisplay8",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

