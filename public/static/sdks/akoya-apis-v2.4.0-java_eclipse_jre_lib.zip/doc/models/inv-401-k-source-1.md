
# Inv 401 K Source 1

Source of money.

## Enumeration

`Inv401KSource1`

## Fields

| Name |
|  --- |
| `Pretax` |
| `Aftertax` |
| `Match` |
| `Profitsharing` |
| `Rollover` |
| `Othervest` |
| `Othernonvest` |

