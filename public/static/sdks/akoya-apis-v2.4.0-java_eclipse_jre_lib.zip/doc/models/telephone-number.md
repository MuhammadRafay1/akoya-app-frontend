
# Telephone Number

Standard for international phone numbers

*This model accepts additional fields of type Object.*

## Structure

`TelephoneNumber`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TelephoneNumberType2`](../../doc/models/telephone-number-type-2.md) | Optional | Type of phone number: HOME, BUSINESS, CELL, FAX | TelephoneNumberType2 getType() | setType(TelephoneNumberType2 type) |
| `Country` | `String` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164<br><br>**Constraints**: *Maximum Length*: `3` | String getCountry() | setCountry(String country) |
| `Number` | `String` | Optional | Telephone subscriber number defined by ITU-T recommendation E.164<br><br>**Constraints**: *Maximum Length*: `15`, *Pattern*: `\d+` | String getNumber() | setNumber(String number) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "FAX",
  "country": "country8",
  "number": "number8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

