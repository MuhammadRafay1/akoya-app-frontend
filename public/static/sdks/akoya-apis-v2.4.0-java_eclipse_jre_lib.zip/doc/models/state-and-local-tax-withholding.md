
# State and Local Tax Withholding

Income in a state and/or locality and its or their tax withholding

*This model accepts additional fields of type Object.*

## Structure

`StateAndLocalTaxWithholding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StateCode` | [`StateCode2`](../../doc/models/state-code-2.md) | Optional | State two-digit code | StateCode2 getStateCode() | setStateCode(StateCode2 stateCode) |
| `State` | [`StateTaxWithholding2`](../../doc/models/state-tax-withholding-2.md) | Optional | Amount of state income tax withheld | StateTaxWithholding2 getState() | setState(StateTaxWithholding2 state) |
| `Local` | [`LocalTaxWithholding1`](../../doc/models/local-tax-withholding-1.md) | Optional | Amount of local income tax withheld, if any | LocalTaxWithholding1 getLocal() | setLocal(LocalTaxWithholding1 local) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "stateCode": "IL",
  "state": {
    "taxWithheld": 128.78,
    "taxId": "taxId0",
    "income": 191.56,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "local": {
    "taxWithheld": 75.84,
    "localityName": "localityName6",
    "income": 244.5,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

