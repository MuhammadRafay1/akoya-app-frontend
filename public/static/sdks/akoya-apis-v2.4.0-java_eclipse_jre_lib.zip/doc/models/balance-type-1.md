
# Balance Type 1

The type of an investment balance. AMOUNT or PERCENTAGE.

## Enumeration

`BalanceType1`

## Fields

| Name |
|  --- |
| `Amount` |
| `Percentage` |

