
# Tax Party 8

Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms.

*This model accepts additional fields of type Object.*

## Structure

`TaxParty8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Tin` | `String` | Optional | Issuer or recipient Tax Identification Number. Usually EIN for issuer and SSN for recipient | String getTin() | setTin(String tin) |
| `PartyType` | [`TaxPartyType2`](../../doc/models/tax-party-type-2.md) | Optional | Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient | TaxPartyType2 getPartyType() | setPartyType(TaxPartyType2 partyType) |
| `IndividualName` | [`IndividualName4`](../../doc/models/individual-name-4.md) | Optional | Individual issuer or recipient name | IndividualName4 getIndividualName() | setIndividualName(IndividualName4 individualName) |
| `BusinessName` | [`BusinessName1`](../../doc/models/business-name-1.md) | Optional | Business issuer or recipient name | BusinessName1 getBusinessName() | setBusinessName(BusinessName1 businessName) |
| `Address` | [`Address1`](../../doc/models/address-1.md) | Optional | Issuer or recipient address | Address1 getAddress() | setAddress(Address1 address) |
| `Phone` | [`TelephoneNumberPlusExtension4`](../../doc/models/telephone-number-plus-extension-4.md) | Optional | Issuer or recipient telephone number | TelephoneNumberPlusExtension4 getPhone() | setPhone(TelephoneNumberPlusExtension4 phone) |
| `Email` | `String` | Optional | Issuer or recipient email address. (Additional information, not part of IRS forms) | String getEmail() | setEmail(String email) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "tin": "tin0",
  "partyType": "BUSINESS",
  "individualName": {
    "first": "first0",
    "middle": "middle0",
    "last": "last4",
    "suffix": "suffix4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "businessName": {
    "name1": "name18",
    "name2": "name22",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

