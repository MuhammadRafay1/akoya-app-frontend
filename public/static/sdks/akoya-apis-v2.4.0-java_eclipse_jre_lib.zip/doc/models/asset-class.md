
# Asset Class

*This model accepts additional fields of type Object.*

## Structure

`AssetClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetClass` | [`AssetClass1`](../../doc/models/asset-class-1.md) | Optional | - | AssetClass1 getAssetClass() | setAssetClass(AssetClass1 assetClass) |
| `Percent` | `Double` | Optional | Percentage of asset class that falls under this asset | Double getPercent() | setPercent(Double percent) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetClass": "INTLSTOCK",
  "percent": 150.26,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

