
# Option Security Entity

Information about the option security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`OptionSecurityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Secured` | [`Secured`](../../doc/models/secured.md) | Optional | How the option is secured | Secured getSecured() | setSecured(Secured secured) |
| `OptionType` | [`OptionType`](../../doc/models/option-type.md) | Optional | - | OptionType getOptionType() | setOptionType(OptionType optionType) |
| `StrikePrice` | `Double` | Optional | Strike price / Unit price | Double getStrikePrice() | setStrikePrice(Double strikePrice) |
| `ExpireDate` | `LocalDateTime` | Optional | Expiration date of option | LocalDateTime getExpireDate() | setExpireDate(LocalDateTime expireDate) |
| `SharesPerContract` | `Double` | Optional | Shares per contract | Double getSharesPerContract() | setSharesPerContract(Double sharesPerContract) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "secured": "COVERED",
  "optionType": "CALL",
  "strikePrice": 0.6,
  "expireDate": "2016-03-13T12:52:32.123Z",
  "sharesPerContract": 217.4,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

