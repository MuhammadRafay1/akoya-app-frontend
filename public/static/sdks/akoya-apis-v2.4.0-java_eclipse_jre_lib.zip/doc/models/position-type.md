
# Position Type

## Enumeration

`PositionType`

## Fields

| Name |
|  --- |
| `MLong` |
| `MShort` |

