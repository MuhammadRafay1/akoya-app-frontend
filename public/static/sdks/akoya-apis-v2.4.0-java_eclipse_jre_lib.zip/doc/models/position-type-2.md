
# Position Type 2

LONG, SHORT.

## Enumeration

`PositionType2`

## Fields

| Name |
|  --- |
| `MLong` |
| `MShort` |

