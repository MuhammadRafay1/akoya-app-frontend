
# Investment Sale Type

Type of investment sale

## Enumeration

`InvestmentSaleType`

## Fields

| Name |
|  --- |
| `Cryptocurrency` |
| `EmployeeStockPurchasePlan` |
| `IncentiveStockOption` |
| `NonqualifiedStockOptions` |
| `Other` |
| `RestrictedStock` |
| `RestrictedStockUnits` |

