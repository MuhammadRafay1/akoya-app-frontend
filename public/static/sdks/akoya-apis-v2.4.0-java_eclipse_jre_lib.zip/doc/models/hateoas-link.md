
# Hateoas Link

REST application constraint (Hypermedia As The Engine Of Application State)

*This model accepts additional fields of type Object.*

## Structure

`HateoasLink`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Href` | `String` | Required | URL to invoke the action on the resource | String getHref() | setHref(String href) |
| `Action` | [`Action`](../../doc/models/action.md) | Optional | HTTP Method to use for the request | Action getAction() | setAction(Action action) |
| `Types` | [`List<Type>`](../../doc/models/type.md) | Optional | Content-types that can be used in the Accept header. | List<Type> getTypes() | setTypes(List<Type> types) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "href": "https://api.fi.com/fdx/v4/accounts/12345",
  "action": "DELETE",
  "types": [
    "image/gif"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

