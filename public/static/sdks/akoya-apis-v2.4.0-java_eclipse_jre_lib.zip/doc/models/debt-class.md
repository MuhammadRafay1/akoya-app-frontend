
# Debt Class

Classification of debt

## Enumeration

`DebtClass`

## Fields

| Name |
|  --- |
| `Treasury` |
| `Municipal` |
| `Corporate` |
| `Other` |

