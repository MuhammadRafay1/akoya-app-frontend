
# Sale Term Type 2

Box 2, LONG or SHORT

## Enumeration

`SaleTermType2`

## Fields

| Name |
|  --- |
| `MLong` |
| `MShort` |

