
# Debt Type

Debt type

## Enumeration

`DebtType`

## Fields

| Name |
|  --- |
| `Asset` |
| `Coupon` |

