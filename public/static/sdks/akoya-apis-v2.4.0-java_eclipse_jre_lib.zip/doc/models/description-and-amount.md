
# Description and Amount

Description and amount pair used on IRS W-2, etc.

*This model accepts additional fields of type Object.*

## Structure

`DescriptionAndAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Optional | Description | String getDescription() | setDescription(String description) |
| `Amount` | `Double` | Optional | Amount | Double getAmount() | setAmount(Double amount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "description": "description0",
  "amount": 4.82,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

