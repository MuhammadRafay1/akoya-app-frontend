
# Month and Amount

Month and amount pair used on IRS Form 1099-K, etc.

*This model accepts additional fields of type Object.*

## Structure

`MonthAndAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | [`MonthAbbreviation1`](../../doc/models/month-abbreviation-1.md) | Optional | Month | MonthAbbreviation1 getMonth() | setMonth(MonthAbbreviation1 month) |
| `Amount` | `Double` | Optional | Amount | Double getAmount() | setAmount(Double amount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "month": "SEP",
  "amount": 97.94,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

