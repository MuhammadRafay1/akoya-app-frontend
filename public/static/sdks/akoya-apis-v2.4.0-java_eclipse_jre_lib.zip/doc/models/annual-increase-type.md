
# Annual Increase Type

## Enumeration

`AnnualIncreaseType`

## Fields

| Name |
|  --- |
| `Fixed` |
| `Percent` |
| `Dollar` |

