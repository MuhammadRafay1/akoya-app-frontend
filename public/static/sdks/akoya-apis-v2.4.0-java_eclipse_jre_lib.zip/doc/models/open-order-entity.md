
# Open Order Entity

Information on an open order.

*This model accepts additional fields of type Object.*

## Structure

`OpenOrderEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderId` | `String` | Optional | Long term persistent identity of the order. Id for this order transaction. | String getOrderId() | setOrderId(String orderId) |
| `SecurityId` | `String` | Optional | Unique identifier of the security. | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type | SecurityIdType getSecurityIdType() | setSecurityIdType(SecurityIdType securityIdType) |
| `Symbol` | `String` | Optional | Market symbol | String getSymbol() | setSymbol(String symbol) |
| `Description` | `String` | Optional | Description of order | String getDescription() | setDescription(String description) |
| `Units` | `Double` | Optional | Number of units (shares, bonds, etc.) | Double getUnits() | setUnits(Double units) |
| `OrderType` | [`OrderType`](../../doc/models/order-type.md) | Optional | Type of order. | OrderType getOrderType() | setOrderType(OrderType orderType) |
| `OrderDate` | `LocalDateTime` | Optional | Order date | LocalDateTime getOrderDate() | setOrderDate(LocalDateTime orderDate) |
| `UnitPrice` | `Double` | Optional | Unit price | Double getUnitPrice() | setUnitPrice(Double unitPrice) |
| `UnitType` | [`UnitType`](../../doc/models/unit-type.md) | Optional | Type of unit. | UnitType getUnitType() | setUnitType(UnitType unitType) |
| `OrderDuration` | [`OrderDuration`](../../doc/models/order-duration.md) | Optional | This order is good for DAY, GOODTILLCANCEL, IMMEDIATE | OrderDuration getOrderDuration() | setOrderDuration(OrderDuration orderDuration) |
| `SubAccount` | [`SubAccount`](../../doc/models/sub-account.md) | Optional | - | SubAccount getSubAccount() | setSubAccount(SubAccount subAccount) |
| `LimitPrice` | `Double` | Optional | Limit Price | Double getLimitPrice() | setLimitPrice(Double limitPrice) |
| `StopPrice` | `Double` | Optional | Stop price | Double getStopPrice() | setStopPrice(Double stopPrice) |
| `Inv401KSource` | [`Inv401KSource`](../../doc/models/inv-401-k-source.md) | Optional | For 401(k) accounts, source of money for this order. Default if not present is OTHERNONVEST. | Inv401KSource getInv401KSource() | setInv401KSource(Inv401KSource inv401KSource) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "orderId": "orderId4",
  "securityId": "securityId6",
  "securityIdType": "VALOR",
  "symbol": "symbol0",
  "description": "description2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

