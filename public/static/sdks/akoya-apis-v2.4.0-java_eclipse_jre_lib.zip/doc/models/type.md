
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `EnumApplicationpdf` |
| `EnumImagegif` |
| `EnumImagejpeg` |
| `EnumImagetiff` |
| `EnumImagepng` |
| `EnumApplicationjson` |

## Example

```
application/json
```

