
# Insurance Transaction

Insurance transactions

*This model accepts additional fields of type Object.*

## Structure

`InsuranceTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Corresponds to AccountId in Account | String getAccountId() | setAccountId(String accountId) |
| `Amount` | `Double` | Optional | The amount of money in the account currency.<br><br>If balanceType is `ASSET`:<br><br>1. If `debitCreditMemo` = `DEBIT`, sign is "+" or not present<br>2. If `CREDIT`, sign is "-"<br><br>If balanceType is `LIABILITY`:<br><br>1. If `debitCreditMemo` = `DEBIT`, sign is "-"<br>2. If `CREDIT`, sign is "+" or not present | Double getAmount() | setAmount(Double amount) |
| `Category` | `String` | Optional | Transaction category, preferably MCC or SIC. | String getCategory() | setCategory(String category) |
| `DebitCreditMemo` | [`DebitCreditMemo`](../../doc/models/debit-credit-memo.md) | Optional | Akoya will ensure that this is correctly populated with one of DEBIT or CREDIT and matches the sign of the status field. | DebitCreditMemo getDebitCreditMemo() | setDebitCreditMemo(DebitCreditMemo debitCreditMemo) |
| `Description` | `String` | Optional | The description of the transaction | String getDescription() | setDescription(String description) |
| `ImageIds` | `List<String>` | Optional | Array of image identifiers (unique to transaction) used to retrieve images of check or transaction receipt. | List<String> getImageIds() | setImageIds(List<String> imageIds) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `ForeignAmount` | `Double` | Optional | The amount of money in the foreign currency | Double getForeignAmount() | setForeignAmount(Double foreignAmount) |
| `ForeignCurrency` | `String` | Optional | The ISO 4217 code of the foreign currency | String getForeignCurrency() | setForeignCurrency(String foreignCurrency) |
| `LineItem` | [`List<LineItem>`](../../doc/models/line-item.md) | Optional | Breakdown of the transaction details | List<LineItem> getLineItem() | setLineItem(List<LineItem> lineItem) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links (unique to this Transaction) used to retrieve images of checks or transaction receipts, or invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `Memo` | `String` | Optional | Secondary transaction description | String getMemo() | setMemo(String memo) |
| `PostedTimestamp` | `LocalDateTime` | Optional | The date and time that the transaction was posted to the account. If not provided then TransactionTimestamp can be used as PostedTimeStamp. | LocalDateTime getPostedTimestamp() | setPostedTimestamp(LocalDateTime postedTimestamp) |
| `Reference` | `String` | Optional | A tracking reference identifier | String getReference() | setReference(String reference) |
| `ReferenceTransactionId` | `String` | Optional | Akoya ensures that this field is populated for all transactions which are reversals, otherwise it is null. Either way it is always present.<br><br>For reverse postings, the identity of the transaction being reversed. For the correction transaction, the identity of the reversing post. For credit card posting transactions, the identity of the authorization transaction. | String getReferenceTransactionId() | setReferenceTransactionId(String referenceTransactionId) |
| `Status` | [`Status1`](../../doc/models/status-1.md) | Optional | AUTHORIZATION, MEMO, PENDING, or POSTED | Status1 getStatus() | setStatus(Status1 status) |
| `SubCategory` | `String` | Optional | Transaction category detail | String getSubCategory() | setSubCategory(String subCategory) |
| `TransactionId` | `String` | Optional | Long term persistent identity of the transaction (unique to account).<br>Transaction IDs should:<br><br>1. be the same for pending and posted<br>2. be different for reversed transactions<br>3. `referenceTransactionId` should be present for reversed transactions' | String getTransactionId() | setTransactionId(String transactionId) |
| `TransactionTimestamp` | `LocalDateTime` | Optional | The date and time that the transaction was added to the server backend systems.<br><br>Akoya ensures that this field is populated for all transactions to which it applies, otherwise it is null. Either way it is always present. | LocalDateTime getTransactionTimestamp() | setTransactionTimestamp(LocalDateTime transactionTimestamp) |
| `TransactionType` | [`TransactionType1`](../../doc/models/transaction-type-1.md) | Optional | InsuranceTransaction Type | TransactionType1 getTransactionType() | setTransactionType(TransactionType1 transactionType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId4",
  "amount": 123.56,
  "category": "category2",
  "debitCreditMemo": "DEBIT",
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

