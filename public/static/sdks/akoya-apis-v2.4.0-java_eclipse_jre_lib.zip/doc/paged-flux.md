
# PagedFlux

It is an asynchronous, Flux-based iterator. It can fetch and iterate over each individual element in all the pages lazily.

This class extends `reactor.core.publisher.Flux<I>`

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `this` | Subscribes to the Flux and begins emitting items lazily as requested by the subscriber. | `Flux<I>` |
| `pages()` | Returns a `Flux` that emits entire pages instead of individual items. | <code>Flux<PagedResponse<I,P>></code> |

Here the PagedResponse is a base class and it can be an instance of following:

- [`LinkPagedResponse`](../doc/link-paged-response.md)

## Usage Example

```java
// Iterating over items in all the pages.
pagedFlux.subscribe(
    _item -> System.out.println(_item),
    _error -> _error.printStackTrace()
);

// Iterating over all the pages.
pagedFlux.pages().subscribe(_page -> {
    if (_page instanceof LinkPagedResponse) {
        // Extracting next link value that's used to fetch this page.
        System.out.println(((LinkPagedResponse<?, ?>) _page).getNextLink());
    }

    // Iterating over items in the current page.
    _page.getItems().forEach(_item -> System.out.println(_item));

    // Extracting paged response body.
    System.out.println(_page.getResult());

    // Extracting paged response headers.
    System.out.println(_page.getHeaders().asSimpleMap());

    // Extracting paged response status code.
    System.out.println(_page.getStatusCode());
}, _error -> _error.printStackTrace());
```

