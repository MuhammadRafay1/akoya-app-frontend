
# LinkPagedResponse

This class represents a paginated API response for link based pagination.

## Base Class

[`ApiResponse`](../doc/api-response.md)

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `getNextLink()` | Retrieves the link input used to fetch the next page. | `String` |

