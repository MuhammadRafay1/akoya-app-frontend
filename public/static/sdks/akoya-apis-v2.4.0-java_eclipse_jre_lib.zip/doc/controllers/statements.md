# Statements

Statements

```java
StatementsApi statementsApi = client.getStatementsApi();
```

## Class Name

`StatementsApi`

## Methods

* [Get-Statement-List](../../doc/controllers/statements.md#get-statement-list)
* [Get-Statements](../../doc/controllers/statements.md#get-statements)


# Get-Statement-List

Retrieve a list of available statements for the end-user's consented accounts. You may request a date range of up to two years of historical statements (maximum date ranges vary by provider).

The paginated response includes an array of statement information with the end-user's account id and statement details such as statement id, date, description, and status. The results also include links to GET the statement image.

```java
CompletableFuture<ApiResponse<PaginatedArray>> getStatementListAsync(
    final String accountId,
    final String version,
    final String providerId,
    final LocalDate startTime,
    final LocalDate endTime,
    final String offset,
    final Integer limit,
    final InteractionType xAkoyaInteractionType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountId` | `String` | Template, Required | Account Identifier |
| `version` | `String` | Template, Required | Akoya major version number. Do not use minor version numbers. For instance, use v2 and not v2.2 |
| `providerId` | `String` | Template, Required | Id of provider |
| `startTime` | `LocalDate` | Query, Optional | Start date for use in retrieval of statements (ISO 8601) |
| `endTime` | `LocalDate` | Query, Optional | End date for use in retrieval of statements (ISO 8601) |
| `offset` | `String` | Query, Optional | The number of items to skip before the first in the response. The default is 0.<br><br>**Default**: `"0"` |
| `limit` | `Integer` | Query, Optional | The maximum number of items to be returned in the response. The default is 50.<br><br>**Default**: `50` |
| `xAkoyaInteractionType` | [`InteractionType`](../../doc/models/interaction-type.md) | Header, Optional | Optional but recommended header to include with each data request.<br>Allowed values are `user` or `batch`.<br>`user` indicates a request is prompted by an end-user action.<br>`batch` indicates the request is part of a batch process. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaginatedArray`](../../doc/models/paginated-array.md).

## Example Usage

```java
String accountId = ":accountId";
String version = "v2";
String providerId = "mikomo";
LocalDate startTime = DateTimeHelper.fromSimpleDate("2020-03-30");
LocalDate endTime = DateTimeHelper.fromSimpleDate("2021-03-30");
String offset = "0";
Integer limit = 50;

statementsApi.getStatementListAsync(accountId, version, providerId, startTime, endTime, offset, limit, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format. | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | 404 - Not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | `ApiException` |
| 408 | Request timed out (round trip call took >10 seconds). | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Internal Server Error. | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | FdxVersion in header is not implemented. | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance. | [`ErrorException`](../../doc/models/error-exception.md) |


# Get-Statements

Retrieve a specific account statement file. Use [HTTP Accept request-header](https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html) to specify desired content types.

For the initial launch, only PDF statements are supported. PDFs are returned in the response.

### cURL request

We recommend using the auto-generated cURL request with the {idToken}, accountId, providerId, statementId, and version with an added cURL parameter to return the output to a file. For example:

```curl
curl --request GET --url https://sandbox-products.ddp.akoya.com/statements/v2/mikomo/513815781465/P9CvLPKDaFRMbNDkhu1 --header "accept: application/pdf" --header "authorization: Bearer {idtoken}" --output example.pdf
```

```java
CompletableFuture<ApiResponse<DynamicResponse>> getStatementsAsync(
    final String accountId,
    final String version,
    final String providerId,
    final String statementId,
    final InteractionType xAkoyaInteractionType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountId` | `String` | Template, Required | Account Identifier |
| `version` | `String` | Template, Required | Akoya major version number. Do not use minor version numbers. For instance, use v2 and not v2.2 |
| `providerId` | `String` | Template, Required | Id of provider |
| `statementId` | `String` | Template, Required | Statement Identifier |
| `xAkoyaInteractionType` | [`InteractionType`](../../doc/models/interaction-type.md) | Header, Optional | Optional but recommended header to include with each data request.<br>Allowed values are `user` or `batch`.<br>`user` indicates a request is prompted by an end-user action.<br>`batch` indicates the request is part of a batch process. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `DynamicResponse`.

## Example Usage

```java
String accountId = ":accountId";
String version = "v2";
String providerId = "mikomo";
String statementId = "statementId";

statementsApi.getStatementsAsync(accountId, version, providerId, statementId, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Statement is processing and is not yet available. | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Account exists but contains no statements. | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | `ApiException` |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 408 | Request timed out (round trip call took >10 seconds). | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Internal Server Error. | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | FdxVersion in header is not implemented. | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance. | [`ErrorException`](../../doc/models/error-exception.md) |

