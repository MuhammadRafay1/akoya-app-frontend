
# PagedIterable

An iterable wrapper for paginated data that allows iteration over pages or individual items. It can fetch and iterate over each individual element in all the pages lazily.

This class implements the interface `java.lang.Iterable<PagedSupplier<I>>`

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `this` | Provides iterator functionality to sequentially access all items across all pages. It fetches pages lazily as needed. | <code>Iterable<[`PagedSupplier`](../doc/paged-supplier.md)<I>></code> |
| `pages` | Retrieve an iterable collection of all pages in the paginated data, which can be used to loop through all pages lazily. | <code>Iterable<[`PagedSupplier`](../doc/paged-supplier.md)<PagedResponse<I,P>>></code> |

Here the PagedResponse is a base class and it can be an instance of following:

- [`LinkPagedResponse`](../doc/link-paged-response.md)

## Usage Example

```java
// Iterating over items in all the pages.
pagedIterable.forEach(_item -> {
    try {
        System.out.println(_item.get());
    } catch (ApiException | IOException e) {
        e.printStackTrace(); // Handle the exception
    }
});

// Iterating over all the pages.
pagedIterable.pages().forEach(_page -> {
    try {
        PagedResponse<?, ?> pageValue = _page.get();

        if (pageValue instanceof LinkPagedResponse) {
            // Extracting next link value that's used to fetch this page.
            System.out.println(((LinkPagedResponse<?, ?>) pageValue).getNextLink());
        }

        // Iterating over items in the current page.
        pageValue.getItems().forEach(_item -> System.out.println(_item));

        // Extracting paged response body.
        System.out.println(pageValue.getResult());

        // Extracting paged response headers.
        System.out.println(pageValue.getHeaders().asSimpleMap());

        // Extracting paged response status code.
        System.out.println(pageValue.getStatusCode());

    } catch (ApiException | IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
});
```

