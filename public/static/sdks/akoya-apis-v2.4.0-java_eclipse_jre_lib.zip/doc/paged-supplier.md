
# PagedSupplier

`PagedSupplier<T>` is a lightweight wrapper just like `java.util.function.Supplier` that can return a single item or page of data. It handles both API and I/O exceptions in a clean and consistent manner.

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `get()` | Returns the result by invoking the supplier, potentially throwing an ApiException or IOException. | `T` |

