
# HttpBodyRequest

HTTP Request with an explicit body.

## Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getBody()` | Body for the http request. | `Object` |

