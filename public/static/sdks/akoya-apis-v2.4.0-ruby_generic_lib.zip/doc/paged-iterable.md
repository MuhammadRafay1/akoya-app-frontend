
# PagedIterable

An iterable wrapper for paginated data that allows iteration over pages or individual items. It can fetch and iterate over each individual element in all the pages lazily.

This class defines the 'each` method that provides it with the iterator functionality.

## Methods

| Name | Description | Type |
|  --- | --- | --- |
| `each` | Provides iterator functionality to sequentially access all items across all pages. It will loop through all items by fetching next pages lazily. | `Enumerator<Object>` |
| `pages` | Retrieve an iterable collection of all pages in the paginated data, which can be used to loop through all pages lazily. | <code>Enumerator<[`LinkPagedResponse`](../doc/link-paged-response.md) \| [`NumberPagedResponse`](../doc/number-paged-response.md) \| [`CursorPagedResponse`](../doc/cursor-paged-response.md) \| [`OffsetPagedResponse`](../doc/offset-paged-response.md)></code> |

## Usage Example

```ruby
# Iterating over items in all pages.
result.each { | _item | puts _item }

# Iterating over pages in the paginated response.
result.pages.each do |_page|
  if page.is_a?(CursorPagedResponse)
    puts page.next_cursor
  elsif page.is_a?(NumberPagedResponse)
    puts page.page_number
  elsif page.is_a?(LinkPagedResponse)
    puts page.next_link
  elsif page.is_a?(OffsetPagedResponse)
    puts page.offset
  else
    puts "Unknown Pagination Metadata Type"
  end

  puts _page.data
  # Iterating over items in the current page.
  _page.items.each { |_item| puts _item }
end
```

