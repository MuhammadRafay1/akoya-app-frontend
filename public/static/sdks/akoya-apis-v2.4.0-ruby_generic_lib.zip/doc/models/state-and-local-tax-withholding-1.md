
# State and Local Tax Withholding 1

Box 17, State and Local tax withholding

*This model accepts additional fields of type Object.*

## Structure

`StateAndLocalTaxWithholding1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state_code` | [`StateCode2`](../../doc/models/state-code-2.md) | Optional | State two-digit code |
| `state` | [`StateTaxWithholding2`](../../doc/models/state-tax-withholding-2.md) | Optional | Amount of state income tax withheld |
| `local` | [`LocalTaxWithholding1`](../../doc/models/local-tax-withholding-1.md) | Optional | Amount of local income tax withheld, if any |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "stateCode": "AA",
  "state": {
    "taxWithheld": 128.78,
    "taxId": "taxId0",
    "income": 191.56,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "local": {
    "taxWithheld": 75.84,
    "localityName": "localityName6",
    "income": 244.5,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

