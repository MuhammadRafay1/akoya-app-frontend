
# Hateoas Link

REST application constraint (Hypermedia As The Engine Of Application State)

*This model accepts additional fields of type Object.*

## Structure

`HateoasLink`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `href` | `String` | Required | URL to invoke the action on the resource |
| `action` | [`Action`](../../doc/models/action.md) | Optional | HTTP Method to use for the request |
| `types` | [`Array<Type>`](../../doc/models/type.md) | Optional | Content-types that can be used in the Accept header. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "href": "https://api.fi.com/fdx/v4/accounts/12345",
  "action": "DELETE",
  "types": [
    "image/gif"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

