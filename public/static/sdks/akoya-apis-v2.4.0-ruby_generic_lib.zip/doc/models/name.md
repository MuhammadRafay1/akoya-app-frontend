
# Name

The end-user's name

*This model accepts additional fields of type Object.*

## Structure

`Name`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `String` | Optional | First or given name. This data element may contain first & last name if not separated. |
| `middle` | `String` | Optional | - |
| `last` | `String` | Optional | - |
| `prefix` | `String` | Optional | Name prefix, e.g. Mr. |
| `suffix` | `String` | Optional | Generational or academic suffix |
| `company` | `String` | Optional | Company name |
| `addresses` | [`Array<Address2>`](../../doc/models/address-2.md) | Optional | An array of the end-user's physical mail addresses<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `telephones` | [`Array<Telephone>`](../../doc/models/telephone.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `email` | `Array<String>` | Optional | An array of the end-user's electronic mail addresses |
| `accounts` | [`Array<Account7>`](../../doc/models/account-7.md) | Optional | List of accounts related to this end-user<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

