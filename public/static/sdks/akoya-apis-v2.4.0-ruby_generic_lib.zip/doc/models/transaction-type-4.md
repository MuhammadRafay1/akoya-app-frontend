
# Transaction Type 4

LocTransaction Type

## Enumeration

`TransactionType4`

## Fields

| Name |
|  --- |
| `CHECK` |
| `WITHDRAWAL` |
| `TRANSFER` |
| `POSDEBIT` |
| `ATMWITHDRAWAL` |
| `BILLPAYMENT` |
| `FEE` |
| `DEPOSIT` |
| `ADJUSTMENT` |
| `INTEREST` |
| `DIVIDEND` |
| `DIRECTDEPOSIT` |
| `ATMDEPOSIT` |
| `POSCREDIT` |

