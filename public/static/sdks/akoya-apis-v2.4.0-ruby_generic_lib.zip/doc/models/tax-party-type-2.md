
# Tax Party Type 2

Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient

## Enumeration

`TaxPartyType2`

## Fields

| Name |
|  --- |
| `BUSINESS` |
| `INDIVIDUAL` |

