
# Expired Option Type

Type of expired stock option. Used by IRS Form 8949

## Enumeration

`ExpiredOptionType`

## Fields

| Name |
|  --- |
| `GRANTED` |
| `PURCHASED` |

