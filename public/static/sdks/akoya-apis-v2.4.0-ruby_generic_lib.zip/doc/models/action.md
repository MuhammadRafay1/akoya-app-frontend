
# Action

HTTP Method to use for the request

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `GET` |
| `POST` |
| `PATCH` |
| `DELETE` |
| `PUT` |

