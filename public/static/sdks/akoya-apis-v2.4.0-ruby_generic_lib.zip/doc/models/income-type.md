
# Income Type

Type of investment income. CGLONG (capital gains-long term), CGSHORT (capital gains-short term), MISC.

## Enumeration

`IncomeType`

## Fields

| Name |
|  --- |
| `CGLONG` |
| `CGSHORT` |
| `MISC` |

