
# An Investment Holding

*This model accepts additional fields of type Object.*

## Structure

`AnInvestmentHolding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_classes` | [`Array<AssetClass>`](../../doc/models/asset-class.md) | Optional | Percent breakdown by asset class.<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `average_cost` | `TrueClass \| FalseClass` | Optional | Cost is average of all purchases for holding. |
| `cash_account` | `TrueClass \| FalseClass` | Optional | If true, indicates that this holding is used to maintain proceeds from sales, dividends, and other cash postings to the investment account. |
| `change_in_price` | `Float` | Optional | Change in current price compared to previous day's close |
| `currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. |
| `current_unit_price` | `Float` | Optional | - |
| `current_unit_price_date` | `DateTime` | Optional | Current unit price as of date |
| `description` | `String` | Optional | Description of the holding |
| `expiration_date` | `DateTime` | Optional | For CDs, bonds, and other time-based holdings. |
| `face_value` | `Float` | Optional | Face value at the time of data retrieved. |
| `fi_asset_classes` | [`Array<FiAssetClass>`](../../doc/models/fi-asset-class.md) | Optional | Percent breakdown by FI-specific asset class percentage breakdown |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `held_in_account` | [`HeldInAccount`](../../doc/models/held-in-account.md) | Optional | Sub-account |
| `holding_id` | `String` | Optional | Long term persistent identity of the holding |
| `holding_name` | `String` | Optional | Holding name or security name |
| `holding_sub_type` | [`HoldingSubType`](../../doc/models/holding-sub-type.md) | Optional | - |
| `holding_type` | [`HoldingType`](../../doc/models/holding-type.md) | Optional | - |
| `inv_401_k_surce` | [`Inv401KSurce`](../../doc/models/inv-401-k-surce.md) | Optional | Source for money for this security. |
| `market_value` | `Float` | Optional | Market value at the time of data retrieved |
| `original_purchase_date` | `DateTime` | Optional | Date of original purchase |
| `position_type` | [`PositionType`](../../doc/models/position-type.md) | Optional | - |
| `purchased_price` | `Float` | Optional | Price of holding at the time of purchase |
| `rate` | `Float` | Optional | For CDs, bonds, and other rate based holdings. |
| `security_id` | `String` | Optional | Unique identifier of security |
| `security_id_type` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type |
| `symbol` | `String` | Optional | Ticker / Market symbol |
| `tax_lots` | [`Array<TaxLot>`](../../doc/models/tax-lot.md) | Optional | Breakdown by tax lot.<br><br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `units` | `Float` | Optional | Number of shares (with decimals). |
| `mutual_fund_security` | [`MutualFundSecurityEntity`](../../doc/models/mutual-fund-security-entity.md) | Optional | Information about the mutual fund security specific to the type of security |
| `option_security` | [`OptionSecurityEntity`](../../doc/models/option-security-entity.md) | Optional | Information about the option security specific to the type of security |
| `other_security` | [`OtherSecurityEntity`](../../doc/models/other-security-entity.md) | Optional | Information about the security specific to the type of security |
| `stock_security` | [`StockSecurityEntity`](../../doc/models/stock-security-entity.md) | Optional | Information about the stock security specific to the type of security |
| `sweep_security` | [`SweepSecurityEntity`](../../doc/models/sweep-security-entity.md) | Optional | Information about the sweep security specific to the type of security |
| `debt_security` | [`DebtSecurityEntity`](../../doc/models/debt-security-entity.md) | Optional | Information about the debt security specific to the type of security |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "assetClasses": [
    {
      "assetClass": "DOMESTICBOND",
      "percent": 174.1,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "assetClass": "DOMESTICBOND",
      "percent": 174.1,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "averageCost": false,
  "cashAccount": false,
  "changeInPrice": 26.72,
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

