
# Other Security Entity

Information about the security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`OtherSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type_description` | `String` | Optional | Description of Other Security |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "typeDescription": "typeDescription6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

