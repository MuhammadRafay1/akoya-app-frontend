
# Domicile

The country and region of the business customer's location

*This model accepts additional fields of type Object.*

## Structure

`Domicile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | `String` | Optional | - |
| `country` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "region": "region2",
  "country": "country0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

