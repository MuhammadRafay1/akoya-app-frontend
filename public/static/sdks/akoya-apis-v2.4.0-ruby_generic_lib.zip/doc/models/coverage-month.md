
# Coverage Month

Month enumeration used on forms 1095-A and 1095-C

## Enumeration

`CoverageMonth`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `JANUARY` |
| `FEBRUARY` |
| `MARCH` |
| `APRIL` |
| `MAY` |
| `JUNE` |
| `JULY` |
| `AUGUST` |
| `SEPTEMBER` |
| `OCTOBER` |
| `NOVEMBER` |
| `DECEMBER` |

