
# Address 2

*This model accepts additional fields of type Object.*

## Structure

`Address2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`LocationType`](../../doc/models/location-type.md) | Optional | The location type of an address |
| `line_1` | `String` | Optional | May contain full address if not separated |
| `line_2` | `String` | Optional | - |
| `line_3` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `state` | `String` | Optional | - |
| `postal_code` | `String` | Optional | - |
| `country` | `String` | Optional | ISO 3166 Country Code |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "HOME",
  "line1": "line14",
  "line2": "line26",
  "line3": "line34",
  "city": "city2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

