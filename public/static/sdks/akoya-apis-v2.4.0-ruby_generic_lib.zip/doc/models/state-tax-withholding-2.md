
# State Tax Withholding 2

Amount of state income tax withheld

*This model accepts additional fields of type Object.*

## Structure

`StateTaxWithholding2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_withheld` | `Float` | Optional | Amount of state income tax withheld |
| `tax_id` | `String` | Optional | Filer's state tax id |
| `income` | `Float` | Optional | Income amount for state tax purposes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 252.7,
  "taxId": "taxId2",
  "income": 67.64,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

