
# Investment Loan Entity

Information about an investment loan.

*This model accepts additional fields of type Object.*

## Structure

`InvestmentLoanEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `loan_id` | `String` | Optional | Unique identifier for this loan |
| `loan_description` | `String` | Optional | Description |
| `initial_loan_balance` | `Float` | Optional | Initial loan balance amount |
| `loan_start_date` | `DateTime` | Optional | Start date of the loan |
| `current_loan_balance` | `Float` | Optional | Current loan principal balance amount |
| `date_as_of` | `DateTime` | Optional | Date and time of current loan balance |
| `loan_rate` | `Float` | Optional | Loan annual interest rate for the loan |
| `loan_payment_amount` | `Float` | Optional | Loan payment amount |
| `loan_payment_frequency` | [`LoanPaymentFrequency`](../../doc/models/loan-payment-frequency.md) | Optional | - |
| `loan_payment_initial` | `Float` | Optional | Initial number of loan payments |
| `loan_payments_remaining` | `Integer` | Optional | Remaining number of loan payments |
| `loan_maturity_date` | `DateTime` | Optional | Expected loan end date |
| `loan_interest_to_date` | `Float` | Optional | Total interest paid to date on this loan |
| `loan_total_projected_interest` | `Float` | Optional | Total projected interest to be paid on this loan |
| `loan_next_payment_date` | `DateTime` | Optional | The next payment date for the loan |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "loanId": "loanId2",
  "loanDescription": "loanDescription4",
  "initialLoanBalance": 205.08,
  "loanStartDate": "2016-03-13T12:52:32.123Z",
  "currentLoanBalance": 206.82,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

