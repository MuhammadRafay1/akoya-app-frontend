
# Code and Amount

Code and amount pair used on IRS W-2, K-1, etc.

*This model accepts additional fields of type Object.*

## Structure

`CodeAndAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | Code |
| `amount` | `Float` | Optional | Amount |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "code": "code2",
  "amount": 40.84,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

