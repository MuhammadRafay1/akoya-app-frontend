
# Policy Premium Term

he payment term for the premium. MONTHLY or ANNUAL.

## Enumeration

`PolicyPremiumTerm`

## Fields

| Name |
|  --- |
| `MONTHLY` |
| `ANNUAL` |

