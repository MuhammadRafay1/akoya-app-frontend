
# Contribution Entity

Describes how new contributions are distributed among the available securities.

*This model accepts additional fields of type Object.*

## Structure

`ContributionEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `security_id` | `String` | Optional | Unique identifier of security |
| `security_id_type` | [`SecurityIdType`](../../doc/models/security-id-type.md) | Optional | Security identifier type |
| `employer_match_percentage` | `Float` | Optional | Employer contribution match percentage |
| `employer_match_amount` | `Float` | Optional | Employer contribution match amount |
| `employee_pre_tax_amount` | `Float` | Optional | Employee pre‐tax contribution amount |
| `employee_pre_tax_percentage` | `Float` | Optional | Employee pre‐tax contribution percentage |
| `employee_after_tax_amount` | `Float` | Optional | Employee after tax contribution amount |
| `employee_after_tax_percentage` | `Float` | Optional | Employee after tax contribution percentage |
| `employee_defer_pre_tax_amount` | `Float` | Optional | Employee defer pre‐tax contribution match amount |
| `employee_defer_pre_tax_percentage` | `Float` | Optional | Employee defer pre‐tax contribution match percentage |
| `employee_year_to_date` | `Float` | Optional | Employee total year to date contribution |
| `employer_year_to_date` | `Float` | Optional | Employer total year to date contribution |
| `rollover_contribution_percentage` | `Float` | Optional | Rollover contribution percentage |
| `rollover_contribution_amount` | `Float` | Optional | Rollover contribution Amount |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "securityId": "securityId2",
  "securityIdType": "VALOR",
  "employerMatchPercentage": 195.92,
  "employerMatchAmount": 120.16,
  "employeePreTaxAmount": 147.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

