
# Tax Refund Direct Deposit 2

Tax refund direct deposit information

*This model accepts additional fields of type Object.*

## Structure

`TaxRefundDirectDeposit2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_name` | `String` | Optional | Name of institution |
| `rtn` | `String` | Optional | Routing transit number |
| `account_number` | `String` | Optional | Account number |
| `account_nick_name` | `String` | Optional | Account nickname |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "institutionName": "institutionName0",
  "rtn": "rtn6",
  "accountNumber": "accountNumber0",
  "accountNickName": "accountNickName8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

