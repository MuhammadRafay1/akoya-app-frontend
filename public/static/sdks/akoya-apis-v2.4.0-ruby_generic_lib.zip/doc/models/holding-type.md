
# Holding Type

## Enumeration

`HoldingType`

## Fields

| Name |
|  --- |
| `STOCK` |
| `BOND` |
| `MUTUALFUND` |
| `CD` |
| `ANNUITY` |
| `OPTION` |
| `OTHER` |

