
# Order Type

Type of order.

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `BUY` |
| `SELL` |
| `BUYTOCOVER` |
| `BUYTOOPEN` |
| `SELLTOCOVER` |
| `SELLTOOPEN` |
| `SELLSHORT` |
| `SELLCLOSE` |

