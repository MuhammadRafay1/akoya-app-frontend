
# Mode

Indicates format of returned data.
'raw' = provider-specific;
'standard' = FDX-aligned values (BETA)

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `RAW` |
| `STANDARD` |

## Example

```
raw
```

