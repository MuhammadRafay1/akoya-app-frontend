
# Business Name

Name 1, Name 2

*This model accepts additional fields of type Object.*

## Structure

`BusinessName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name_1` | `String` | Optional | Name line 1 |
| `name_2` | `String` | Optional | Name line 2 |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name1": "name16",
  "name2": "name20",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

