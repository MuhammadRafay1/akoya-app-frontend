
# Balance Type

ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance)

## Enumeration

`BalanceType`

## Fields

| Name |
|  --- |
| `ASSET` |
| `LIABILITY` |

