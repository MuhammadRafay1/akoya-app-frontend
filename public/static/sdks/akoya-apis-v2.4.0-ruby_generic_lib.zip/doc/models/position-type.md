
# Position Type

## Enumeration

`PositionType`

## Fields

| Name |
|  --- |
| `LONG` |
| `SHORT` |

