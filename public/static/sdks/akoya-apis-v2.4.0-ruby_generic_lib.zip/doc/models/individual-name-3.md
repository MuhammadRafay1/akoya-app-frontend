
# Individual Name 3

Box g, Employee's previously reported name

*This model accepts additional fields of type Object.*

## Structure

`IndividualName3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `String` | Optional | First name |
| `middle` | `String` | Optional | Middle initial |
| `last` | `String` | Optional | Last name |
| `suffix` | `String` | Optional | Generational or academic suffix |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first8",
  "middle": "middle8",
  "last": "last8",
  "suffix": "suffix8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

