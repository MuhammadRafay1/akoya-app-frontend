
# Fi Asset Class

*This model accepts additional fields of type Object.*

## Structure

`FiAssetClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_class` | `String` | Optional | FI-specific asset class |
| `percent` | `Float` | Optional | Percentage of asset class that falls under this asset |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 193.72,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

