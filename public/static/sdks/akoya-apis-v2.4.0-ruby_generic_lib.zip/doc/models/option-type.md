
# Option Type

## Enumeration

`OptionType`

## Fields

| Name |
|  --- |
| `CALL` |
| `PUT` |

