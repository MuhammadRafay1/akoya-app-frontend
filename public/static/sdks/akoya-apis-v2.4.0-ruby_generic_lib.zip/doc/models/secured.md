
# Secured

How the option is secured

## Enumeration

`Secured`

## Fields

| Name |
|  --- |
| `COVERED` |
| `NAKED` |

