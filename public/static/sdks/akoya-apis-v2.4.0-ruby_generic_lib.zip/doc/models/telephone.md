
# Telephone

*This model accepts additional fields of type Object.*

## Structure

`Telephone`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | `String` | Optional | - |
| `type` | [`PhoneType`](../../doc/models/phone-type.md) | Optional | - |
| `country` | `String` | Optional | Country calling codes defined by ITU-T recommendations E.123 and E.164 |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "number": "number6",
  "type": "HOME",
  "country": "country2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

