
# Option Security Entity

Information about the option security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`OptionSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `secured` | [`Secured`](../../doc/models/secured.md) | Optional | How the option is secured |
| `option_type` | [`OptionType`](../../doc/models/option-type.md) | Optional | - |
| `strike_price` | `Float` | Optional | Strike price / Unit price |
| `expire_date` | `DateTime` | Optional | Expiration date of option |
| `shares_per_contract` | `Float` | Optional | Shares per contract |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "secured": "COVERED",
  "optionType": "CALL",
  "strikePrice": 0.6,
  "expireDate": "2016-03-13T12:52:32.123Z",
  "sharesPerContract": 217.4,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

