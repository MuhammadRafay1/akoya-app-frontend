
# Account Contact Entity

Contact information for the account

*This model accepts additional fields of type Object.*

## Structure

`AccountContactEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `holders` | [`Array<AccountHolderEntity>`](../../doc/models/account-holder-entity.md) | Optional | Owners of the account |
| `emails` | `Array<String>` | Optional | Email addresses associated with the account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "holders": [
    {
      "customerId": "customerId0",
      "name": {
        "first": "first6",
        "middle": "middle6",
        "last": "last0",
        "prefix": "prefix8",
        "suffix": "suffix0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "relationship": "FOR_BENEFIT_OF_SECONDARY_JOINT_RESTRICTED",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "customerId": "customerId0",
      "name": {
        "first": "first6",
        "middle": "middle6",
        "last": "last0",
        "prefix": "prefix8",
        "suffix": "suffix0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "relationship": "FOR_BENEFIT_OF_SECONDARY_JOINT_RESTRICTED",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "emails": [
    "emails1"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

