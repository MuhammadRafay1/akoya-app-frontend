
# Stock Security Entity

Information about the stock security specific to the type of security

*This model accepts additional fields of type Object.*

## Structure

`StockSecurityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `units_street` | `Float` | Optional | Units in the FI's street name, positive quantity |
| `units_user` | `Float` | Optional | Units in user's name directly, positive  quantity |
| `reinvest_dividends` | `TrueClass \| FalseClass` | Optional | Reinvest dividends |
| `stock_type` | [`StockType`](../../doc/models/stock-type.md) | Optional | - |
| `myield` | `Float` | Optional | Current yield |
| `yield_as_of_date` | `DateTime` | Optional | Yield as-of date |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "unitsStreet": 117.56,
  "unitsUser": 92.52,
  "reinvestDividends": false,
  "stockType": "STOCK",
  "yield": 211.18,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

