
# Loan Payment Frequency

## Enumeration

`LoanPaymentFrequency`

## Fields

| Name |
|  --- |
| `WEEKLY` |
| `BIWEEKLY` |
| `TWICEMONTHLY` |
| `MONTHLY` |
| `FOURWEEKS` |
| `BIMONTHLY` |
| `QUARTERLY` |
| `SEMIANNUALLY` |
| `ANNUALLY` |
| `OTHER` |

