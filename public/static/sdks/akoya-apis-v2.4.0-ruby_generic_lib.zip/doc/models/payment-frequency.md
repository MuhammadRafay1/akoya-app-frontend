
# Payment Frequency

## Enumeration

`PaymentFrequency`

## Fields

| Name |
|  --- |
| `DAILY` |
| `WEEKLY` |
| `BIWEEKLY` |
| `SEMIMONTHLY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `ANNUALLY` |

