
# Business Name 1

Business issuer or recipient name

*This model accepts additional fields of type Object.*

## Structure

`BusinessName1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name_1` | `String` | Optional | Name line 1 |
| `name_2` | `String` | Optional | Name line 2 |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name1": "name18",
  "name2": "name22",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

