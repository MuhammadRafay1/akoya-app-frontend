
# Telephone Number Type

Purpose or type of telephone number

## Enumeration

`TelephoneNumberType`

## Fields

| Name |
|  --- |
| `BUSINESS` |
| `CELL` |
| `FAX` |
| `HOME` |

