
# Transactions Entity

Optionally paginated array of transactions

*This model accepts additional fields of type Object.*

## Structure

`TransactionsEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `transactions` | Array[[Transaction1](../../doc/models/transaction-1.md) \| [Transaction11](../../doc/models/transaction-11.md) \| [Transaction12](../../doc/models/transaction-12.md) \| [Transaction13](../../doc/models/transaction-13.md) \| [Transaction14](../../doc/models/transaction-14.md)] \| nil | Optional | This is Array of a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "links": {
    "next": {
      "href": "href4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "transactions": [
    {
      "depositTransaction": {
        "accountId": "accountId0",
        "amount": 1.72,
        "category": "category8",
        "debitCreditMemo": "DEBIT",
        "description": "description0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

