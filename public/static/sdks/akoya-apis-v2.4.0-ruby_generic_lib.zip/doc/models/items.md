
# Items

*This model accepts additional fields of type Object.*

## Structure

`Items`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cost_basis` | `Float` | Optional | Total amount of money spent acquiring this lot including any fees or commission expenses incurred. |
| `current_value` | `Float` | Optional | Lot market value |
| `original_purchase_date` | `DateTime` | Optional | Lot acquired date. |
| `position_type` | [`PositionType2`](../../doc/models/position-type-2.md) | Optional | LONG, SHORT. |
| `purchased_price` | `Float` | Optional | Original purchase price. |
| `quantity` | `Float` | Optional | Lot quantity. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "costBasis": 220.88,
  "currentValue": 32.84,
  "originalPurchaseDate": "2016-03-13T12:52:32.123Z",
  "positionType": "LONG",
  "purchasedPrice": 246.34,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

