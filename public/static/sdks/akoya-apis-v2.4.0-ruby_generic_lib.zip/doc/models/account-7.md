
# Account 7

*This model accepts additional fields of type Object.*

## Structure

`Account7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `String` | Optional | Account ID of the related account |
| `relationship` | [`AccountHolderRelationship`](../../doc/models/account-holder-relationship.md) | Optional | Types of relationships between accounts and holders. Suggested values |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId8",
  "relationship": "FOR_BENEFIT_OF_PRIMARY_JOINT_RESTRICTED",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

