
# Loan Balances

Data elements included with balances specific to loan accounts

*This model accepts additional fields of type Object.*

## Structure

`LoanBalances`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `String` | Optional | Long-term persistent identity of the account. Not an account number. This identity must be unique to the owning institution. |
| `account_type` | `String` | Optional | The type of an account. For instance, CHECKING, SAVINGS, 401K, etc. |
| `account_number_display` | `String` | Optional | Account display number for the end user’s handle at owning institution. This is to be displayed by the Interface Provider. |
| `currency` | [`CurrencyEntity`](../../doc/models/currency-entity.md) | Optional | Indicates the currency code used by the account. May also include currency rate. |
| `description` | `String` | Optional | - |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | - |
| `nickname` | `String` | Optional | Name given by the user. Used in UIs to assist in account selection |
| `product_name` | `String` | Optional | Marketed product name for this account.  Used in UIs to assist in account selection |
| `status` | [`Status`](../../doc/models/status.md) | Optional | The status of an account. |
| `line_of_business` | `String` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. |
| `balance_type` | [`BalanceType`](../../doc/models/balance-type.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) |
| `interest_rate` | `Float` | Optional | Interest Rate of Account |
| `interest_rate_type` | [`InterestRateType`](../../doc/models/interest-rate-type.md) | Optional | The type of interest rate. FIXED or VARIABLE. |
| `interest_rate_as_of` | `DateTime` | Optional | Date of account’s interest rate |
| `last_activity_date` | `DateTime` | Optional | Date that last transaction occurred on account |
| `micr_number` | `String` | Optional | MICR Number |
| `parent_account_id` | `String` | Optional | Long-term persistent identity of the parent account. This is used to group accounts. |
| `prior_interest_rate` | `Float` | Optional | Previous Interest Rate of Account |
| `transfer_in` | `TrueClass \| FalseClass` | Optional | Account is eligible for incoming transfers |
| `transfer_out` | `TrueClass \| FalseClass` | Optional | Account is eligible for outgoing transfers |
| `compounding_period` | [`CompoundingPeriod`](../../doc/models/compounding-period.md) | Optional | - |
| `loan_term` | `Integer` | Optional | Term of loan in months |
| `maturity_date` | `DateTime` | Optional | Maturity date |
| `originating_date` | `DateTime` | Optional | Loan origination date |
| `payment_frequency` | [`PaymentFrequency`](../../doc/models/payment-frequency.md) | Optional | - |
| `total_number_of_payments` | `Integer` | Optional | Total number of payments |
| `balance_as_of` | `DateTime` | Optional | As-of date of balances |
| `escrow_balance` | `Float` | Optional | Escrow balance of loan |
| `interest_paid_year_to_date` | `Float` | Optional | Interest paid year to date |
| `last_payment_amount` | `Float` | Optional | Last payment amount |
| `last_payment_date` | `DateTime` | Optional | Last payment date |
| `next_payment_amount` | `Float` | Optional | Amount of next payment |
| `next_payment_date` | `DateTime` | Optional | Date of next payment |
| `original_principal` | `Float` | Optional | Original principal of loan |
| `pay_off_amount` | `Float` | Optional | Payoff amount |
| `principal_balance` | `Float` | Optional | Principal balance of loan |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId8",
  "accountType": "accountType8",
  "accountNumberDisplay": "accountNumberDisplay4",
  "currency": {
    "currencyCode": "currencyCode0",
    "currencyRate": 27.48,
    "originalCurrencyCode": "originalCurrencyCode4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "description": "description8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

