
# Customer Name

*This model accepts additional fields of type Object.*

## Structure

`CustomerName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `String` | Optional | First or given name. This data element may contain first & last name if not separated. |
| `middle` | `String` | Optional | - |
| `last` | `String` | Optional | - |
| `prefix` | `String` | Optional | Name prefix, e.g. Mr. |
| `suffix` | `String` | Optional | Generational or academic suffix |
| `company` | `String` | Optional | Company name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first6",
  "middle": "middle6",
  "last": "last0",
  "prefix": "prefix8",
  "suffix": "suffix0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

