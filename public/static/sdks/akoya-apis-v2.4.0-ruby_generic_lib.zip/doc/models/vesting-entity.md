
# Vesting Entity

Provides the past, present, and future vesting schedule and percentages.

*This model accepts additional fields of type Object.*

## Structure

`VestingEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vesting_date` | `DateTime` | Optional | Vesting date |
| `symbol` | `String` | Optional | Security symbol |
| `strike_price` | `Float` | Optional | Strike price |
| `vesting_percentage` | `Float` | Optional | Vesting percentage |
| `other_vest_amount` | `Float` | Optional | Other vest amount |
| `other_vest_percentage` | `Float` | Optional | Other vest percentage |
| `vested_balance` | `Float` | Optional | Vested balance |
| `un_vested_balance` | `Float` | Optional | Unvested balance |
| `vested_quantity` | `Float` | Optional | Vested qualtity |
| `un_vested_quantity` | `Float` | Optional | Unvested quantity |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "vestingDate": "2016-03-13T12:52:32.123Z",
  "symbol": "symbol0",
  "strikePrice": 216.86,
  "vestingPercentage": 250.28,
  "otherVestAmount": 111.28,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

