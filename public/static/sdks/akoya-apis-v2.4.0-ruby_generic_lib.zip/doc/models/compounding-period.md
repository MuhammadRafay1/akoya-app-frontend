
# Compounding Period

## Enumeration

`CompoundingPeriod`

## Fields

| Name |
|  --- |
| `DAILY` |
| `WEEKLY` |
| `BIWEEKLY` |
| `SEMIMONTHLY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `ANNUALLY` |

