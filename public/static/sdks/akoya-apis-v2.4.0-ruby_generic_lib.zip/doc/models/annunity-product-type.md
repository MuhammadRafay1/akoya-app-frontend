
# Annunity Product Type

## Enumeration

`AnnunityProductType`

## Fields

| Name |
|  --- |
| `CURRENCY` |
| `SHARES` |

