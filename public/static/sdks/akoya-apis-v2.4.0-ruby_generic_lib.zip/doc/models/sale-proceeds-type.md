
# Sale Proceeds Type

Gross or net proceeds. Used by Form 1099-B

## Enumeration

`SaleProceedsType`

## Fields

| Name |
|  --- |
| `GROSS` |
| `NET` |

