
# Annual Increase Type

## Enumeration

`AnnualIncreaseType`

## Fields

| Name |
|  --- |
| `FIXED` |
| `PERCENT` |
| `DOLLAR` |

