
# Call Type

Type of next call

## Enumeration

`CallType`

## Fields

| Name |
|  --- |
| `CALL` |
| `PUT` |
| `PREFUND` |
| `MATURITY` |

