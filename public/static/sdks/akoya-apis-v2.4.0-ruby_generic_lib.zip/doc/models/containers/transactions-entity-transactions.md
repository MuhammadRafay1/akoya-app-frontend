
# Transactions Entity Transactions

## Data Type

`Transaction1 | Transaction11 | Transaction12 | Transaction13 | Transaction14`

## Cases

| Type |
|  --- |
| [`Transaction1`](../../../doc/models/transaction-1.md) |
| [`Transaction11`](../../../doc/models/transaction-11.md) |
| [`Transaction12`](../../../doc/models/transaction-12.md) |
| [`Transaction13`](../../../doc/models/transaction-13.md) |
| [`Transaction14`](../../../doc/models/transaction-14.md) |

