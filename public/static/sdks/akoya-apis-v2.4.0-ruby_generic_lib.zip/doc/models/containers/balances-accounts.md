
# Balances Accounts

## Data Type

`Account6 | Account61 | Account62 | Account63 | Account64 | Account65`

## Cases

| Type |
|  --- |
| [`Account6`](../../../doc/models/account-6.md) |
| [`Account61`](../../../doc/models/account-61.md) |
| [`Account62`](../../../doc/models/account-62.md) |
| [`Account63`](../../../doc/models/account-63.md) |
| [`Account64`](../../../doc/models/account-64.md) |
| [`Account65`](../../../doc/models/account-65.md) |

