
# Investments Accounts

## Data Type

`Account8 | Account6 | Account61 | Account62 | Account64 | Account65`

## Cases

| Type |
|  --- |
| [`Account8`](../../../doc/models/account-8.md) |
| [`Account6`](../../../doc/models/account-6.md) |
| [`Account61`](../../../doc/models/account-61.md) |
| [`Account62`](../../../doc/models/account-62.md) |
| [`Account64`](../../../doc/models/account-64.md) |
| [`Account65`](../../../doc/models/account-65.md) |

