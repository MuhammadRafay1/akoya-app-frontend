
# Akoya Account Info Product Accounts

## Data Type

`Account | Account1 | Account2 | Account3 | Account4 | Account5`

## Cases

| Type |
|  --- |
| [`Account`](../../../doc/models/account.md) |
| [`Account1`](../../../doc/models/account-1.md) |
| [`Account2`](../../../doc/models/account-2.md) |
| [`Account3`](../../../doc/models/account-3.md) |
| [`Account4`](../../../doc/models/account-4.md) |
| [`Account5`](../../../doc/models/account-5.md) |

