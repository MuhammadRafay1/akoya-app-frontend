
# Tax Party 1

Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms.

*This model accepts additional fields of type Object.*

## Structure

`TaxParty1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tin` | `String` | Optional | Issuer or recipient Tax Identification Number. Usually EIN for issuer and SSN for recipient |
| `party_type` | [`TaxPartyType2`](../../doc/models/tax-party-type-2.md) | Optional | Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient |
| `individual_name` | [`IndividualName4`](../../doc/models/individual-name-4.md) | Optional | Individual issuer or recipient name |
| `business_name` | [`BusinessName1`](../../doc/models/business-name-1.md) | Optional | Business issuer or recipient name |
| `address` | [`Address1`](../../doc/models/address-1.md) | Optional | Issuer or recipient address |
| `phone` | [`TelephoneNumberPlusExtension4`](../../doc/models/telephone-number-plus-extension-4.md) | Optional | Issuer or recipient telephone number |
| `email` | `String` | Optional | Issuer or recipient email address. (Additional information, not part of IRS forms) |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "tin": "tin8",
  "partyType": "BUSINESS",
  "individualName": {
    "first": "first0",
    "middle": "middle0",
    "last": "last4",
    "suffix": "suffix4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "businessName": {
    "name1": "name18",
    "name2": "name22",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

