
# Debt Type

Debt type

## Enumeration

`DebtType`

## Fields

| Name |
|  --- |
| `ASSET` |
| `COUPON` |

