
# Coverage Month 1

Month of coverage

## Enumeration

`CoverageMonth1`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `JANUARY` |
| `FEBRUARY` |
| `MARCH` |
| `APRIL` |
| `MAY` |
| `JUNE` |
| `JULY` |
| `AUGUST` |
| `SEPTEMBER` |
| `OCTOBER` |
| `NOVEMBER` |
| `DECEMBER` |

