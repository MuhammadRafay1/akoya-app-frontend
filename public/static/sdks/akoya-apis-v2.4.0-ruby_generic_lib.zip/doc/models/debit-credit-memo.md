
# Debit Credit Memo

Akoya will ensure that this is correctly populated with one of DEBIT or CREDIT and matches the sign of the status field.

## Enumeration

`DebitCreditMemo`

## Fields

| Name |
|  --- |
| `DEBIT` |
| `CREDIT` |

