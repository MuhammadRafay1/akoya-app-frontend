
# Phone Type

## Enumeration

`PhoneType`

## Fields

| Name |
|  --- |
| `HOME` |
| `BUSINESS` |
| `CELL` |
| `FAX` |

