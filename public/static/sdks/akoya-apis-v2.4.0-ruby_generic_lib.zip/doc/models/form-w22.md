
# Form W22

Boxes 1-20 of Correct information Wage and Tax Statement

*This model accepts additional fields of type Object.*

## Structure

`FormW22`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_year` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `corrected` | `TrueClass \| FalseClass` | Optional | True to indicate this is a corrected tax form |
| `account_id` | `String` | Optional | Long-term persistent identity of the source account. Not the account number |
| `tax_form_id` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted. |
| `tax_form_date` | `Date` | Optional | Date of production or delivery of the tax form |
| `additional_information` | `String` | Optional | Additional explanation text or content about this tax form |
| `tax_form_type` | [`TypeFormType2`](../../doc/models/type-form-type-2.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. |
| `attributes` | [`Array<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. |
| `error` | [`Error2`](../../doc/models/error-2.md) | Optional | Present if an error was encountered while retrieving this form |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs |
| `control_number` | `String` | Optional | Control number |
| `wages` | `Float` | Optional | Box 1, Wages, tips, other compensation |
| `federal_tax_withheld` | `Float` | Optional | Box 2, Federal income tax withheld |
| `social_security_wages` | `Float` | Optional | Box 3, Social security wages |
| `social_security_tax_withheld` | `Float` | Optional | Box 4, Social security tax withheld |
| `medicare_wages` | `Float` | Optional | Box 5, Medicare wages and tips |
| `medicare_tax_withheld` | `Float` | Optional | Box 6, Medicare tax withheld |
| `social_security_tips` | `Float` | Optional | Box 7, Social security tips |
| `allocated_tips` | `Float` | Optional | Box 8, Allocated tips |
| `dependent_care_benefit` | `Float` | Optional | Box 10, Dependent care benefits |
| `non_qualified_plan` | `Float` | Optional | Box 11, Nonqualified plans |
| `codes` | [`Array<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 12, Codes and amounts |
| `statutory` | `TrueClass \| FalseClass` | Optional | Box 13, Statutory employee |
| `retirement_plan` | `TrueClass \| FalseClass` | Optional | Box 13, Retirement plan |
| `third_party_sick_pay` | `TrueClass \| FalseClass` | Optional | Box 13, Third-party sick pay |
| `espp_qualified` | `Float` | Optional | Employee Stock Purchase Plan Qualified Disposition amount |
| `espp_non_qualified` | `Float` | Optional | Employee Stock Purchase Plan Nonqualified Disposition amount |
| `other` | [`Array<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 14, Other descriptions and amounts |
| `state_and_local` | [`Array<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 15-20, State and Local tax withholding |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId0",
  "taxFormId": "taxFormId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

