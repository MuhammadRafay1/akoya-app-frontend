
# Holding Sub Type

## Enumeration

`HoldingSubType`

## Fields

| Name |
|  --- |
| `MONEYMARKET` |
| `CASH` |

