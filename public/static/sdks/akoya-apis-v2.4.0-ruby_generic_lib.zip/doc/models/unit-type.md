
# Unit Type

Type of unit.

## Enumeration

`UnitType`

## Fields

| Name |
|  --- |
| `CURRENCY` |
| `SHARES` |

